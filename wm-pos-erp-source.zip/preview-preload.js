// preview-preload.js
// Bridge for the print preview window's toolbar. The page itself is the
// invoice HTML with a toolbar injected by main.js; these calls let that
// toolbar print, save a PDF, switch paper size, or close the window.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('previewApi', {
    print: (size, heightPx) => ipcRenderer.invoke('preview:print', { size, heightPx }),
    pdf: (size, heightPx) => ipcRenderer.invoke('preview:pdf', { size, heightPx }),
    setSize: (size) => ipcRenderer.invoke('preview:size', { size }),
    close: () => ipcRenderer.invoke('preview:close'),
});
