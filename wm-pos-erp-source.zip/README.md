# WM POS ERP

Offline, multi-business Point of Sale + ERP desktop app — built with Electron + SQLite,
by **WM Tech**.

Works fully offline (no internet needed to run). All data lives in a local SQLite
database on the computer it's installed on.

## Features (v1)

- **Multi-business**: run unlimited separate businesses from one install, each with
  its own products, stock, accounts and ledger. Good for someone running a General
  Store + Bakery + Pharmacy from one office.
- **Multi-branch**: each business can have multiple branches/outlets, each with its
  own stock levels.
- **POS / Billing**: fast tile-based checkout, barcode/name search, cart, discounts,
  multiple payment methods (cash, card, bank, Easypaisa, JazzCash, credit/udhaar),
  and an automatic printed receipt (via the system print dialog — works with any
  printer configured in Windows, thermal or regular, or "Print to PDF").
- **Sales History & Returns**: browse past invoices by date, view line items,
  reprint any receipt, and process refunds — a refund automatically restores stock
  and posts the reversing ledger entries so accounts stay correct.
- **Inventory**: products, categories, barcodes, cost/sale price, tax %, reorder
  levels, low-stock warnings, manual stock adjustments (damage, correction, opening
  stock) with a logged reason.
- **Purchasing**: suppliers, purchase orders with multiple items, automatically adds
  to stock and posts to accounts payable.
- **Accounting/Ledger**: auto chart of accounts (Cash, Bank, Sales Revenue, Purchase
  Expense, Accounts Receivable/Payable, General Expenses). Every sale, purchase and
  expense automatically posts the right debit/credit entries — no manual bookkeeping.
- **Reports**: sales summary, profit & loss (with real cost-of-goods-sold), top
  selling products, expense log, low stock list — all filterable by date range.
- **Customers & khata**: each customer carries the same details printed on
  invoices (full name, S/O-D/O-W/O, CNIC, contact, address) plus an optional
  opening balance. Their khata combines counter sales, service jobs and vehicle
  sales with payments received, with a running balance, and can be printed as an
  A4 statement. Receiving a payment moves it from Accounts Receivable into
  Cash/Bank. Vehicle buyers are added as customers automatically. POS defaults to
  "Walk-in Customer" and refuses to leave any balance unpaid unless a named
  customer is selected, so every rupee owed has an owner.
- **Users & roles**: super_admin / admin / manager / accountant / cashier, with
  login required.
- **Automatic backup**: pick any folder (second drive, USB, or a Google Drive /
  OneDrive sync folder) and the app backs itself up on launch once a day and again
  when you close it. Old backups are pruned automatically to whatever number you
  choose. Every backup is restorable in one click from the Settings page, and
  backups sort by the timestamp in their filename, so the order stays correct even
  after copying them to another drive.
- **Auto-update**: checks GitHub Releases for a newer version, downloads it on your
  confirmation, and installs on restart. Update checks need internet; everything
  else in the app works fully offline.
- **Industry modules**: the business type chosen at setup changes what the app
  shows. Currently built out: **Automobile (Parts & Service)** — parts carry a
  Part Number and Compatible Vehicles fitment note, and a dedicated **Service
  Jobs** module tracks vehicles, mechanics, and repair jobs from intake through
  billing (see below). Other business types (General Store, Bakery, Pharmacy)
  currently share the same general-purpose screens; more industry-specific
  modules can be added the same way.

### Automobile module (Parts & Service)

Only appears when a business's type is set to "Automobile (Parts & Service)".

- **Vehicles**: registration number, make/model/year, linked to a customer
- **Mechanics**: simple roster (name, phone, specialty) — no login needed
- **Service Jobs**: `pending → in_progress → completed → delivered` (or
  `cancelled`). Add part lines (pulled from inventory, at whatever price you set)
  and labor lines (free-text description + amount) while a job is open.
- **Finalizing a job** (moving it to "delivered") is the one irreversible step:
  it decrements stock for the parts used, posts the same ledger entries a normal
  sale would (Cash/Receivable vs Sales Revenue), and locks the job from further
  edits — mirroring how a completed sale works elsewhere in the app.
  This requires the `automobile.jobs.finalize` permission, separate from
  `automobile.jobs.manage` (which only allows opening jobs and adding parts/labor)
  — so a cashier can process jobs day-to-day without being able to bill and close
  them if you don't want them to.
- **Reports** gets a "Labor vs Parts" breakdown for delivered jobs in the
  selected date range; **Dashboard** gets an "Open Service Jobs" count.
- **Vehicle Stock & Sales** (bikes, cars, scooters): each unit is tracked
  individually with its own motor and chassis number, rather than as a quantity.
  Selling a unit records the buyer's details (name, S/O-D/O-W/O, CNIC, contact,
  address), marks it sold, and posts the ledger entries. A sale can be cancelled,
  which reverses the ledger and returns the unit to stock.
- **Vehicle sales invoice** prints in three sizes: **A4** and **A5** use a formal
  dealership layout (logo, SALES INVOICE title, customer information, spec table,
  cash/online payment boxes, signature lines); **80mm thermal** is a condensed
  receipt with the same information. The shop's receipt footer (Settings → Shop
  Profile) is printed as the "Important Information" note.
- **Bikes/cars sold through POS**: in an automobile business, an inventory
  product can be marked "Ye bike/car hai" and carries a **Colour** and **Model**.
  Stock is kept as a quantity per model/colour; the per-unit **Chassis No, Motor
  No and Motor Power** are *not* stored on the product — they are typed in at
  checkout, one set per unit (each bike is its own cart line), saved on that sale
  line, and printed on the formal A4/A5/80mm invoice. A named customer is
  required for these sales because the invoice prints the buyer's details.
- **Invoices & Print Preview**: every sale, service job and khata prints through a
  real **Print Preview window** (the page is shown at its true paper size, with
  Print, Save PDF and A4 / A5 / 80mm buttons). Previously printing went straight
  from a hidden frame to the OS dialog, with no preview. A4 and A5 use a
  receipt-book layout: shop logo top-left, an optional **brand logo + title**
  top-right (e.g. EVEE / Electric Scooter), invoice no. and date, customer details
  on ruled lines, QTY / DESCRIPTION / AMOUNT, Important Information, Cash/Online
  boxes, amount paid, balance, signatures and an address footer. 80mm thermal is a
  condensed version sized to its content. The default size is chosen in Settings →
  Shop Profile → Invoice Print Size (or "ask every time").
- Dashboard and Reports totals (sales, invoices, amount due, profit) include
  counter sales, delivered service jobs, and vehicle sales together.

Default login on first run: **admin / admin123** (change this from Settings → Users
once you're set up).

## Getting started (development)

```bash
npm install
npx electron-rebuild -f -w better-sqlite3   # only needed once, or after npm install
npm start
```

## Building an installer

```bash
npm run build-win     # Windows .exe installer (NSIS)
npm run build-linux   # Linux AppImage
```

Output lands in `dist/`.

**Building the Windows installer on Windows** — just run `npm run build-win`, nothing
extra needed.

**Building the Windows installer on Linux** — you need Wine (both 64-bit and 32-bit;
NSIS runs the installer once under Wine to generate the uninstaller):

```bash
sudo dpkg --add-architecture i386
sudo apt-get update
sudo apt-get install -y --no-install-recommends wine64 wine32:i386
```

The native `better-sqlite3` module is fetched as a prebuilt Windows binary
automatically, so no Windows compiler is needed.

### Important packaging note

`better-sqlite3` is a native module and **must** be excluded from the asar bundle,
or the app will crash on launch with a "cannot find module" error. This is already
handled by `asarUnpack` in `package.json` — don't remove it.

## Releasing a new version (GitHub Actions builds it)

Same setup as WM BillSoft: the source lives in a **private** repo, GitHub builds
the installer on its own Windows machine, and publishes it to the **public**
`waqas1952/wm-pos-erp-release` repo that installed copies check for updates.

One-time setup:
1. In the private source repo: Settings → Secrets and variables → Actions →
   New repository secret, name **`RELEASES_TOKEN`**, value = a fine-grained token
   from the **waqas1952** account with access to `wm-pos-erp-release` and
   **Contents: Read and write**.
2. Put `.github/workflows/release.yml` in the source repo (it is in this project).

Every release:
1. Raise `"version"` in `package.json` (e.g. 1.6.0 → 1.7.0).
2. Upload the project to the private repo's `main` branch — either the files
   themselves, or the single `wm-pos-erp-source.zip` (the workflow unpacks it).
3. The **Actions** tab shows "Build & Release (Windows)" running (~5–10 min).
   When it finishes, `wm-pos-erp-release` has a new release with
   `WM-POS-ERP-Setup-X.Y.Z.exe` and `latest.yml`, marked Latest.
4. Installed copies see it on next launch, or via Settings → Check for Updates.

Pushing the same version again does not replace a published release, so always
raise the version. The run also keeps a downloadable copy of the installer under
the run's "Artifacts".

Building by hand is still possible: `npm run build-win` makes
`dist/WM-POS-ERP-Setup-X.Y.Z.exe` and `dist/latest.yml`, which can be attached to
a release manually (the file name already matches what `latest.yml` expects).
The repo must stay Public, and the release must not be a pre-release.

## Project structure

```
main.js              Electron main process + all IPC handlers
preload.js            Safe bridge exposing window.api to the renderer
db/schema.sql         Full SQLite schema (businesses, products, sales, ledger, etc.)
db/database.js        All business logic: stock updates, ledger auto-posting, reports
renderer/             The UI (HTML/CSS/vanilla JS, one file per module)
  index.html
  css/style.css
  js/state.js          shared state + helpers (toast, money formatting, ipc wrapper)
  js/app.js             login, business/branch switching, navigation
  js/dashboard.js, pos.js, inventory.js, purchasing.js, accounts.js, reports.js, settings.js
```

Each sale/purchase/expense is wrapped in a SQLite transaction, so stock and ledger
entries always stay in sync — a crash mid-sale can't leave half-written data.

## What's next (not yet built, but the schema/architecture already supports it)

- Barcode scanner hardware integration (currently: type/search a barcode — a USB
  scanner that types + Enter will already work as-is)
- Batch & expiry tracking UI (schema already has batch_no/expiry_date on stock and
  purchase items — just needs a UI to enter/display them, useful for pharmacy/bakery)
- Data backup/restore over the network or to cloud storage (currently: local file only)
- Multi-currency, multi-language (Urdu) UI toggle
- Barcode label printing for products
- Held/parked sales (start a sale, pause it, resume later — for busy counters)

## Notes for WM Tech

This is meant to be a **product you can resell** to your local retail clients —
each install is fully self-contained (their data never leaves their machine), so
there's no server cost to you per customer. The multi-business design also means
one install can be sold to someone running more than one shop.
