// db/database.js
// Handles SQLite connection, schema initialization, and all data operations
// for WM POS ERP. Uses better-sqlite3 (synchronous, safe for Electron main process).

const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const permissions = require('./permissions');

function hashPassword(plain, salt) {
    salt = salt || crypto.randomBytes(16).toString('hex');
    const hash = crypto.pbkdf2Sync(plain, salt, 100000, 64, 'sha512').toString('hex');
    return `${salt}:${hash}`;
}

function verifyPassword(plain, stored) {
    const [salt, hash] = stored.split(':');
    const check = crypto.pbkdf2Sync(plain, salt, 100000, 64, 'sha512').toString('hex');
    return check === hash;
}

function getDbFilePath(userDataPath) {
    return path.join(userDataPath, 'wm-pos-erp.db');
}

function checkpoint(db) {
    db.pragma('wal_checkpoint(TRUNCATE)');
}

function openDatabase(userDataPath) {
    const dbPath = getDbFilePath(userDataPath);
    const db = new Database(dbPath);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');

    const schemaPath = path.join(__dirname, 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);

    runMigrations(db);
    seedDefaultAdmin(db);

    return db;
}

// Adds columns introduced after v1.0 to databases created by an older build.
// CREATE TABLE IF NOT EXISTS won't alter an existing table, so new columns
// have to be added explicitly. Safe to run on every launch.
function runMigrations(db) {
    const columnsOf = (table) => db.prepare(`PRAGMA table_info(${table})`).all().map(c => c.name);

    const businessCols = columnsOf('businesses');
    const businessAdditions = [
        ['logo_data', 'TEXT'],
        ['tagline', 'TEXT'],
        ['receipt_footer', 'TEXT'],
        ['brand_logo_data', 'TEXT'],
        ['brand_title', 'TEXT'],
        ['invoice_size', "TEXT DEFAULT 'ask'"],
    ];
    for (const [col, type] of businessAdditions) {
        if (!businessCols.includes(col)) {
            db.exec(`ALTER TABLE businesses ADD COLUMN ${col} ${type}`);
        }
    }

    const userCols = columnsOf('users');
    if (!userCols.includes('permissions')) {
        db.exec('ALTER TABLE users ADD COLUMN permissions TEXT');
    }

    const customerCols = columnsOf('customers');
    for (const [col, type] of [['guardian_name', 'TEXT'], ['cnic_no', 'TEXT'], ['active', 'INTEGER DEFAULT 1']]) {
        if (!customerCols.includes(col)) db.exec(`ALTER TABLE customers ADD COLUMN ${col} ${type}`);
    }

    const vsCols = columnsOf('vehicle_sales');
    if (!vsCols.includes('customer_id')) db.exec('ALTER TABLE vehicle_sales ADD COLUMN customer_id INTEGER');

    const saleItemCols = columnsOf('sale_items');
    for (const col of ['chassis_no', 'motor_no', 'motor_power']) {
        if (!saleItemCols.includes(col)) db.exec(`ALTER TABLE sale_items ADD COLUMN ${col} TEXT`);
    }

    const productCols = columnsOf('products');
    const productAdditions = [
        ['part_number', 'TEXT'],
        ['compatible_vehicles', 'TEXT'],
        ['color', 'TEXT'],
        ['model', 'TEXT'],
        ['is_vehicle', 'INTEGER DEFAULT 0'],
    ];
    for (const [col, type] of productAdditions) {
        if (!productCols.includes(col)) {
            db.exec(`ALTER TABLE products ADD COLUMN ${col} ${type}`);
        }
    }
}

// Create a default super_admin user (username: admin, password: admin123) on first run
function seedDefaultAdmin(db) {
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
    if (!existing) {
        db.prepare(`
            INSERT INTO users (business_id, username, password_hash, full_name, role, active)
            VALUES (NULL, 'admin', ?, 'Administrator', 'super_admin', 1)
        `).run(hashPassword('admin123'));
    }
}

// ===================== AUTH =====================

function authenticateUser(db, username, password) {
    const user = db.prepare('SELECT * FROM users WHERE username = ? AND active = 1').get(username);
    if (!user) return null;
    if (!verifyPassword(password, user.password_hash)) return null;
    delete user.password_hash;
    user.effective_permissions = permissions.effectivePermissions(user);
    return user;
}

function createUser(db, { business_id, username, password, full_name, role, permissions: perms }) {
    const uname = String(username || '').trim();
    if (!uname) throw new Error('Username zaroori hai');
    if (!password) throw new Error('Password zaroori hai');

    const clash = db.prepare('SELECT id FROM users WHERE username = ?').get(uname);
    if (clash) throw new Error('Ye username pehle se mojood hai');

    const stmt = db.prepare(`
        INSERT INTO users (business_id, username, password_hash, full_name, role, permissions, active)
        VALUES (?, ?, ?, ?, ?, ?, 1)
    `);
    const info = stmt.run(
        business_id || null, uname, hashPassword(password),
        full_name || '', role || 'cashier',
        Array.isArray(perms) ? JSON.stringify(perms) : null
    );
    return info.lastInsertRowid;
}

function listUsers(db, business_id) {
    const rows = db.prepare(`
        SELECT id, business_id, username, full_name, role, permissions, active
        FROM users WHERE business_id = ? OR business_id IS NULL ORDER BY id
    `).all(business_id);
    return rows.map(u => ({ ...u, effective_permissions: permissions.effectivePermissions(u) }));
}

function getUser(db, id) {
    const u = db.prepare('SELECT id, business_id, username, full_name, role, permissions, active FROM users WHERE id = ?').get(id);
    if (!u) return null;
    u.effective_permissions = permissions.effectivePermissions(u);
    return u;
}

function countActiveAdmins(db, excludeId) {
    const row = db.prepare(`
        SELECT COUNT(*) as c FROM users
        WHERE active = 1 AND role IN ('super_admin','admin') AND id != ?
    `).get(excludeId || -1);
    return row.c;
}

// Update a user's profile, role, permissions, active flag, or password.
// Guards against locking every administrator out of the app.
function updateUser(db, id, patch) {
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!existing) throw new Error('User nahi mila');

    const wouldDropAdmin =
        (patch.role !== undefined && ['super_admin', 'admin'].includes(existing.role) && !['super_admin', 'admin'].includes(patch.role))
        || (patch.active === false && ['super_admin', 'admin'].includes(existing.role));
    if (wouldDropAdmin && countActiveAdmins(db, id) === 0) {
        throw new Error('Kam az kam ek admin hona zaroori hai');
    }

    const sets = [];
    const params = { id };
    const simple = ['full_name', 'role', 'business_id'];
    for (const f of simple) {
        if (patch[f] !== undefined) { sets.push(`${f} = @${f}`); params[f] = patch[f]; }
    }
    if (patch.username !== undefined) {
        const uname = String(patch.username).trim();
        if (!uname) throw new Error('Username khali nahi ho sakta');
        const clash = db.prepare('SELECT id FROM users WHERE username = ? AND id != ?').get(uname, id);
        if (clash) throw new Error('Ye username pehle se mojood hai');
        sets.push('username = @username'); params.username = uname;
    }
    if (patch.active !== undefined) { sets.push('active = @active'); params.active = patch.active ? 1 : 0; }
    if (patch.permissions !== undefined) {
        sets.push('permissions = @permissions');
        params.permissions = Array.isArray(patch.permissions) ? JSON.stringify(patch.permissions) : null;
    }
    if (patch.password) {
        sets.push('password_hash = @password_hash');
        params.password_hash = hashPassword(patch.password);
    }

    if (sets.length) db.prepare(`UPDATE users SET ${sets.join(', ')} WHERE id = @id`).run(params);
    return getUser(db, id);
}

function deleteUser(db, id) {
    const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    if (!existing) throw new Error('User nahi mila');
    if (['super_admin', 'admin'].includes(existing.role) && countActiveAdmins(db, id) === 0) {
        throw new Error('Aakhri admin delete nahi ho sakta');
    }
    db.prepare('DELETE FROM users WHERE id = ?').run(id);
    return { deleted: true };
}

// ===================== BUSINESS / BRANCH =====================

function createBusiness(db, { name, business_type, address, phone, currency }) {
    const info = db.prepare(`
        INSERT INTO businesses (name, business_type, address, phone, currency)
        VALUES (?, ?, ?, ?, ?)
    `).run(name, business_type || 'general', address || '', phone || '', currency || 'PKR');
    const businessId = info.lastInsertRowid;

    // Every business gets a default main branch
    db.prepare(`INSERT INTO branches (business_id, name, is_main) VALUES (?, 'Main Branch', 1)`).run(businessId);

    // Default chart of accounts
    const defaultAccounts = [
        ['Cash in Hand', 'asset'],
        ['Bank Account', 'asset'],
        ['Sales Revenue', 'income'],
        ['Purchase Expense', 'expense'],
        ['General Expenses', 'expense'],
        ['Accounts Receivable', 'asset'],
        ['Accounts Payable', 'liability'],
    ];
    const acctStmt = db.prepare(`INSERT INTO accounts (business_id, name, account_type) VALUES (?, ?, ?)`);
    for (const [name2, type] of defaultAccounts) acctStmt.run(businessId, name2, type);

    return businessId;
}

function listBusinesses(db) {
    return db.prepare('SELECT * FROM businesses ORDER BY name').all();
}

function getBusiness(db, id) {
    return db.prepare('SELECT * FROM businesses WHERE id = ?').get(id);
}

// Update the branding/profile fields of a business. Only the fields present in
// `patch` are changed, so callers can update the logo alone without resending
// the rest of the profile.
function updateBusiness(db, id, patch) {
    const allowed = ['name', 'business_type', 'address', 'phone', 'logo_data', 'tagline', 'receipt_footer', 'currency',
        'brand_logo_data', 'brand_title', 'invoice_size'];
    if (patch.invoice_size !== undefined && !['a4', 'a5', 'thermal', 'ask'].includes(patch.invoice_size)) {
        throw new Error('Invalid invoice size');
    }
    const fields = allowed.filter(f => Object.prototype.hasOwnProperty.call(patch, f));
    if (!fields.length) return getBusiness(db, id);

    const setSql = fields.map(f => `${f} = @${f}`).join(', ');
    const params = { id };
    for (const f of fields) params[f] = patch[f];
    db.prepare(`UPDATE businesses SET ${setSql} WHERE id = @id`).run(params);
    return getBusiness(db, id);
}

function listBranches(db, business_id) {
    return db.prepare('SELECT * FROM branches WHERE business_id = ? ORDER BY is_main DESC, name').all(business_id);
}

function createBranch(db, { business_id, name, address, phone }) {
    return db.prepare(`INSERT INTO branches (business_id, name, address, phone) VALUES (?, ?, ?, ?)`)
        .run(business_id, name, address || '', phone || '').lastInsertRowid;
}

// ===================== CATEGORIES / PRODUCTS =====================

function createCategory(db, { business_id, name, parent_id }) {
    return db.prepare(`INSERT INTO categories (business_id, name, parent_id) VALUES (?, ?, ?)`)
        .run(business_id, name, parent_id || null).lastInsertRowid;
}

function listCategories(db, business_id) {
    return db.prepare('SELECT * FROM categories WHERE business_id = ? ORDER BY name').all(business_id);
}

function createProduct(db, p) {
    return db.prepare(`
        INSERT INTO products (business_id, category_id, name, sku, barcode, unit, cost_price, sale_price, tax_percent, reorder_level, expiry_tracked, part_number, compatible_vehicles, color, model, is_vehicle)
        VALUES (@business_id, @category_id, @name, @sku, @barcode, @unit, @cost_price, @sale_price, @tax_percent, @reorder_level, @expiry_tracked, @part_number, @compatible_vehicles, @color, @model, @is_vehicle)
    `).run({
        business_id: p.business_id,
        category_id: p.category_id || null,
        name: p.name,
        sku: p.sku || '',
        barcode: p.barcode || '',
        unit: p.unit || 'pcs',
        cost_price: p.cost_price || 0,
        sale_price: p.sale_price || 0,
        tax_percent: p.tax_percent || 0,
        reorder_level: p.reorder_level || 0,
        expiry_tracked: p.expiry_tracked ? 1 : 0,
        part_number: p.part_number || null,
        compatible_vehicles: p.compatible_vehicles || null,
        color: p.color || null,
        model: p.model || null,
        is_vehicle: p.is_vehicle ? 1 : 0,
    }).lastInsertRowid;
}

// Only the fields present in `p` change; anything the edit form didn't send
// (e.g. expiry_tracked) keeps its stored value instead of breaking the query.
function updateProduct(db, id, p) {
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
    if (!existing) throw new Error('Product nahi mila');
    const has = (k) => Object.prototype.hasOwnProperty.call(p, k);
    const pick = (k, fallback) => (has(k) ? p[k] : existing[k] ?? fallback);

    db.prepare(`
        UPDATE products SET category_id=@category_id, name=@name, sku=@sku, barcode=@barcode, unit=@unit,
            cost_price=@cost_price, sale_price=@sale_price, tax_percent=@tax_percent, reorder_level=@reorder_level,
            expiry_tracked=@expiry_tracked, part_number=@part_number, compatible_vehicles=@compatible_vehicles,
            color=@color, model=@model, is_vehicle=@is_vehicle, active=@active
        WHERE id=@id
    `).run({
        id,
        category_id: pick('category_id', null) || null,
        name: pick('name', ''),
        sku: pick('sku', ''),
        barcode: pick('barcode', ''),
        unit: pick('unit', 'pcs') || 'pcs',
        cost_price: Number(pick('cost_price', 0)) || 0,
        sale_price: Number(pick('sale_price', 0)) || 0,
        tax_percent: Number(pick('tax_percent', 0)) || 0,
        reorder_level: Number(pick('reorder_level', 0)) || 0,
        expiry_tracked: pick('expiry_tracked', 0) ? 1 : 0,
        part_number: pick('part_number', null) || null,
        compatible_vehicles: pick('compatible_vehicles', null) || null,
        color: pick('color', null) || null,
        model: pick('model', null) || null,
        is_vehicle: pick('is_vehicle', 0) ? 1 : 0,
        active: has('active') ? (p.active === false || p.active === 0 ? 0 : 1) : existing.active,
    });
}

function deleteProduct(db, id) {
    db.prepare('UPDATE products SET active = 0 WHERE id = ?').run(id);
}

function listProducts(db, business_id, opts = {}) {
    let sql = 'SELECT * FROM products WHERE business_id = ?';
    const params = [business_id];
    if (!opts.includeInactive) sql += ' AND active = 1';
    if (opts.search) {
        sql += ' AND (name LIKE ? OR barcode LIKE ? OR sku LIKE ?)';
        const s = `%${opts.search}%`;
        params.push(s, s, s);
    }
    sql += ' ORDER BY name';
    return db.prepare(sql).all(...params);
}

function findProductByBarcode(db, business_id, barcode) {
    return db.prepare('SELECT * FROM products WHERE business_id = ? AND barcode = ? AND active = 1').get(business_id, barcode);
}

// ===================== STOCK =====================

function getStock(db, branch_id, product_id) {
    const rows = db.prepare('SELECT * FROM stock WHERE branch_id = ? AND product_id = ?').all(branch_id, product_id);
    return rows.reduce((sum, r) => sum + r.quantity, 0);
}

function listStockForBranch(db, branch_id) {
    return db.prepare(`
        SELECT p.id as product_id, p.name, p.unit, p.reorder_level, p.sale_price,
               COALESCE(SUM(s.quantity), 0) as quantity
        FROM products p
        LEFT JOIN stock s ON s.product_id = p.id AND s.branch_id = ?
        WHERE p.active = 1
          AND p.business_id = (SELECT business_id FROM branches WHERE id = ?)
        GROUP BY p.id
        ORDER BY p.name
    `).all(branch_id, branch_id);
}

function listLowStock(db, branch_id) {
    return listStockForBranch(db, branch_id).filter(r => r.quantity <= r.reorder_level);
}

// Internal: adjust a product's stock at a branch (positive or negative delta)
function _applyStockDelta(db, branch_id, product_id, delta, batch_no = null, expiry_date = null) {
    const existing = db.prepare('SELECT * FROM stock WHERE branch_id = ? AND product_id = ? AND (batch_no IS ? OR batch_no = ?)')
        .get(branch_id, product_id, batch_no, batch_no);
    if (existing) {
        db.prepare("UPDATE stock SET quantity = quantity + ?, updated_at = datetime('now') WHERE id = ?")
            .run(delta, existing.id);
    } else {
        db.prepare('INSERT INTO stock (branch_id, product_id, quantity, batch_no, expiry_date) VALUES (?, ?, ?, ?, ?)')
            .run(branch_id, product_id, delta, batch_no, expiry_date);
    }
}

function manualStockAdjustment(db, { business_id, branch_id, product_id, quantity_change, reason, user_id }) {
    const tx = db.transaction(() => {
        _applyStockDelta(db, branch_id, product_id, quantity_change);
        db.prepare(`
            INSERT INTO stock_adjustments (business_id, branch_id, product_id, quantity_change, reason, user_id)
            VALUES (?, ?, ?, ?, ?, ?)
        `).run(business_id, branch_id, product_id, quantity_change, reason || 'manual', user_id || null);
    });
    tx();
}

// ===================== LEDGER / ACCOUNTS =====================

function listAccounts(db, business_id) {
    return db.prepare('SELECT * FROM accounts WHERE business_id = ? ORDER BY account_type, name').all(business_id);
}

function getAccountByName(db, business_id, name) {
    return db.prepare('SELECT * FROM accounts WHERE business_id = ? AND name = ?').get(business_id, name);
}

function postLedgerEntry(db, { business_id, account_id, description, debit, credit, reference_type, reference_id, entry_date }) {
    db.prepare(`
        INSERT INTO ledger_entries (business_id, account_id, entry_date, description, debit, credit, reference_type, reference_id)
        VALUES (?, ?, COALESCE(?, datetime('now')), ?, ?, ?, ?, ?)
    `).run(business_id, account_id, entry_date || null, description || '', debit || 0, credit || 0, reference_type || 'manual', reference_id || null);
}

function getAccountBalance(db, account_id) {
    const row = db.prepare(`
        SELECT COALESCE(SUM(debit),0) as total_debit, COALESCE(SUM(credit),0) as total_credit
        FROM ledger_entries WHERE account_id = ?
    `).get(account_id);
    const acct = db.prepare('SELECT * FROM accounts WHERE id = ?').get(account_id);
    const base = acct.opening_balance || 0;
    // Asset/Expense accounts increase with debit; Liability/Income/Equity increase with credit
    if (acct.account_type === 'asset' || acct.account_type === 'expense') {
        return base + row.total_debit - row.total_credit;
    }
    return base + row.total_credit - row.total_debit;
}

function getLedgerEntries(db, business_id, account_id, from, to) {
    let sql = 'SELECT * FROM ledger_entries WHERE business_id = ?';
    const params = [business_id];
    if (account_id) { sql += ' AND account_id = ?'; params.push(account_id); }
    if (from) { sql += ' AND entry_date >= ?'; params.push(from); }
    if (to) { sql += ' AND entry_date <= ?'; params.push(to); }
    sql += ' ORDER BY entry_date DESC, id DESC';
    return db.prepare(sql).all(...params);
}

// ===================== SUPPLIERS / PURCHASING =====================

function createSupplier(db, { business_id, name, phone, address, opening_balance }) {
    return db.prepare(`INSERT INTO suppliers (business_id, name, phone, address, opening_balance) VALUES (?, ?, ?, ?, ?)`)
        .run(business_id, name, phone || '', address || '', opening_balance || 0).lastInsertRowid;
}

function listSuppliers(db, business_id) {
    return db.prepare('SELECT * FROM suppliers WHERE business_id = ? ORDER BY name').all(business_id);
}

// Create a purchase with items. Increases stock, records payable/cash ledger entries.
function createPurchase(db, { business_id, branch_id, supplier_id, invoice_no, items, discount, tax, paid_amount, user_id, payment_account_name }) {
    const tx = db.transaction(() => {
        const subtotal = items.reduce((s, it) => s + it.quantity * it.cost_price, 0);
        const total_amount = subtotal - (discount || 0) + (tax || 0);

        const info = db.prepare(`
            INSERT INTO purchases (business_id, branch_id, supplier_id, invoice_no, subtotal, discount, tax, total_amount, paid_amount, status, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'received', ?)
        `).run(business_id, branch_id, supplier_id || null, invoice_no || '', subtotal, discount || 0, tax || 0, total_amount, paid_amount || 0, user_id || null);

        const purchaseId = info.lastInsertRowid;
        const itemStmt = db.prepare(`
            INSERT INTO purchase_items (purchase_id, product_id, quantity, cost_price, batch_no, expiry_date, total)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `);
        for (const it of items) {
            itemStmt.run(purchaseId, it.product_id, it.quantity, it.cost_price, it.batch_no || null, it.expiry_date || null, it.quantity * it.cost_price);
            _applyStockDelta(db, branch_id, it.product_id, it.quantity, it.batch_no || null, it.expiry_date || null);
        }

        // Ledger: Debit Purchase Expense (or Inventory), Credit Cash/Bank (paid) and Accounts Payable (unpaid)
        const purchaseExpenseAcct = getAccountByName(db, business_id, 'Purchase Expense');
        const payableAcct = getAccountByName(db, business_id, 'Accounts Payable');
        const cashAcct = getAccountByName(db, business_id, payment_account_name || 'Cash in Hand');

        if (purchaseExpenseAcct) {
            postLedgerEntry(db, { business_id, account_id: purchaseExpenseAcct.id, description: `Purchase #${purchaseId}`, debit: total_amount, reference_type: 'purchase', reference_id: purchaseId });
        }
        const paid = paid_amount || 0;
        if (paid > 0 && cashAcct) {
            postLedgerEntry(db, { business_id, account_id: cashAcct.id, description: `Purchase #${purchaseId} payment`, credit: paid, reference_type: 'purchase', reference_id: purchaseId });
        }
        const unpaid = total_amount - paid;
        if (unpaid > 0 && payableAcct) {
            postLedgerEntry(db, { business_id, account_id: payableAcct.id, description: `Purchase #${purchaseId} balance`, credit: unpaid, reference_type: 'purchase', reference_id: purchaseId });
        }

        return purchaseId;
    });
    return tx();
}

function listPurchases(db, business_id, branch_id) {
    let sql = 'SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id WHERE p.business_id = ?';
    const params = [business_id];
    if (branch_id) { sql += ' AND p.branch_id = ?'; params.push(branch_id); }
    sql += ' ORDER BY p.purchase_date DESC';
    return db.prepare(sql).all(...params);
}

function getPurchaseItems(db, purchase_id) {
    return db.prepare(`
        SELECT pi.*, p.name as product_name FROM purchase_items pi
        JOIN products p ON p.id = pi.product_id WHERE pi.purchase_id = ?
    `).all(purchase_id);
}

// ===================== CUSTOMERS / SALES (POS) =====================

function createCustomer(db, { business_id, name, guardian_name, cnic_no, phone, address, opening_balance }) {
    const n = String(name || '').trim() || 'Walk-in Customer';
    const opening = Number(opening_balance) || 0;
    const id = db.prepare(`
        INSERT INTO customers (business_id, name, guardian_name, cnic_no, phone, address, opening_balance)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(business_id, n, guardian_name || '', cnic_no || '', phone || '', address || '', opening).lastInsertRowid;
    if (opening) _postOpeningBalanceDelta(db, business_id, id, n, opening);
    return id;
}

// An opening balance is money the customer already owed before being entered,
// so it belongs in Accounts Receivable. Changes are posted as the difference.
function _postOpeningBalanceDelta(db, business_id, customer_id, name, delta) {
    const receivableAcct = getAccountByName(db, business_id, 'Accounts Receivable');
    if (!receivableAcct || !delta) return;
    postLedgerEntry(db, {
        business_id, account_id: receivableAcct.id,
        description: `Opening balance: ${name}`,
        debit: delta > 0 ? delta : 0, credit: delta < 0 ? -delta : 0,
        reference_type: 'customer_opening', reference_id: customer_id,
    });
}

function updateCustomer(db, id, patch) {
    const allowed = ['name', 'guardian_name', 'cnic_no', 'phone', 'address', 'opening_balance', 'active'];
    const fields = allowed.filter(f => Object.prototype.hasOwnProperty.call(patch, f));
    if (fields.length) {
        const params = { id };
        for (const f of fields) params[f] = patch[f];
        if ('name' in params && !String(params.name || '').trim()) throw new Error('Customer ka naam zaroori hai');
        if ('active' in params) params.active = params.active ? 1 : 0;
        if ('opening_balance' in params) params.opening_balance = Number(params.opening_balance) || 0;
        const before = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);
        if (!before) throw new Error('Customer nahi mila');
        db.prepare(`UPDATE customers SET ${fields.map(f => `${f} = @${f}`).join(', ')} WHERE id = @id`).run(params);
        if ('opening_balance' in params) {
            const delta = params.opening_balance - (before.opening_balance || 0);
            if (delta) _postOpeningBalanceDelta(db, before.business_id, id, params.name || before.name, delta);
        }
    }
    return getCustomer(db, id);
}

// What a customer currently owes: opening balance + unpaid part of every
// counter sale, delivered service job and vehicle sale, minus payments received.
function customerBalance(db, customer_id) {
    const c = db.prepare('SELECT opening_balance FROM customers WHERE id = ?').get(customer_id);
    if (!c) return 0;
    const q = (sql) => db.prepare(sql).get(customer_id).t;
    const salesDue = q(`SELECT COALESCE(SUM(total - paid_amount),0) as t FROM sales WHERE customer_id = ? AND status = 'completed'`);
    const jobsDue = q(`SELECT COALESCE(SUM(total - paid_amount),0) as t FROM service_jobs WHERE customer_id = ? AND status = 'delivered'`);
    const vehiclesDue = q(`SELECT COALESCE(SUM(amount - paid_amount),0) as t FROM vehicle_sales WHERE customer_id = ? AND status = 'completed'`);
    const paid = q(`SELECT COALESCE(SUM(amount),0) as t FROM customer_payments WHERE customer_id = ?`);
    return (c.opening_balance || 0) + salesDue + jobsDue + vehiclesDue - paid;
}

function getCustomer(db, id) {
    const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(id);
    if (c) c.balance = customerBalance(db, id);
    return c;
}

function listCustomers(db, business_id, opts = {}) {
    let sql = 'SELECT * FROM customers WHERE business_id = ?';
    const params = [business_id];
    if (!opts.includeInactive) sql += ' AND COALESCE(active, 1) = 1';
    if (opts.search) {
        sql += ' AND (name LIKE ? OR phone LIKE ? OR cnic_no LIKE ?)';
        const s = `%${opts.search}%`;
        params.push(s, s, s);
    }
    sql += ' ORDER BY name';
    return db.prepare(sql).all(...params).map(c => ({ ...c, balance: customerBalance(db, c.id) }));
}

// Every bill and payment for one customer, oldest first, with a running balance.
function customerStatement(db, customer_id) {
    const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(customer_id);
    if (!c) throw new Error('Customer nahi mila');
    const rows = db.prepare(`
        SELECT sale_date as date, 'Sale' as type, invoice_no as ref, total as billed, paid_amount as paid
            FROM sales WHERE customer_id = ? AND status = 'completed'
        UNION ALL
        SELECT closed_date, 'Service Job', job_no, total, paid_amount
            FROM service_jobs WHERE customer_id = ? AND status = 'delivered'
        UNION ALL
        SELECT sale_date, 'Vehicle Sale', invoice_no, amount, paid_amount
            FROM vehicle_sales WHERE customer_id = ? AND status = 'completed'
        UNION ALL
        SELECT payment_date, 'Payment Received', COALESCE(note, ''), 0, amount
            FROM customer_payments WHERE customer_id = ?
        ORDER BY 1
    `).all(customer_id, customer_id, customer_id, customer_id);

    let running = c.opening_balance || 0;
    const entries = rows.map(r => {
        running += (r.billed || 0) - (r.paid || 0);
        return { ...r, balance: running };
    });
    return { customer: { ...c, balance: running }, openingBalance: c.opening_balance || 0, entries };
}

// Record money received from a customer. Moves it out of Accounts Receivable
// into Cash/Bank so the books agree with the customer's reduced balance.
function receiveCustomerPayment(db, { business_id, customer_id, amount, payment_method, note, user_id }) {
    const amt = Number(amount) || 0;
    if (amt <= 0) throw new Error('Raqam zero se zyada honi chahiye');
    const tx = db.transaction(() => {
        const cust = db.prepare('SELECT * FROM customers WHERE id = ?').get(customer_id);
        if (!cust) throw new Error('Customer nahi mila');
        const info = db.prepare(`
            INSERT INTO customer_payments (business_id, customer_id, amount, payment_method, note, user_id)
            VALUES (?, ?, ?, ?, ?, ?)
        `).run(business_id, customer_id, amt, payment_method || 'cash', note || '', user_id || null);
        const payId = info.lastInsertRowid;

        const cashAcct = getAccountByName(db, business_id, paymentAccountForMethod(payment_method));
        const receivableAcct = getAccountByName(db, business_id, 'Accounts Receivable');
        const label = `Payment from ${cust.name}`;
        if (cashAcct) postLedgerEntry(db, { business_id, account_id: cashAcct.id, description: label, debit: amt, reference_type: 'customer_payment', reference_id: payId });
        if (receivableAcct) postLedgerEntry(db, { business_id, account_id: receivableAcct.id, description: label, credit: amt, reference_type: 'customer_payment', reference_id: payId });
        return payId;
    });
    return tx();
}

function generateInvoiceNo(db, business_id) {
    const row = db.prepare('SELECT COUNT(*) as c FROM sales WHERE business_id = ?').get(business_id);
    return `INV-${String(business_id).padStart(3, '0')}-${String(row.c + 1).padStart(6, '0')}`;
}

// Create a sale with items. Decreases stock (FIFO across batches), records ledger + customer balance.
function createSale(db, { business_id, branch_id, customer_id, items, discount, tax, paid_amount, payment_method, user_id }) {
    const tx = db.transaction(() => {
        const subtotal = items.reduce((s, it) => s + it.quantity * it.unit_price - (it.discount || 0), 0);
        const total = subtotal - (discount || 0) + (tax || 0);
        const invoice_no = generateInvoiceNo(db, business_id);

        const info = db.prepare(`
            INSERT INTO sales (business_id, branch_id, customer_id, invoice_no, subtotal, discount, tax, total, paid_amount, payment_method, status, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', ?)
        `).run(business_id, branch_id, customer_id || null, invoice_no, subtotal, discount || 0, tax || 0, total, paid_amount || 0, payment_method || 'cash', user_id || null);

        const saleId = info.lastInsertRowid;
        const itemStmt = db.prepare(`
            INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, discount, total, chassis_no, motor_no, motor_power)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        for (const it of items) {
            itemStmt.run(saleId, it.product_id, it.quantity, it.unit_price, it.discount || 0, it.quantity * it.unit_price - (it.discount || 0),
                it.chassis_no || null, it.motor_no || null, it.motor_power || null);
            _applyStockDelta(db, branch_id, it.product_id, -Math.abs(it.quantity));
        }

        // Ledger: Debit Cash/Receivable, Credit Sales Revenue
        const salesAcct = getAccountByName(db, business_id, 'Sales Revenue');
        const cashAcct = getAccountByName(db, business_id, paymentAccountForMethod(payment_method));
        const receivableAcct = getAccountByName(db, business_id, 'Accounts Receivable');

        if (salesAcct) {
            postLedgerEntry(db, { business_id, account_id: salesAcct.id, description: `Sale ${invoice_no}`, credit: total, reference_type: 'sale', reference_id: saleId });
        }
        const paid = paid_amount || 0;
        if (paid > 0 && cashAcct) {
            postLedgerEntry(db, { business_id, account_id: cashAcct.id, description: `Sale ${invoice_no} payment`, debit: paid, reference_type: 'sale', reference_id: saleId });
        }
        const unpaid = total - paid;
        if (unpaid > 0 && receivableAcct) {
            postLedgerEntry(db, { business_id, account_id: receivableAcct.id, description: `Sale ${invoice_no} balance`, debit: unpaid, reference_type: 'sale', reference_id: saleId });
        }

        return { saleId, invoice_no, total };
    });
    return tx();
}

function paymentAccountForMethod(method) {
    if (method === 'bank' || method === 'card' || method === 'online') return 'Bank Account';
    return 'Cash in Hand';
}

function listSales(db, business_id, branch_id, from, to) {
    let sql = `
        SELECT s.*, c.name as customer_name FROM sales s
        LEFT JOIN customers c ON c.id = s.customer_id
        WHERE s.business_id = ?`;
    const params = [business_id];
    if (branch_id) { sql += ' AND s.branch_id = ?'; params.push(branch_id); }
    if (from) { sql += ' AND s.sale_date >= ?'; params.push(from); }
    if (to) { sql += ' AND s.sale_date <= ?'; params.push(to); }
    sql += ' ORDER BY s.sale_date DESC';
    return db.prepare(sql).all(...params);
}

function getSaleItems(db, sale_id) {
    return db.prepare(`
        SELECT si.*, p.name as product_name, p.color, p.model, p.is_vehicle FROM sale_items si
        JOIN products p ON p.id = si.product_id WHERE si.sale_id = ?
    `).all(sale_id);
}

function getSale(db, sale_id) {
    return db.prepare('SELECT * FROM sales WHERE id = ?').get(sale_id);
}

// Refund a completed sale: restores stock, reverses the original ledger entries,
// and marks the sale as refunded. Cannot refund an already-refunded sale.
function refundSale(db, { sale_id, business_id, branch_id, user_id, reason }) {
    const tx = db.transaction(() => {
        const sale = db.prepare('SELECT * FROM sales WHERE id = ?').get(sale_id);
        if (!sale) throw new Error('Sale not found');
        if (sale.status === 'refunded') throw new Error('Sale is already refunded');

        const items = getSaleItems(db, sale_id);
        for (const it of items) {
            _applyStockDelta(db, branch_id || sale.branch_id, it.product_id, Math.abs(it.quantity));
        }

        // Reverse the original ledger postings for this sale (opposite debit/credit)
        const originalEntries = db.prepare(`SELECT * FROM ledger_entries WHERE reference_type = 'sale' AND reference_id = ?`).all(sale_id);
        for (const entry of originalEntries) {
            postLedgerEntry(db, {
                business_id, account_id: entry.account_id,
                description: `Refund of Sale ${sale.invoice_no}` + (reason ? ` (${reason})` : ''),
                debit: entry.credit, credit: entry.debit,
                reference_type: 'refund', reference_id: sale_id,
            });
        }

        db.prepare(`UPDATE sales SET status = 'refunded' WHERE id = ?`).run(sale_id);
    });
    tx();
}

// ===================== EXPENSES =====================

function createExpense(db, { business_id, branch_id, category, description, amount, user_id, payment_account_name }) {
    const tx = db.transaction(() => {
        const info = db.prepare(`
            INSERT INTO expenses (business_id, branch_id, category, description, amount, user_id)
            VALUES (?, ?, ?, ?, ?, ?)
        `).run(business_id, branch_id || null, category || 'general', description || '', amount, user_id || null);

        const expAcct = getAccountByName(db, business_id, 'General Expenses');
        const cashAcct = getAccountByName(db, business_id, payment_account_name || 'Cash in Hand');
        if (expAcct) postLedgerEntry(db, { business_id, account_id: expAcct.id, description: description || category, debit: amount, reference_type: 'expense', reference_id: info.lastInsertRowid });
        if (cashAcct) postLedgerEntry(db, { business_id, account_id: cashAcct.id, description: description || category, credit: amount, reference_type: 'expense', reference_id: info.lastInsertRowid });

        return info.lastInsertRowid;
    });
    return tx();
}

function listExpenses(db, business_id, from, to) {
    let sql = 'SELECT * FROM expenses WHERE business_id = ?';
    const params = [business_id];
    if (from) { sql += ' AND expense_date >= ?'; params.push(from); }
    if (to) { sql += ' AND expense_date <= ?'; params.push(to); }
    sql += ' ORDER BY expense_date DESC';
    return db.prepare(sql).all(...params);
}

// ===================== REPORTS =====================

// Invoice count / totals / amount due across every kind of billed sale:
// counter (POS) sales, delivered service jobs, and whole-vehicle sales.
function salesSummary(db, business_id, from, to) {
    const row = db.prepare(`
        SELECT COUNT(*) as invoice_count, COALESCE(SUM(total),0) as total_sales,
               COALESCE(SUM(paid),0) as total_paid, COALESCE(SUM(total - paid),0) as total_due
        FROM (
            SELECT total, paid_amount as paid FROM sales
                WHERE business_id = ? AND sale_date >= ? AND sale_date <= ? AND status = 'completed'
            UNION ALL
            SELECT total, paid_amount as paid FROM service_jobs
                WHERE business_id = ? AND closed_date >= ? AND closed_date <= ? AND status = 'delivered'
            UNION ALL
            SELECT amount as total, paid_amount as paid FROM vehicle_sales
                WHERE business_id = ? AND sale_date >= ? AND sale_date <= ? AND status = 'completed'
        )
    `).get(business_id, from, to, business_id, from, to, business_id, from, to);
    return row;
}

function profitLossReport(db, business_id, from, to) {
    // Counter (POS) sales
    const retailRevenue = db.prepare(`SELECT COALESCE(SUM(total),0) as t FROM sales WHERE business_id=? AND sale_date>=? AND sale_date<=? AND status='completed'`).get(business_id, from, to).t;
    const retailCogs = db.prepare(`
        SELECT COALESCE(SUM(si.quantity * p.cost_price),0) as t
        FROM sale_items si
        JOIN sales s ON s.id = si.sale_id
        JOIN products p ON p.id = si.product_id
        WHERE s.business_id=? AND s.sale_date>=? AND s.sale_date<=? AND s.status='completed'
    `).get(business_id, from, to).t;

    // Automobile service jobs: revenue is the billed total; cost is the parts used
    // (labor lines have no purchase cost)
    const serviceRevenue = db.prepare(`SELECT COALESCE(SUM(total),0) as t FROM service_jobs WHERE business_id=? AND status='delivered' AND closed_date>=? AND closed_date<=?`).get(business_id, from, to).t;
    const serviceCogs = db.prepare(`
        SELECT COALESCE(SUM(sji.quantity * p.cost_price),0) as t
        FROM service_job_items sji
        JOIN service_jobs sj ON sj.id = sji.job_id
        JOIN products p ON p.id = sji.product_id
        WHERE sj.business_id=? AND sj.status='delivered' AND sj.closed_date>=? AND sj.closed_date<=?
    `).get(business_id, from, to).t;

    // Automobile whole-vehicle sales: cost is the unit's purchase price
    const vehicleRevenue = db.prepare(`SELECT COALESCE(SUM(amount),0) as t FROM vehicle_sales WHERE business_id=? AND status='completed' AND sale_date>=? AND sale_date<=?`).get(business_id, from, to).t;
    const vehicleCogs = db.prepare(`
        SELECT COALESCE(SUM(vu.cost_price),0) as t
        FROM vehicle_sales vs JOIN vehicle_units vu ON vu.id = vs.vehicle_unit_id
        WHERE vs.business_id=? AND vs.status='completed' AND vs.sale_date>=? AND vs.sale_date<=?
    `).get(business_id, from, to).t;

    const salesTotal = retailRevenue + serviceRevenue + vehicleRevenue;
    const cogs = retailCogs + serviceCogs + vehicleCogs;

    const expensesTotal = db.prepare(`SELECT COALESCE(SUM(amount),0) as t FROM expenses WHERE business_id=? AND expense_date>=? AND expense_date<=?`).get(business_id, from, to).t;

    const grossProfit = salesTotal - cogs;
    const netProfit = grossProfit - expensesTotal;

    return {
        salesTotal, cogs, grossProfit, expensesTotal, netProfit,
        breakdown: { retailRevenue, serviceRevenue, vehicleRevenue },
    };
}

// Bike/car sales totals for a date range (used by Dashboard and Reports).
// Covers both ways a vehicle can be sold: units from the Vehicle Stock tab,
// and inventory products marked "bike/car" sold through POS.
function vehicleSalesSummary(db, business_id, from, to) {
    const units = db.prepare(`
        SELECT COUNT(*) as unitsSold, COALESCE(SUM(vs.amount),0) as revenue,
               COALESCE(SUM(vs.paid_amount),0) as paid, COALESCE(SUM(vu.cost_price),0) as cost
        FROM vehicle_sales vs JOIN vehicle_units vu ON vu.id = vs.vehicle_unit_id
        WHERE vs.business_id=? AND vs.status='completed' AND vs.sale_date>=? AND vs.sale_date<=?
    `).get(business_id, from, to);

    // POS lines for vehicle products. The amount still owed is shared across
    // a sale's lines in proportion to their value.
    const pos = db.prepare(`
        SELECT COALESCE(SUM(si.quantity),0) as unitsSold, COALESCE(SUM(si.total),0) as revenue,
               COALESCE(SUM(si.quantity * p.cost_price),0) as cost,
               COALESCE(SUM(CASE WHEN s.subtotal > 0 THEN si.total * (s.total - s.paid_amount) / s.subtotal ELSE 0 END),0) as due
        FROM sale_items si
        JOIN sales s ON s.id = si.sale_id
        JOIN products p ON p.id = si.product_id
        WHERE s.business_id=? AND s.status='completed' AND s.sale_date>=? AND s.sale_date<=? AND p.is_vehicle = 1
    `).get(business_id, from, to);

    const unitsInStock = db.prepare(`SELECT COUNT(*) as c FROM vehicle_units WHERE business_id=? AND status='in_stock'`).get(business_id).c;
    const productsInStock = db.prepare(`
        SELECT COALESCE(SUM(st.quantity),0) as c FROM stock st JOIN products p ON p.id = st.product_id
        WHERE p.business_id=? AND p.is_vehicle = 1 AND p.active = 1
    `).get(business_id).c;

    const unitsSold = units.unitsSold + pos.unitsSold;
    const revenue = units.revenue + pos.revenue;
    const cost = units.cost + pos.cost;
    const due = (units.revenue - units.paid) + Math.round(pos.due);
    return { unitsSold, revenue, paid: revenue - due, cost, due, profit: revenue - cost, inStock: unitsInStock + productsInStock };
}

function topSellingProducts(db, business_id, from, to, limit = 10) {
    return db.prepare(`
        SELECT p.name, SUM(si.quantity) as qty_sold, SUM(si.total) as revenue
        FROM sale_items si
        JOIN sales s ON s.id = si.sale_id
        JOIN products p ON p.id = si.product_id
        WHERE s.business_id = ? AND s.sale_date >= ? AND s.sale_date <= ? AND s.status = 'completed'
        GROUP BY p.id ORDER BY qty_sold DESC LIMIT ?
    `).all(business_id, from, to, limit);
}

// ===================== AUTOMOBILE: VEHICLES / MECHANICS / SERVICE JOBS =====================

function createVehicle(db, { business_id, customer_id, registration_no, make, model, year, color, notes }) {
    const reg = String(registration_no || '').trim();
    if (!reg) throw new Error('Registration number zaroori hai');
    return db.prepare(`
        INSERT INTO vehicles (business_id, customer_id, registration_no, make, model, year, color, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(business_id, customer_id || null, reg, make || '', model || '', year || '', color || '', notes || '').lastInsertRowid;
}

function updateVehicle(db, id, patch) {
    const allowed = ['customer_id', 'registration_no', 'make', 'model', 'year', 'color', 'notes'];
    const fields = allowed.filter(f => Object.prototype.hasOwnProperty.call(patch, f));
    if (!fields.length) return db.prepare('SELECT * FROM vehicles WHERE id = ?').get(id);
    const setSql = fields.map(f => `${f} = @${f}`).join(', ');
    db.prepare(`UPDATE vehicles SET ${setSql} WHERE id = @id`).run({ id, ...patch });
    return db.prepare('SELECT * FROM vehicles WHERE id = ?').get(id);
}

function listVehicles(db, business_id, search) {
    let sql = `
        SELECT v.*, c.name as customer_name, c.phone as customer_phone
        FROM vehicles v LEFT JOIN customers c ON c.id = v.customer_id
        WHERE v.business_id = ?`;
    const params = [business_id];
    if (search) {
        sql += ` AND (v.registration_no LIKE ? OR v.make LIKE ? OR v.model LIKE ?)`;
        const s = `%${search}%`;
        params.push(s, s, s);
    }
    sql += ' ORDER BY v.created_at DESC';
    return db.prepare(sql).all(...params);
}

function getVehicle(db, id) {
    return db.prepare(`
        SELECT v.*, c.name as customer_name, c.phone as customer_phone
        FROM vehicles v LEFT JOIN customers c ON c.id = v.customer_id WHERE v.id = ?
    `).get(id);
}

function createMechanic(db, { business_id, name, phone, specialty }) {
    const n = String(name || '').trim();
    if (!n) throw new Error('Mechanic ka naam zaroori hai');
    return db.prepare(`INSERT INTO mechanics (business_id, name, phone, specialty) VALUES (?, ?, ?, ?)`)
        .run(business_id, n, phone || '', specialty || '').lastInsertRowid;
}

function listMechanics(db, business_id, includeInactive) {
    let sql = 'SELECT * FROM mechanics WHERE business_id = ?';
    if (!includeInactive) sql += ' AND active = 1';
    sql += ' ORDER BY name';
    return db.prepare(sql).all(business_id);
}

function updateMechanic(db, id, patch) {
    const allowed = ['name', 'phone', 'specialty', 'active'];
    const fields = allowed.filter(f => Object.prototype.hasOwnProperty.call(patch, f));
    if (!fields.length) return db.prepare('SELECT * FROM mechanics WHERE id = ?').get(id);
    const setSql = fields.map(f => `${f} = @${f}`).join(', ');
    const params = { id, ...patch };
    if ('active' in params) params.active = params.active ? 1 : 0;
    db.prepare(`UPDATE mechanics SET ${setSql} WHERE id = @id`).run(params);
    return db.prepare('SELECT * FROM mechanics WHERE id = ?').get(id);
}

function generateJobNo(db, business_id) {
    const row = db.prepare('SELECT COUNT(*) as c FROM service_jobs WHERE business_id = ?').get(business_id);
    return `JOB-${String(business_id).padStart(3, '0')}-${String(row.c + 1).padStart(5, '0')}`;
}

// Open a new service job. No stock or ledger impact yet - that happens once
// the job is finalized (status -> delivered).
function createServiceJob(db, { business_id, branch_id, vehicle_id, customer_id, mechanic_id, complaint, odometer_reading, user_id }) {
    if (!vehicle_id) throw new Error('Vehicle select karna zaroori hai');
    const job_no = generateJobNo(db, business_id);
    const info = db.prepare(`
        INSERT INTO service_jobs (business_id, branch_id, vehicle_id, customer_id, mechanic_id, job_no, status, complaint, odometer_reading, user_id)
        VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)
    `).run(business_id, branch_id, vehicle_id, customer_id || null, mechanic_id || null, job_no, complaint || '', odometer_reading || '', user_id || null);
    return info.lastInsertRowid;
}

function getServiceJob(db, id) {
    return db.prepare(`
        SELECT sj.*, v.registration_no, v.make, v.model, v.year as vehicle_year,
               c.name as customer_name, c.phone as customer_phone,
               m.name as mechanic_name
        FROM service_jobs sj
        JOIN vehicles v ON v.id = sj.vehicle_id
        LEFT JOIN customers c ON c.id = sj.customer_id
        LEFT JOIN mechanics m ON m.id = sj.mechanic_id
        WHERE sj.id = ?
    `).get(id);
}

function getServiceJobItems(db, job_id) {
    return db.prepare(`
        SELECT sji.*, p.name as product_name
        FROM service_job_items sji
        LEFT JOIN products p ON p.id = sji.product_id
        WHERE sji.job_id = ? ORDER BY sji.id
    `).all(job_id);
}

function listServiceJobs(db, business_id, branch_id, status) {
    let sql = `
        SELECT sj.*, v.registration_no, v.make, v.model, c.name as customer_name, m.name as mechanic_name
        FROM service_jobs sj
        JOIN vehicles v ON v.id = sj.vehicle_id
        LEFT JOIN customers c ON c.id = sj.customer_id
        LEFT JOIN mechanics m ON m.id = sj.mechanic_id
        WHERE sj.business_id = ?`;
    const params = [business_id];
    if (branch_id) { sql += ' AND sj.branch_id = ?'; params.push(branch_id); }
    if (status) { sql += ' AND sj.status = ?'; params.push(status); }
    sql += ' ORDER BY sj.opened_date DESC';
    return db.prepare(sql).all(...params);
}

function _assertJobOpen(job) {
    if (!job) throw new Error('Job nahi mili');
    if (job.status === 'delivered' || job.status === 'cancelled') {
        throw new Error('Ye job band ho chuki hai, edit nahi ho sakti');
    }
}

function _recalcJobTotals(db, job_id) {
    const items = getServiceJobItems(db, job_id);
    const subtotal = items.reduce((s, it) => s + it.total, 0);
    const job = db.prepare('SELECT * FROM service_jobs WHERE id = ?').get(job_id);
    const total = Math.max(0, subtotal - (job.discount || 0) + (job.tax || 0));
    db.prepare('UPDATE service_jobs SET subtotal = ?, total = ? WHERE id = ?').run(subtotal, total, job_id);
}

function addServiceJobItem(db, { job_id, product_id, description, quantity, unit_price }) {
    const job = db.prepare('SELECT * FROM service_jobs WHERE id = ?').get(job_id);
    _assertJobOpen(job);
    const desc = String(description || '').trim();
    if (!desc) throw new Error('Description zaroori hai');
    const qty = Number(quantity) || 1;
    const price = Number(unit_price) || 0;
    db.prepare(`
        INSERT INTO service_job_items (job_id, product_id, description, quantity, unit_price, total)
        VALUES (?, ?, ?, ?, ?, ?)
    `).run(job_id, product_id || null, desc, qty, price, qty * price);
    _recalcJobTotals(db, job_id);
    return getServiceJob(db, job_id);
}

function removeServiceJobItem(db, item_id) {
    const item = db.prepare('SELECT * FROM service_job_items WHERE id = ?').get(item_id);
    if (!item) throw new Error('Item nahi mila');
    const job = db.prepare('SELECT * FROM service_jobs WHERE id = ?').get(item.job_id);
    _assertJobOpen(job);
    db.prepare('DELETE FROM service_job_items WHERE id = ?').run(item_id);
    _recalcJobTotals(db, item.job_id);
    return getServiceJob(db, item.job_id);
}

// Move a job through its workflow. Moving to 'delivered' finalizes it:
// decrements stock for part lines and posts the same ledger entries a normal
// sale would, in one transaction. Once delivered or cancelled, a job is
// locked (see _assertJobOpen) and this cannot be called on it again.
function updateServiceJobStatus(db, job_id, newStatus, extra = {}) {
    const validStatuses = ['pending', 'in_progress', 'completed', 'delivered', 'cancelled'];
    if (!validStatuses.includes(newStatus)) throw new Error('Invalid status');

    const tx = db.transaction(() => {
        const job = db.prepare('SELECT * FROM service_jobs WHERE id = ?').get(job_id);
        _assertJobOpen(job);

        if (newStatus === 'cancelled') {
            db.prepare(`UPDATE service_jobs SET status = 'cancelled', closed_date = datetime('now') WHERE id = ?`).run(job_id);
            return getServiceJob(db, job_id);
        }

        if (newStatus !== 'delivered') {
            db.prepare('UPDATE service_jobs SET status = ? WHERE id = ?').run(newStatus, job_id);
            return getServiceJob(db, job_id);
        }

        // --- Finalize: newStatus === 'delivered' ---
        const items = getServiceJobItems(db, job_id);
        if (!items.length) throw new Error('Job finalize karne se pehle kam az kam ek item add karein');

        const discount = extra.discount !== undefined ? Number(extra.discount) : (job.discount || 0);
        const tax = extra.tax !== undefined ? Number(extra.tax) : (job.tax || 0);
        const paid_amount = extra.paid_amount !== undefined ? Number(extra.paid_amount) : 0;
        const payment_method = extra.payment_method || 'cash';

        const subtotal = items.reduce((s, it) => s + it.total, 0);
        const total = Math.max(0, subtotal - discount + tax);

        db.prepare(`
            UPDATE service_jobs SET status = 'delivered', closed_date = datetime('now'),
                subtotal = ?, discount = ?, tax = ?, total = ?, paid_amount = ?, payment_method = ?
            WHERE id = ?
        `).run(subtotal, discount, tax, total, paid_amount, payment_method, job_id);

        // Decrement stock for part lines (product_id set); labor lines have none
        for (const it of items) {
            if (it.product_id) _applyStockDelta(db, job.branch_id, it.product_id, -Math.abs(it.quantity));
        }

        // Post the same style of ledger entries a sale would
        const salesAcct = getAccountByName(db, job.business_id, 'Sales Revenue');
        const cashAcct = getAccountByName(db, job.business_id, paymentAccountForMethod(payment_method));
        const receivableAcct = getAccountByName(db, job.business_id, 'Accounts Receivable');
        const jobLabel = `Service Job ${job.job_no}`;

        if (salesAcct) postLedgerEntry(db, { business_id: job.business_id, account_id: salesAcct.id, description: jobLabel, credit: total, reference_type: 'service_job', reference_id: job_id });
        if (paid_amount > 0 && cashAcct) postLedgerEntry(db, { business_id: job.business_id, account_id: cashAcct.id, description: `${jobLabel} payment`, debit: paid_amount, reference_type: 'service_job', reference_id: job_id });
        const unpaid = total - paid_amount;
        if (unpaid > 0 && receivableAcct) postLedgerEntry(db, { business_id: job.business_id, account_id: receivableAcct.id, description: `${jobLabel} balance`, debit: unpaid, reference_type: 'service_job', reference_id: job_id });

        return getServiceJob(db, job_id);
    });
    return tx();
}

function serviceJobsSummary(db, business_id, from, to) {
    const rows = db.prepare(`
        SELECT sji.product_id, sji.total
        FROM service_job_items sji
        JOIN service_jobs sj ON sj.id = sji.job_id
        WHERE sj.business_id = ? AND sj.status = 'delivered' AND sj.closed_date >= ? AND sj.closed_date <= ?
    `).all(business_id, from, to);

    let laborTotal = 0, partsTotal = 0;
    for (const r of rows) {
        if (r.product_id) partsTotal += r.total; else laborTotal += r.total;
    }
    const jobCount = db.prepare(`
        SELECT COUNT(*) as c FROM service_jobs WHERE business_id = ? AND status = 'delivered' AND closed_date >= ? AND closed_date <= ?
    `).get(business_id, from, to).c;

    return { jobCount, laborTotal, partsTotal, total: laborTotal + partsTotal };
}

// ===================== AUTOMOBILE: VEHICLE STOCK / SALES (bikes, cars, scooters) =====================

function createVehicleUnit(db, u) {
    const model = String(u.model || '').trim();
    if (!model) throw new Error('Model zaroori hai');
    return db.prepare(`
        INSERT INTO vehicle_units (business_id, branch_id, vehicle_type, make, model, color, motor_power, motor_no, chassis_no, cost_price, sale_price, notes)
        VALUES (@business_id, @branch_id, @vehicle_type, @make, @model, @color, @motor_power, @motor_no, @chassis_no, @cost_price, @sale_price, @notes)
    `).run({
        business_id: u.business_id, branch_id: u.branch_id || null,
        vehicle_type: u.vehicle_type || 'bike', make: u.make || '', model,
        color: u.color || '', motor_power: u.motor_power || '', motor_no: u.motor_no || '',
        chassis_no: u.chassis_no || '', cost_price: u.cost_price || 0, sale_price: u.sale_price || 0,
        notes: u.notes || '',
    }).lastInsertRowid;
}

function updateVehicleUnit(db, id, patch) {
    const allowed = ['vehicle_type', 'make', 'model', 'color', 'motor_power', 'motor_no', 'chassis_no', 'cost_price', 'sale_price', 'notes'];
    const fields = allowed.filter(f => Object.prototype.hasOwnProperty.call(patch, f));
    if (fields.length) {
        const setSql = fields.map(f => `${f} = @${f}`).join(', ');
        db.prepare(`UPDATE vehicle_units SET ${setSql} WHERE id = @id`).run({ id, ...patch });
    }
    return db.prepare('SELECT * FROM vehicle_units WHERE id = ?').get(id);
}

function listVehicleUnits(db, business_id, { status, search } = {}) {
    let sql = 'SELECT * FROM vehicle_units WHERE business_id = ?';
    const params = [business_id];
    if (status) { sql += ' AND status = ?'; params.push(status); }
    if (search) {
        sql += ' AND (model LIKE ? OR make LIKE ? OR chassis_no LIKE ? OR motor_no LIKE ?)';
        const s = `%${search}%`;
        params.push(s, s, s, s);
    }
    sql += ' ORDER BY created_at DESC';
    return db.prepare(sql).all(...params);
}

function getVehicleUnit(db, id) {
    return db.prepare('SELECT * FROM vehicle_units WHERE id = ?').get(id);
}

function generateVehicleInvoiceNo(db, business_id) {
    const row = db.prepare('SELECT COUNT(*) as c FROM vehicle_sales WHERE business_id = ?').get(business_id);
    return `VS-${String(business_id).padStart(3, '0')}-${String(row.c + 1).padStart(5, '0')}`;
}

// Sell a vehicle unit: marks it sold, records the buyer's invoice details, and
// posts the same style of ledger entries a sale would. One unit, one sale -
// there is no multi-item cart here, since each vehicle is its own invoice.
function sellVehicleUnit(db, s) {
    const tx = db.transaction(() => {
        const unit = db.prepare('SELECT * FROM vehicle_units WHERE id = ?').get(s.vehicle_unit_id);
        if (!unit) throw new Error('Vehicle nahi mili');
        if (unit.status !== 'in_stock') throw new Error('Ye vehicle pehle hi sell ho chuki hai');

        const amount = s.amount !== undefined ? Number(s.amount) : unit.sale_price;
        const paid_amount = Number(s.paid_amount) || 0;
        const invoice_no = generateVehicleInvoiceNo(db, s.business_id);

        // Every vehicle buyer becomes (or already is) a customer, so any unpaid
        // balance shows up in their khata.
        let customer_id = s.customer_id || null;
        if (!customer_id && String(s.customer_name || '').trim()) {
            customer_id = createCustomer(db, {
                business_id: s.business_id, name: s.customer_name, guardian_name: s.guardian_name,
                cnic_no: s.cnic_no, phone: s.contact_no, address: s.address,
            });
        }

        const info = db.prepare(`
            INSERT INTO vehicle_sales (business_id, branch_id, vehicle_unit_id, customer_id, invoice_no, customer_name, guardian_name, cnic_no, contact_no, address, amount, paid_amount, payment_method, status, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', ?)
        `).run(
            s.business_id, s.branch_id, s.vehicle_unit_id, customer_id, invoice_no,
            s.customer_name || '', s.guardian_name || '', s.cnic_no || '', s.contact_no || '', s.address || '',
            amount, paid_amount, s.payment_method || 'cash', s.user_id || null
        );
        const saleId = info.lastInsertRowid;

        db.prepare(`UPDATE vehicle_units SET status = 'sold' WHERE id = ?`).run(s.vehicle_unit_id);

        const salesAcct = getAccountByName(db, s.business_id, 'Sales Revenue');
        const cashAcct = getAccountByName(db, s.business_id, paymentAccountForMethod(s.payment_method));
        const receivableAcct = getAccountByName(db, s.business_id, 'Accounts Receivable');
        const label = `Vehicle Sale ${invoice_no} (${unit.model})`;

        if (salesAcct) postLedgerEntry(db, { business_id: s.business_id, account_id: salesAcct.id, description: label, credit: amount, reference_type: 'vehicle_sale', reference_id: saleId });
        if (paid_amount > 0 && cashAcct) postLedgerEntry(db, { business_id: s.business_id, account_id: cashAcct.id, description: `${label} payment`, debit: paid_amount, reference_type: 'vehicle_sale', reference_id: saleId });
        const unpaid = amount - paid_amount;
        if (unpaid > 0 && receivableAcct) postLedgerEntry(db, { business_id: s.business_id, account_id: receivableAcct.id, description: `${label} balance`, debit: unpaid, reference_type: 'vehicle_sale', reference_id: saleId });

        return saleId;
    });
    return tx();
}

function getVehicleSale(db, id) {
    return db.prepare(`
        SELECT vs.*, vu.vehicle_type, vu.make, vu.model, vu.color, vu.motor_power, vu.motor_no, vu.chassis_no
        FROM vehicle_sales vs JOIN vehicle_units vu ON vu.id = vs.vehicle_unit_id
        WHERE vs.id = ?
    `).get(id);
}

function listVehicleSales(db, business_id, branch_id, from, to) {
    let sql = `
        SELECT vs.*, vu.vehicle_type, vu.make, vu.model, vu.color, vu.motor_power, vu.motor_no, vu.chassis_no
        FROM vehicle_sales vs JOIN vehicle_units vu ON vu.id = vs.vehicle_unit_id
        WHERE vs.business_id = ?`;
    const params = [business_id];
    if (branch_id) { sql += ' AND vs.branch_id = ?'; params.push(branch_id); }
    if (from) { sql += ' AND vs.sale_date >= ?'; params.push(from); }
    if (to) { sql += ' AND vs.sale_date <= ?'; params.push(to); }
    sql += ' ORDER BY vs.sale_date DESC';
    return db.prepare(sql).all(...params);
}

// Cancel a completed vehicle sale: reverses the ledger entries and returns the
// unit to stock so it can be sold again. Mirrors the sale-refund pattern.
function cancelVehicleSale(db, id) {
    const tx = db.transaction(() => {
        const sale = db.prepare('SELECT * FROM vehicle_sales WHERE id = ?').get(id);
        if (!sale) throw new Error('Sale nahi mili');
        if (sale.status === 'cancelled') throw new Error('Ye sale pehle hi cancelled hai');

        const originalEntries = db.prepare(`SELECT * FROM ledger_entries WHERE reference_type = 'vehicle_sale' AND reference_id = ?`).all(id);
        for (const entry of originalEntries) {
            postLedgerEntry(db, {
                business_id: sale.business_id, account_id: entry.account_id,
                description: `Cancelled: ${sale.invoice_no}`, debit: entry.credit, credit: entry.debit,
                reference_type: 'vehicle_sale_cancel', reference_id: id,
            });
        }
        db.prepare(`UPDATE vehicle_sales SET status = 'cancelled' WHERE id = ?`).run(id);
        db.prepare(`UPDATE vehicle_units SET status = 'in_stock' WHERE id = ?`).run(sale.vehicle_unit_id);
    });
    tx();
}

module.exports = {
    openDatabase, getDbFilePath, checkpoint,
    authenticateUser, createUser, listUsers, getUser, updateUser, deleteUser,
    createBusiness, listBusinesses, getBusiness, updateBusiness, listBranches, createBranch,
    createCategory, listCategories,
    createProduct, updateProduct, deleteProduct, listProducts, findProductByBarcode,
    getStock, listStockForBranch, listLowStock, manualStockAdjustment,
    listAccounts, getAccountByName, postLedgerEntry, getAccountBalance, getLedgerEntries,
    createSupplier, listSuppliers, createPurchase, listPurchases, getPurchaseItems,
    createCustomer, updateCustomer, getCustomer, listCustomers, customerBalance, customerStatement, receiveCustomerPayment, createSale, listSales, getSaleItems, getSale, refundSale,
    createExpense, listExpenses,
    salesSummary, profitLossReport, topSellingProducts,
    createVehicle, updateVehicle, listVehicles, getVehicle,
    createMechanic, listMechanics, updateMechanic,
    createServiceJob, getServiceJob, getServiceJobItems, listServiceJobs,
    addServiceJobItem, removeServiceJobItem, updateServiceJobStatus, serviceJobsSummary,
    createVehicleUnit, updateVehicleUnit, listVehicleUnits, getVehicleUnit,
    sellVehicleUnit, getVehicleSale, listVehicleSales, cancelVehicleSale, vehicleSalesSummary,
};
