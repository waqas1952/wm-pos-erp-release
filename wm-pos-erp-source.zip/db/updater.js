// db/updater.js
// Auto-update via electron-updater, pointed at GitHub Releases.
//
// How releases work: bump "version" in package.json, run `npm run build-win`,
// then upload the generated "WM POS ERP Setup X.Y.Z.exe" AND "latest.yml"
// (both in dist/) to a GitHub release tagged vX.Y.Z. Installed copies will
// then see the new version.
//
// Note: update checks need internet. The app itself works fully offline -
// a failed check is logged and ignored, never blocking the user.

const { autoUpdater } = require('electron-updater');

let mainWindow = null;
let checking = false;

function send(channel, payload) {
    if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send(channel, payload);
    }
}

function initUpdater(win, { autoCheck }) {
    mainWindow = win;

    autoUpdater.autoDownload = false;          // ask the user first
    autoUpdater.autoInstallOnAppQuit = true;

    autoUpdater.on('checking-for-update', () => send('update:status', { state: 'checking' }));

    autoUpdater.on('update-available', (info) => {
        checking = false;
        send('update:status', { state: 'available', version: info.version, notes: info.releaseNotes || '' });
    });

    autoUpdater.on('update-not-available', () => {
        checking = false;
        send('update:status', { state: 'none' });
    });

    autoUpdater.on('error', (err) => {
        checking = false;
        send('update:status', { state: 'error', message: (err && err.message) || String(err) });
    });

    autoUpdater.on('download-progress', (p) => {
        send('update:status', { state: 'downloading', percent: Math.round(p.percent), transferred: p.transferred, total: p.total });
    });

    autoUpdater.on('update-downloaded', (info) => {
        send('update:status', { state: 'downloaded', version: info.version });
    });

    if (autoCheck) {
        // Delay so it never slows down app startup
        setTimeout(() => { checkForUpdates().catch(() => {}); }, 8000);
    }
}

async function checkForUpdates() {
    if (checking) return { alreadyChecking: true };
    checking = true;
    try {
        await autoUpdater.checkForUpdates();
        return { started: true };
    } catch (err) {
        checking = false;
        throw err;
    }
}

async function downloadUpdate() {
    await autoUpdater.downloadUpdate();
    return { started: true };
}

function quitAndInstall() {
    autoUpdater.quitAndInstall(false, true);
}

module.exports = { initUpdater, checkForUpdates, downloadUpdate, quitAndInstall };
