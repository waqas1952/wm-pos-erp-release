// db/appsettings.js
// Small JSON-backed settings store for app-level preferences (backup folder,
// schedule, retention, update behaviour). Kept separate from the SQLite business
// data so that restoring a database backup never clobbers the user's own
// backup configuration.

const fs = require('fs');
const path = require('path');

const DEFAULTS = {
    theme: 'royal',             // UI colour theme (see renderer/js/theme.js)
    autoBackupEnabled: false,
    backupFolder: '',           // empty = not chosen yet
    backupOnClose: true,        // backup when the app is closed
    backupDailyOnOpen: true,    // backup on launch if none taken today
    keepBackups: 14,            // how many backup files to retain
    lastBackupAt: null,         // ISO timestamp
    autoCheckUpdates: true,
};

function settingsPath(userDataPath) {
    return path.join(userDataPath, 'app-settings.json');
}

function loadSettings(userDataPath) {
    try {
        const raw = fs.readFileSync(settingsPath(userDataPath), 'utf8');
        return { ...DEFAULTS, ...JSON.parse(raw) };
    } catch (err) {
        return { ...DEFAULTS };
    }
}

function saveSettings(userDataPath, patch) {
    const current = loadSettings(userDataPath);
    const next = { ...current, ...patch };
    fs.writeFileSync(settingsPath(userDataPath), JSON.stringify(next, null, 2), 'utf8');
    return next;
}

module.exports = { loadSettings, saveSettings, DEFAULTS };
