-- WM POS ERP Database Schema
-- Multi-business, multi-branch, offline SQLite schema

PRAGMA foreign_keys = ON;

-- ===================== CORE / BUSINESS =====================

CREATE TABLE IF NOT EXISTS businesses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    business_type TEXT DEFAULT 'general',   -- general, bakery, pharmacy, restaurant, etc.
    address TEXT,
    phone TEXT,
    logo_path TEXT,
    logo_data TEXT,                         -- base64 data URI; stored inline so it survives backup/restore
    tagline TEXT,                           -- optional line printed under the name on receipts
    receipt_footer TEXT,                    -- optional thank-you / return policy line on receipts
    brand_logo_data TEXT,                   -- second logo printed top-right on invoices (e.g. the brand you are a dealer for)
    brand_title TEXT,                       -- text under the brand logo, e.g. "Electric Scooter"
    invoice_size TEXT DEFAULT 'ask',        -- default invoice paper: a4, a5, thermal, or ask every time
    currency TEXT DEFAULT 'PKR',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    address TEXT,
    phone TEXT,
    is_main INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER REFERENCES businesses(id) ON DELETE CASCADE,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    full_name TEXT,
    role TEXT DEFAULT 'cashier',   -- super_admin, admin, manager, cashier, accountant
    permissions TEXT,              -- JSON array of permission keys; NULL = use role defaults
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

-- ===================== PRODUCTS / INVENTORY =====================

CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    parent_id INTEGER REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    category_id INTEGER REFERENCES categories(id),
    name TEXT NOT NULL,
    sku TEXT,
    barcode TEXT,
    unit TEXT DEFAULT 'pcs',
    cost_price REAL DEFAULT 0,
    sale_price REAL DEFAULT 0,
    tax_percent REAL DEFAULT 0,
    reorder_level REAL DEFAULT 0,
    expiry_tracked INTEGER DEFAULT 0,
    part_number TEXT,              -- automobile: manufacturer/OEM part number
    compatible_vehicles TEXT,      -- automobile: free-text fitment note, e.g. "Civic 2016-2020, City 2015-2018"
    color TEXT,                    -- automobile: colour of the bike/car model held in stock
    model TEXT,                    -- automobile: model name/year printed on the invoice
    is_vehicle INTEGER DEFAULT 0,  -- automobile: 1 = a whole bike/car (invoice asks chassis/motor no per unit)
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_business ON products(business_id);

CREATE TABLE IF NOT EXISTS stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity REAL DEFAULT 0,
    batch_no TEXT,
    expiry_date TEXT,
    updated_at TEXT DEFAULT (datetime('now')),
    UNIQUE(branch_id, product_id, batch_no)
);

CREATE TABLE IF NOT EXISTS stock_adjustments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity_change REAL NOT NULL,   -- positive = add, negative = remove
    reason TEXT,                      -- damage, theft, correction, opening_stock, etc
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

-- ===================== SUPPLIERS / PURCHASING =====================

CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT,
    address TEXT,
    opening_balance REAL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    supplier_id INTEGER REFERENCES suppliers(id),
    invoice_no TEXT,
    purchase_date TEXT DEFAULT (datetime('now')),
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    tax REAL DEFAULT 0,
    total_amount REAL DEFAULT 0,
    paid_amount REAL DEFAULT 0,
    status TEXT DEFAULT 'received',   -- pending, received, cancelled
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS purchase_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    purchase_id INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity REAL NOT NULL,
    cost_price REAL NOT NULL,
    batch_no TEXT,
    expiry_date TEXT,
    total REAL NOT NULL
);

-- ===================== CUSTOMERS / SALES (POS) =====================

CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    name TEXT DEFAULT 'Walk-in Customer',
    guardian_name TEXT,            -- S/O, D/O or W/O (as printed on invoices)
    cnic_no TEXT,
    phone TEXT,
    address TEXT,
    opening_balance REAL DEFAULT 0, -- amount the customer already owed when added
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

-- Money received from a customer against what they owe (udhaar wasooli).
CREATE TABLE IF NOT EXISTS customer_payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    customer_id INTEGER NOT NULL REFERENCES customers(id),
    amount REAL NOT NULL,
    payment_method TEXT DEFAULT 'cash',
    note TEXT,
    payment_date TEXT DEFAULT (datetime('now')),
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    customer_id INTEGER REFERENCES customers(id),
    invoice_no TEXT,
    sale_date TEXT DEFAULT (datetime('now')),
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    tax REAL DEFAULT 0,
    total REAL DEFAULT 0,
    paid_amount REAL DEFAULT 0,
    payment_method TEXT DEFAULT 'cash',   -- cash, card, credit, easypaisa, jazzcash
    status TEXT DEFAULT 'completed',       -- completed, held, refunded, cancelled
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sale_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id),
    quantity REAL NOT NULL,
    unit_price REAL NOT NULL,
    discount REAL DEFAULT 0,
    total REAL NOT NULL,
    chassis_no TEXT,               -- automobile: entered at sale time for the unit sold
    motor_no TEXT,
    motor_power TEXT
);

-- ===================== ACCOUNTING / LEDGER =====================

CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,             -- Cash in Hand, Bank, Sales Revenue, Purchase Expense, etc
    account_type TEXT NOT NULL,     -- asset, liability, equity, income, expense
    opening_balance REAL DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS ledger_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    account_id INTEGER NOT NULL REFERENCES accounts(id),
    entry_date TEXT DEFAULT (datetime('now')),
    description TEXT,
    debit REAL DEFAULT 0,
    credit REAL DEFAULT 0,
    reference_type TEXT,   -- sale, purchase, expense, manual, opening
    reference_id INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER REFERENCES branches(id),
    category TEXT,
    description TEXT,
    amount REAL NOT NULL,
    expense_date TEXT DEFAULT (datetime('now')),
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

-- ===================== AUTOMOBILE: VEHICLES / MECHANICS / SERVICE JOBS =====================

CREATE TABLE IF NOT EXISTS vehicles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    customer_id INTEGER REFERENCES customers(id),
    registration_no TEXT NOT NULL,
    make TEXT,
    model TEXT,
    year TEXT,
    color TEXT,
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_vehicles_reg ON vehicles(business_id, registration_no);

CREATE TABLE IF NOT EXISTS mechanics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    phone TEXT,
    specialty TEXT,
    active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS service_jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
    customer_id INTEGER REFERENCES customers(id),
    mechanic_id INTEGER REFERENCES mechanics(id),
    job_no TEXT,
    status TEXT DEFAULT 'pending',     -- pending, in_progress, completed, delivered, cancelled
    complaint TEXT,                     -- customer's reported issue / work requested
    odometer_reading TEXT,
    subtotal REAL DEFAULT 0,
    discount REAL DEFAULT 0,
    tax REAL DEFAULT 0,
    total REAL DEFAULT 0,
    paid_amount REAL DEFAULT 0,
    payment_method TEXT DEFAULT 'cash',
    opened_date TEXT DEFAULT (datetime('now')),
    closed_date TEXT,
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);

-- A job's line items. product_id set = a part (decrements stock on finalize);
-- product_id NULL = a labor/service line (no stock impact).
CREATE TABLE IF NOT EXISTS service_job_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER NOT NULL REFERENCES service_jobs(id) ON DELETE CASCADE,
    product_id INTEGER REFERENCES products(id),
    description TEXT NOT NULL,
    quantity REAL DEFAULT 1,
    unit_price REAL NOT NULL,
    total REAL NOT NULL
);

-- ===================== AUTOMOBILE: VEHICLE STOCK (bikes/cars/scooters for sale) =====================

-- A single sellable vehicle unit - unlike parts (quantity-based), each unit is
-- serialized (its own chassis/motor number) so it gets its own row rather than
-- a quantity count.
CREATE TABLE IF NOT EXISTS vehicle_units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER REFERENCES branches(id),
    vehicle_type TEXT DEFAULT 'bike',    -- bike, car, scooter, other
    make TEXT,
    model TEXT NOT NULL,
    color TEXT,
    motor_power TEXT,                     -- e.g. "1500W" (electric) or "70cc" (petrol)
    motor_no TEXT,
    chassis_no TEXT,
    cost_price REAL DEFAULT 0,
    sale_price REAL DEFAULT 0,
    status TEXT DEFAULT 'in_stock',        -- in_stock, sold
    notes TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_vehicle_units_chassis ON vehicle_units(business_id, chassis_no);

-- A completed (or cancelled) sale of one vehicle unit, with the buyer details
-- a dealership invoice needs (CNIC, guardian name, etc).
CREATE TABLE IF NOT EXISTS vehicle_sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id INTEGER NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    branch_id INTEGER NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    vehicle_unit_id INTEGER NOT NULL REFERENCES vehicle_units(id),
    customer_id INTEGER REFERENCES customers(id),
    invoice_no TEXT,
    customer_name TEXT,
    guardian_name TEXT,      -- S/O, D/O or W/O
    cnic_no TEXT,
    contact_no TEXT,
    address TEXT,
    sale_date TEXT DEFAULT (datetime('now')),
    amount REAL DEFAULT 0,
    paid_amount REAL DEFAULT 0,
    payment_method TEXT DEFAULT 'cash',   -- cash, online
    status TEXT DEFAULT 'completed',       -- completed, cancelled
    user_id INTEGER REFERENCES users(id),
    created_at TEXT DEFAULT (datetime('now'))
);
