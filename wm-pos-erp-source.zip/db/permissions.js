// db/permissions.js
// Defines what each user is allowed to do.
//
// A user's effective permissions are either an explicit per-user list (stored
// as JSON in users.permissions) or, when that is null, the defaults for their
// role. This means an admin can start from a role and then fine-tune a single
// user without affecting anyone else with the same role.

const PERMISSIONS = [
    // key, label shown in the UI, which page it belongs to
    { key: 'pos.sell',           label: 'Sale karna (POS)',                 group: 'POS / Billing' },
    { key: 'pos.discount',       label: 'Bill par discount dena',           group: 'POS / Billing' },
    { key: 'pos.credit',         label: 'Udhaar (credit) par bechna',       group: 'POS / Billing' },

    { key: 'customers.view',     label: 'Customers aur unka khata dekhna',  group: 'Customers' },
    { key: 'customers.manage',   label: 'Customer add/edit karna',          group: 'Customers' },
    { key: 'customers.payment',  label: 'Customer se payment (udhaar) wasool karna', group: 'Customers' },

    { key: 'sales.view',         label: 'Sales history dekhna',             group: 'Sales' },
    { key: 'sales.reprint',      label: 'Purana receipt dobara print karna', group: 'Sales' },
    { key: 'sales.refund',       label: 'Sale refund karna',                group: 'Sales' },

    { key: 'inventory.view',     label: 'Inventory dekhna',                 group: 'Inventory' },
    { key: 'inventory.edit',     label: 'Product add/edit karna',           group: 'Inventory' },
    { key: 'inventory.adjust',   label: 'Stock adjust karna',               group: 'Inventory' },
    { key: 'inventory.cost',     label: 'Cost price (khareed rate) dekhna', group: 'Inventory' },

    { key: 'purchasing.view',    label: 'Purchases dekhna',                 group: 'Purchasing' },
    { key: 'purchasing.manage',  label: 'Purchase / supplier add karna',    group: 'Purchasing' },

    { key: 'accounts.view',      label: 'Accounts aur ledger dekhna',       group: 'Accounts' },
    { key: 'accounts.expense',   label: 'Kharcha (expense) record karna',   group: 'Accounts' },

    { key: 'reports.view',       label: 'Reports dekhna',                   group: 'Reports' },
    { key: 'reports.profit',     label: 'Profit / margin dekhna',           group: 'Reports' },

    { key: 'automobile.jobs.view',     label: 'Service jobs dekhna',                group: 'Automobile' },
    { key: 'automobile.jobs.manage',   label: 'Service job open/edit karna',        group: 'Automobile' },
    { key: 'automobile.jobs.finalize', label: 'Service job finalize/bill karna',    group: 'Automobile' },
    { key: 'automobile.vehicles',      label: 'Vehicles add/edit karna',            group: 'Automobile' },
    { key: 'automobile.mechanics',     label: 'Mechanics add/edit karna',           group: 'Automobile' },
    { key: 'automobile.vehicleStock.manage', label: 'Bike/Car stock add/edit karna',        group: 'Automobile' },
    { key: 'automobile.vehicleSales.view',   label: 'Vehicle sales history dekhna',         group: 'Automobile' },
    { key: 'automobile.vehicleSales.sell',   label: 'Bike/Car bechna (invoice banana)',     group: 'Automobile' },

    { key: 'settings.shop',      label: 'Shop profile aur theme badalna',   group: 'Settings' },
    { key: 'settings.users',     label: 'Users banana aur permissions dena', group: 'Settings' },
    { key: 'settings.backup',    label: 'Backup / restore karna',           group: 'Settings' },
    { key: 'settings.business',  label: 'Business aur branch manage karna', group: 'Settings' },
];

const ALL_KEYS = PERMISSIONS.map(p => p.key);

const ROLE_DEFAULTS = {
    super_admin: ALL_KEYS,
    admin: ALL_KEYS,
    manager: [
        'pos.sell', 'pos.discount', 'pos.credit',
        'customers.view', 'customers.manage', 'customers.payment',
        'sales.view', 'sales.reprint', 'sales.refund',
        'inventory.view', 'inventory.edit', 'inventory.adjust', 'inventory.cost',
        'purchasing.view', 'purchasing.manage',
        'accounts.view', 'accounts.expense',
        'reports.view', 'reports.profit',
        'automobile.jobs.view', 'automobile.jobs.manage', 'automobile.jobs.finalize', 'automobile.vehicles', 'automobile.mechanics',
        'automobile.vehicleStock.manage', 'automobile.vehicleSales.view', 'automobile.vehicleSales.sell',
    ],
    accountant: [
        'customers.view', 'customers.payment',
        'sales.view', 'sales.reprint',
        'inventory.view', 'inventory.cost',
        'purchasing.view',
        'accounts.view', 'accounts.expense',
        'reports.view', 'reports.profit',
        'automobile.jobs.view', 'automobile.vehicleSales.view',
    ],
    cashier: [
        'pos.sell',
        'customers.view', 'customers.manage',
        'sales.view', 'sales.reprint',
        'inventory.view',
        'automobile.jobs.view', 'automobile.jobs.manage',
        'automobile.vehicleSales.view', 'automobile.vehicleSales.sell',
    ],
};

// Which permission is required to see each page in the sidebar. A page with
// no entry here is always visible.
const PAGE_PERMISSION = {
    pos: 'pos.sell',
    customers: 'customers.view',
    sales: 'sales.view',
    inventory: 'inventory.view',
    purchasing: 'purchasing.view',
    accounts: 'accounts.view',
    reports: 'reports.view',
    automobile: 'automobile.jobs.view',
};

function defaultsForRole(role) {
    return ROLE_DEFAULTS[role] || ROLE_DEFAULTS.cashier;
}

// Resolve a user row into a concrete list of permission keys.
function effectivePermissions(user) {
    if (!user) return [];
    if (user.role === 'super_admin') return ALL_KEYS.slice();   // never lockable
    if (user.permissions) {
        try {
            const parsed = JSON.parse(user.permissions);
            if (Array.isArray(parsed)) return parsed.filter(k => ALL_KEYS.includes(k));
        } catch (err) { /* fall through to role defaults */ }
    }
    return defaultsForRole(user.role).slice();
}

function hasPermission(user, key) {
    if (!user) return false;
    if (user.role === 'super_admin') return true;
    return effectivePermissions(user).includes(key);
}

module.exports = { PERMISSIONS, ALL_KEYS, ROLE_DEFAULTS, PAGE_PERMISSION, defaultsForRole, effectivePermissions, hasPermission };
