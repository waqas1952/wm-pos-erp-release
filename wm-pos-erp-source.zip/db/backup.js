// db/backup.js
// Handles automatic and manual database backups.
//
// A backup is just a copy of the SQLite file, named with a timestamp. The
// backup folder can be any path the user picks - a second drive, a USB stick,
// or a Google Drive / OneDrive sync folder (which then pushes it to the cloud
// on its own, so the app itself never needs internet).

const fs = require('fs');
const path = require('path');

const PREFIX = 'wm-pos-erp-backup-';
const EXT = '.db';

function timestampName(date = new Date()) {
    const p = n => String(n).padStart(2, '0');
    return `${PREFIX}${date.getFullYear()}-${p(date.getMonth() + 1)}-${p(date.getDate())}_${p(date.getHours())}-${p(date.getMinutes())}-${p(date.getSeconds())}${EXT}`;
}

// Parse the timestamp out of a backup filename. Sorting on this rather than
// mtime matters: copying backups to another drive or cloud folder rewrites
// mtime, but the name still records when the backup was actually taken.
function parseBackupTime(name) {
    const m = name.match(/(\d{4})-(\d{2})-(\d{2})_(\d{2})-(\d{2})-(\d{2})/);
    if (!m) return null;
    const [, y, mo, d, h, mi, s] = m;
    return new Date(Number(y), Number(mo) - 1, Number(d), Number(h), Number(mi), Number(s));
}

function listBackups(folder) {
    if (!folder || !fs.existsSync(folder)) return [];
    return fs.readdirSync(folder)
        .filter(f => f.startsWith(PREFIX) && f.endsWith(EXT))
        .map(f => {
            const full = path.join(folder, f);
            const st = fs.statSync(full);
            const taken = parseBackupTime(f) || st.mtime;
            return { name: f, path: full, size: st.size, mtime: st.mtime.toISOString(), takenAt: taken.toISOString() };
        })
        .sort((a, b) => b.takenAt.localeCompare(a.takenAt));
}

// Delete the oldest backups beyond `keep`. Never throws - pruning failing
// should not stop a backup from being considered successful.
function pruneBackups(folder, keep) {
    try {
        const all = listBackups(folder);
        for (const old of all.slice(keep)) {
            try { fs.unlinkSync(old.path); } catch (e) { /* ignore single failure */ }
        }
    } catch (e) { /* ignore */ }
}

// Copy the live database to the backup folder.
// `checkpointFn` should flush the WAL so the copy is complete and consistent.
function runBackup({ dbPath, folder, keep, checkpointFn }) {
    if (!folder) throw new Error('No backup folder configured');
    if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });

    if (typeof checkpointFn === 'function') checkpointFn();

    const target = path.join(folder, timestampName());
    fs.copyFileSync(dbPath, target);

    // Verify the copy actually landed and is non-empty before reporting success
    const st = fs.statSync(target);
    if (!st.size) {
        try { fs.unlinkSync(target); } catch (e) { /* ignore */ }
        throw new Error('Backup file was empty');
    }

    pruneBackups(folder, keep || 14);
    return { path: target, size: st.size, at: new Date().toISOString() };
}

function isSameDay(isoA, dateB) {
    if (!isoA) return false;
    const a = new Date(isoA);
    return a.getFullYear() === dateB.getFullYear()
        && a.getMonth() === dateB.getMonth()
        && a.getDate() === dateB.getDate();
}

// Should a "daily on open" backup run right now?
function shouldBackupToday(settings) {
    if (!settings.autoBackupEnabled || !settings.backupFolder) return false;
    if (!settings.backupDailyOnOpen) return false;
    return !isSameDay(settings.lastBackupAt, new Date());
}

module.exports = { runBackup, listBackups, pruneBackups, shouldBackupToday, timestampName, parseBackupTime, PREFIX };
