const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const dbmod = require('./db/database');
const appsettings = require('./db/appsettings');
const backupmod = require('./db/backup');
const updatermod = require('./db/updater');
const permsmod = require('./db/permissions');

let mainWindow;
let db;
let currentUser = null;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1366,
        height: 800,
        minWidth: 1024,
        minHeight: 640,
        icon: path.join(__dirname, 'assets', 'icon.png'),
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            nodeIntegration: false,
        },
    });
    mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
    mainWindow.setMenuBarVisibility(false);
}

// Run a backup using the current settings. Returns the result, or null if
// auto-backup isn't configured. Never throws - backup failure must not break
// app startup or shutdown.
function performBackup(reason) {
    try {
        const settings = appsettings.loadSettings(app.getPath('userData'));
        if (!settings.backupFolder) return null;
        const result = backupmod.runBackup({
            dbPath: dbmod.getDbFilePath(app.getPath('userData')),
            folder: settings.backupFolder,
            keep: settings.keepBackups,
            checkpointFn: () => { try { dbmod.checkpoint(db); } catch (e) {} },
        });
        appsettings.saveSettings(app.getPath('userData'), { lastBackupAt: result.at });
        console.log(`[backup] ${reason}: ${result.path}`);
        return result;
    } catch (err) {
        console.error(`[backup] ${reason} failed:`, err.message);
        return null;
    }
}

app.whenReady().then(() => {
    db = dbmod.openDatabase(app.getPath('userData'));
    const settings = appsettings.loadSettings(app.getPath('userData'));

    // Daily backup on launch, if one hasn't already been taken today
    if (backupmod.shouldBackupToday(settings)) performBackup('daily-on-open');

    createWindow();
    updatermod.initUpdater(mainWindow, { autoCheck: settings.autoCheckUpdates });

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('before-quit', () => {
    const settings = appsettings.loadSettings(app.getPath('userData'));
    if (settings.autoBackupEnabled && settings.backupOnClose) performBackup('on-close');
});

app.on('window-all-closed', () => {
    if (db) db.close();
    if (process.platform !== 'darwin') app.quit();
});

// ---------------- IPC handlers ----------------
// Wrap every handler so renderer always gets {ok, data} or {ok:false, error}
function handle(channel, fn) {
    ipcMain.handle(channel, async (event, ...args) => {
        try {
            const data = await fn(...args);
            return { ok: true, data };
        } catch (err) {
            console.error(`[${channel}]`, err);
            return { ok: false, error: err.message || String(err) };
        }
    });
}

// Same, but refuses the call unless the logged-in user holds `perm`.
// Hiding buttons in the renderer is a convenience; this is the actual check,
// so a tampered renderer still can't perform the action.
function handleGuarded(channel, perm, fn) {
    handle(channel, (...args) => {
        if (!currentUser) throw new Error('Pehle login karein');
        if (!permsmod.hasPermission(currentUser, perm)) {
            throw new Error('Aap ko is kaam ki ijazat nahi hai');
        }
        return fn(...args);
    });
}

// Auth
handle('auth:login', (username, password) => {
    const user = dbmod.authenticateUser(db, username, password);
    if (!user) throw new Error('Invalid username or password');
    currentUser = user;
    return user;
});
handle('auth:currentUser', () => currentUser);
handleGuarded('auth:createUser', 'settings.users', (payload) => dbmod.createUser(db, payload));
handleGuarded('auth:listUsers', 'settings.users', (business_id) => dbmod.listUsers(db, business_id));
handleGuarded('auth:updateUser', 'settings.users', (id, patch) => {
    const updated = dbmod.updateUser(db, id, patch);
    // If the logged-in user edited themselves, refresh the cached copy so the
    // guards above use their new permissions immediately.
    if (currentUser && currentUser.id === id) {
        currentUser = { ...currentUser, ...updated };
    }
    return updated;
});
handleGuarded('auth:deleteUser', 'settings.users', (id) => {
    if (currentUser && currentUser.id === id) throw new Error('Aap khud ko delete nahi kar sakte');
    return dbmod.deleteUser(db, id);
});

// Permission catalogue + role defaults, so the renderer can draw the matrix
handle('perms:catalog', () => ({
    permissions: permsmod.PERMISSIONS,
    roleDefaults: permsmod.ROLE_DEFAULTS,
    pagePermission: permsmod.PAGE_PERMISSION,
}));

// Business / Branch
handleGuarded('business:create', 'settings.business', (payload) => dbmod.createBusiness(db, payload));
handle('business:list', () => dbmod.listBusinesses(db));
handle('business:get', (id) => dbmod.getBusiness(db, id));
handleGuarded('business:update', 'settings.shop', (id, patch) => dbmod.updateBusiness(db, id, patch));

// Opens a picker and returns the chosen image as a base64 data URI. The
// renderer shrinks it before saving, so we only guard against absurd files here.
handleGuarded('business:pickLogo', 'settings.shop', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Choose Logo Image',
        filters: [{ name: 'Images', extensions: ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'] }],
        properties: ['openFile'],
    });
    if (result.canceled || !result.filePaths.length) return { cancelled: true };

    const filePath = result.filePaths[0];
    const stat = fs.statSync(filePath);
    if (stat.size > 10 * 1024 * 1024) throw new Error('Logo 10MB se chhoti honi chahiye');

    const ext = path.extname(filePath).toLowerCase().replace('.', '');
    const mime = ext === 'jpg' ? 'jpeg' : ext;
    const base64 = fs.readFileSync(filePath).toString('base64');
    return { cancelled: false, dataUri: `data:image/${mime};base64,${base64}` };
});
handle('branch:list', (business_id) => dbmod.listBranches(db, business_id));
handleGuarded('branch:create', 'settings.business', (payload) => dbmod.createBranch(db, payload));

// Categories / Products
handle('category:list', (business_id) => dbmod.listCategories(db, business_id));
handleGuarded('category:create', 'inventory.edit', (payload) => dbmod.createCategory(db, payload));
handle('product:list', (business_id, opts) => dbmod.listProducts(db, business_id, opts || {}));
handleGuarded('product:create', 'inventory.edit', (payload) => dbmod.createProduct(db, payload));
handleGuarded('product:update', 'inventory.edit', (id, payload) => dbmod.updateProduct(db, id, payload));
handleGuarded('product:delete', 'inventory.edit', (id) => dbmod.deleteProduct(db, id));
handle('product:findByBarcode', (business_id, barcode) => dbmod.findProductByBarcode(db, business_id, barcode));

// Stock
handle('stock:listForBranch', (branch_id) => dbmod.listStockForBranch(db, branch_id));
handle('stock:lowStock', (branch_id) => dbmod.listLowStock(db, branch_id));
handleGuarded('stock:adjust', 'inventory.adjust', (payload) => dbmod.manualStockAdjustment(db, payload));

// Suppliers / Purchasing
handle('supplier:list', (business_id) => dbmod.listSuppliers(db, business_id));
handleGuarded('supplier:create', 'purchasing.manage', (payload) => dbmod.createSupplier(db, payload));
handleGuarded('purchase:create', 'purchasing.manage', (payload) => dbmod.createPurchase(db, payload));
handle('purchase:list', (business_id, branch_id) => dbmod.listPurchases(db, business_id, branch_id));
handle('purchase:items', (purchase_id) => dbmod.getPurchaseItems(db, purchase_id));

// Customers / Sales (POS)
handle('customer:list', (business_id, opts) => dbmod.listCustomers(db, business_id, opts || {}));
handle('customer:get', (id) => dbmod.getCustomer(db, id));
handleGuarded('customer:create', 'customers.manage', (payload) => dbmod.createCustomer(db, payload));
handleGuarded('customer:update', 'customers.manage', (id, patch) => dbmod.updateCustomer(db, id, patch));
handleGuarded('customer:statement', 'customers.view', (id) => dbmod.customerStatement(db, id));
handleGuarded('customer:receivePayment', 'customers.payment', (payload) => dbmod.receiveCustomerPayment(db, payload));
handleGuarded('sale:create', 'pos.sell', (payload) => dbmod.createSale(db, payload));
handle('sale:list', (business_id, branch_id, from, to) => dbmod.listSales(db, business_id, branch_id, from, to));
handle('sale:items', (sale_id) => dbmod.getSaleItems(db, sale_id));
handle('sale:get', (sale_id) => dbmod.getSale(db, sale_id));
handleGuarded('sale:refund', 'sales.refund', (payload) => dbmod.refundSale(db, payload));

// Expenses
handleGuarded('expense:create', 'accounts.expense', (payload) => dbmod.createExpense(db, payload));
handle('expense:list', (business_id, from, to) => dbmod.listExpenses(db, business_id, from, to));

// Accounts / Ledger
handle('account:list', (business_id) => dbmod.listAccounts(db, business_id));
handle('account:balance', (account_id) => dbmod.getAccountBalance(db, account_id));
handle('ledger:list', (business_id, account_id, from, to) => dbmod.getLedgerEntries(db, business_id, account_id, from, to));

// Automobile: vehicles, mechanics, service jobs
handle('vehicle:list', (business_id, search) => dbmod.listVehicles(db, business_id, search));
handle('vehicle:get', (id) => dbmod.getVehicle(db, id));
handleGuarded('vehicle:create', 'automobile.vehicles', (payload) => dbmod.createVehicle(db, payload));
handleGuarded('vehicle:update', 'automobile.vehicles', (id, patch) => dbmod.updateVehicle(db, id, patch));

handle('mechanic:list', (business_id, includeInactive) => dbmod.listMechanics(db, business_id, includeInactive));
handleGuarded('mechanic:create', 'automobile.mechanics', (payload) => dbmod.createMechanic(db, payload));
handleGuarded('mechanic:update', 'automobile.mechanics', (id, patch) => dbmod.updateMechanic(db, id, patch));

handle('serviceJob:list', (business_id, branch_id, status) => dbmod.listServiceJobs(db, business_id, branch_id, status));
handle('serviceJob:get', (id) => dbmod.getServiceJob(db, id));
handle('serviceJob:items', (job_id) => dbmod.getServiceJobItems(db, job_id));
handleGuarded('serviceJob:create', 'automobile.jobs.manage', (payload) => dbmod.createServiceJob(db, payload));
handleGuarded('serviceJob:addItem', 'automobile.jobs.manage', (payload) => dbmod.addServiceJobItem(db, payload));
handleGuarded('serviceJob:removeItem', 'automobile.jobs.manage', (item_id) => dbmod.removeServiceJobItem(db, item_id));
handleGuarded('serviceJob:updateStatus', 'automobile.jobs.manage', (job_id, status, extra) => {
    // Finalizing (marking delivered) is money-and-stock-moving, so it needs the stronger permission
    if (status === 'delivered' && !permsmod.hasPermission(currentUser, 'automobile.jobs.finalize')) {
        throw new Error('Aap ko job finalize karne ki ijazat nahi hai');
    }
    return dbmod.updateServiceJobStatus(db, job_id, status, extra);
});
handle('serviceJob:summary', (business_id, from, to) => dbmod.serviceJobsSummary(db, business_id, from, to));

// Automobile: vehicle stock (bikes/cars/scooters) and sales
handle('vehicleUnit:list', (business_id, opts) => dbmod.listVehicleUnits(db, business_id, opts || {}));
handle('vehicleUnit:get', (id) => dbmod.getVehicleUnit(db, id));
handleGuarded('vehicleUnit:create', 'automobile.vehicleStock.manage', (payload) => dbmod.createVehicleUnit(db, payload));
handleGuarded('vehicleUnit:update', 'automobile.vehicleStock.manage', (id, patch) => dbmod.updateVehicleUnit(db, id, patch));

handle('vehicleSale:list', (business_id, branch_id, from, to) => dbmod.listVehicleSales(db, business_id, branch_id, from, to));
handle('vehicleSale:get', (id) => dbmod.getVehicleSale(db, id));
handleGuarded('vehicleSale:create', 'automobile.vehicleSales.sell', (payload) => dbmod.sellVehicleUnit(db, payload));
handleGuarded('vehicleSale:cancel', 'automobile.vehicleSales.sell', (id) => dbmod.cancelVehicleSale(db, id));
handle('vehicleSale:summary', (business_id, from, to) => dbmod.vehicleSalesSummary(db, business_id, from, to));

// Reports
handle('report:salesSummary', (business_id, from, to) => dbmod.salesSummary(db, business_id, from, to));
handle('report:profitLoss', (business_id, from, to) => dbmod.profitLossReport(db, business_id, from, to));
handle('report:topProducts', (business_id, from, to, limit) => dbmod.topSellingProducts(db, business_id, from, to, limit));

// Backup / Restore
handleGuarded('backup:create', 'settings.backup', async () => {
    dbmod.checkpoint(db);
    const dbPath = dbmod.getDbFilePath(app.getPath('userData'));
    const result = await dialog.showSaveDialog(mainWindow, {
        title: 'Backup Database',
        defaultPath: `wm-pos-erp-backup-${new Date().toISOString().slice(0, 10)}.db`,
        filters: [{ name: 'WM POS ERP Database', extensions: ['db'] }],
    });
    if (result.canceled || !result.filePath) return { cancelled: true };
    fs.copyFileSync(dbPath, result.filePath);
    return { cancelled: false, path: result.filePath };
});

handleGuarded('backup:restore', 'settings.backup', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Restore Database from Backup',
        filters: [{ name: 'WM POS ERP Database', extensions: ['db'] }],
        properties: ['openFile'],
    });
    if (result.canceled || !result.filePaths.length) return { cancelled: true };
    const chosenPath = result.filePaths[0];
    const dbPath = dbmod.getDbFilePath(app.getPath('userData'));

    db.close();
    fs.copyFileSync(chosenPath, dbPath);
    for (const ext of ['-wal', '-shm']) {
        const sidecarPath = dbPath + ext;
        if (fs.existsSync(sidecarPath)) fs.unlinkSync(sidecarPath);
    }
    db = dbmod.openDatabase(app.getPath('userData'));
    return { cancelled: false, restored: true };
});

// ---- Auto-backup settings ----
handle('settings:get', () => appsettings.loadSettings(app.getPath('userData')));
handle('settings:save', (patch) => appsettings.saveSettings(app.getPath('userData'), patch));

handleGuarded('backup:chooseFolder', 'settings.backup', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
        title: 'Choose Backup Folder',
        properties: ['openDirectory', 'createDirectory'],
    });
    if (result.canceled || !result.filePaths.length) return { cancelled: true };
    const folder = result.filePaths[0];
    appsettings.saveSettings(app.getPath('userData'), { backupFolder: folder });
    return { cancelled: false, folder };
});

// Manual "Backup Now" into the configured auto-backup folder
handleGuarded('backup:runNow', 'settings.backup', () => {
    const settings = appsettings.loadSettings(app.getPath('userData'));
    if (!settings.backupFolder) throw new Error('Pehle backup folder choose karein');
    const result = backupmod.runBackup({
        dbPath: dbmod.getDbFilePath(app.getPath('userData')),
        folder: settings.backupFolder,
        keep: settings.keepBackups,
        checkpointFn: () => dbmod.checkpoint(db),
    });
    appsettings.saveSettings(app.getPath('userData'), { lastBackupAt: result.at });
    return result;
});

handle('backup:list', () => {
    const settings = appsettings.loadSettings(app.getPath('userData'));
    return backupmod.listBackups(settings.backupFolder);
});

// Restore directly from one of the listed auto-backups
handleGuarded('backup:restoreFrom', 'settings.backup', (backupPath) => {
    if (!fs.existsSync(backupPath)) throw new Error('Backup file nahi mili');
    const dbPath = dbmod.getDbFilePath(app.getPath('userData'));
    db.close();
    fs.copyFileSync(backupPath, dbPath);
    for (const ext of ['-wal', '-shm']) {
        const sidecarPath = dbPath + ext;
        if (fs.existsSync(sidecarPath)) fs.unlinkSync(sidecarPath);
    }
    db = dbmod.openDatabase(app.getPath('userData'));
    return { restored: true };
});

// ---- Auto-update ----
handle('update:currentVersion', () => app.getVersion());
handle('update:check', () => updatermod.checkForUpdates());
handle('update:download', () => updatermod.downloadUpdate());
handle('update:install', () => { updatermod.quitAndInstall(); return { installing: true }; });

// ---------------- Print preview ----------------
// Printing used to go straight from a hidden iframe to the OS print dialog,
// so there was no real preview. Now every print opens this window: the page
// is shown on screen as a sheet of paper at its real size, with a toolbar to
// print, save a PDF, or switch between A4 / A5 / 80mm.

const PAPER = {
    a4: { label: 'A4', w: 210, h: 297, margin: 10 },
    a5: { label: 'A5', w: 148, h: 210, margin: 7 },
    thermal: { label: '80mm Thermal', w: 80, h: null, margin: 3 },
};

let previewWin = null;
let previewState = null;   // { files: { size: path }, size, title }

function previewChrome(size, available) {
    const p = PAPER[size];
    const sizeButtons = available.map(s =>
        `<button class="wm-size ${s === size ? 'wm-active' : ''}" data-size="${s}">${PAPER[s].label}</button>`).join('');
    const css = `
    <style id="wm-preview-style">
        @page { margin: 0; ${p.h ? `size: ${p.w}mm ${p.h}mm;` : ''} }
        @media screen {
            html { background: #525659 !important; }
            body { width: ${p.w}mm !important; ${p.h ? `min-height: ${p.h}mm;` : ''} margin: 76px auto 36px !important;
                   padding: ${p.margin}mm !important; box-sizing: border-box !important; background: #fff !important;
                   box-shadow: 0 4px 22px rgba(0,0,0,.5); }
            #wm-bar { position: fixed; top: 0; left: 0; right: 0; height: 56px; background: #1f2430; color: #fff;
                      display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 0 18px;
                      font-family: 'Segoe UI', Arial, sans-serif; font-size: 14px; z-index: 99999;
                      box-shadow: 0 2px 10px rgba(0,0,0,.4); box-sizing: border-box; }
            #wm-bar .wm-title { font-weight: 700; }
            #wm-bar .wm-group { display: flex; gap: 6px; align-items: center; }
            #wm-bar button { font-family: inherit; font-size: 13px; font-weight: 600; border: 0; border-radius: 6px;
                             padding: 9px 14px; cursor: pointer; background: #343b4d; color: #fff; }
            #wm-bar button:hover { background: #454e66; }
            #wm-bar .wm-active { background: #4FA8E0; }
            #wm-bar #wm-print { background: #1A3FA0; }
            #wm-bar #wm-msg { font-size: 12px; color: #9fe0b2; min-width: 120px; }
        }
        @media print {
            #wm-bar { display: none !important; }
            html, body { background: #fff !important; }
            body { margin: 0 !important; width: auto !important; min-height: 0 !important; box-shadow: none !important;
                   padding: ${p.margin}mm !important; box-sizing: border-box !important; }
        }
    </style>`;
    const bar = `
    <div id="wm-bar">
        <div class="wm-title">Print Preview</div>
        <div class="wm-group">${sizeButtons}</div>
        <div class="wm-group">
            <span id="wm-msg"></span>
            <button id="wm-print">🖨 Print</button>
            <button id="wm-pdf">Save PDF</button>
            <button id="wm-close">Close</button>
        </div>
    </div>
    <script>
        (function () {
            var size = ${JSON.stringify(size)};
            function contentHeight() { return Math.ceil(document.body.getBoundingClientRect().height); }
            function msg(t) { document.getElementById('wm-msg').textContent = t || ''; }
            document.getElementById('wm-print').onclick = function () {
                window.previewApi.print(size, contentHeight()).then(function (r) {
                    msg(r && r.success ? 'Print bhej diya' : (r && r.reason && r.reason !== 'cancelled' ? 'Print nahi hua: ' + r.reason : ''));
                });
            };
            document.getElementById('wm-pdf').onclick = function () {
                window.previewApi.pdf(size, contentHeight()).then(function (r) {
                    msg(r && r.saved ? 'PDF save ho gayi' : '');
                });
            };
            document.getElementById('wm-close').onclick = function () { window.previewApi.close(); };
            Array.prototype.forEach.call(document.querySelectorAll('.wm-size'), function (b) {
                b.onclick = function () { window.previewApi.setSize(b.getAttribute('data-size')); };
            });
        })();
    </script>`;
    return { css, bar };
}

function writePreviewFile(size, html) {
    const dir = path.join(app.getPath('temp'), 'wm-pos-print');
    fs.mkdirSync(dir, { recursive: true });
    const available = Object.keys(previewState.pages);
    const { css, bar } = previewChrome(size, available);
    let out = html;
    out = out.includes('</head>') ? out.replace('</head>', css + '</head>') : css + out;
    out = /<body[^>]*>/i.test(out) ? out.replace(/<body[^>]*>/i, (m) => m + bar) : bar + out;
    const file = path.join(dir, `preview-${size}.html`);
    fs.writeFileSync(file, out, 'utf8');
    return file;
}

function loadPreviewSize(size) {
    if (!previewWin || previewWin.isDestroyed() || !previewState.pages[size]) return;
    previewState.size = size;
    const file = writePreviewFile(size, previewState.pages[size]);
    previewWin.loadFile(file);
}

// Page size for printing. A4/A5 use standard names; the thermal roll has a
// fixed width and a height taken from the rendered content, so the printer
// doesn't feed out a full sheet of blank paper.
function pageSizeMicrons(size, heightPx) {
    if (size === 'a4') return 'A4';
    if (size === 'a5') return 'A5';
    const mm = Math.max(60, (heightPx || 800) * 25.4 / 96 + 6);
    return { width: 80000, height: Math.ceil(mm * 1000) };
}

handle('print:preview', ({ pages, size, title }) => {
    const available = Object.keys(pages || {}).filter(k => PAPER[k] && pages[k]);
    if (!available.length) throw new Error('Print karne ke liye kuch nahi mila');
    const start = available.includes(size) ? size : available[0];
    previewState = { pages, size: start, title: title || 'Invoice' };

    if (!previewWin || previewWin.isDestroyed()) {
        previewWin = new BrowserWindow({
            width: 1000, height: 900, minWidth: 520, minHeight: 500,
            title: 'Print Preview', parent: mainWindow, autoHideMenuBar: true,
            icon: path.join(__dirname, 'assets', 'icon.png'),
            webPreferences: { preload: path.join(__dirname, 'preview-preload.js'), contextIsolation: true, nodeIntegration: false },
        });
        previewWin.on('closed', () => { previewWin = null; });
    }
    loadPreviewSize(start);
    previewWin.show();
    previewWin.focus();
    return { opened: true, size: start };
});

ipcMain.handle('preview:size', (event, { size }) => { loadPreviewSize(size); return { ok: true }; });
ipcMain.handle('preview:close', () => { if (previewWin && !previewWin.isDestroyed()) previewWin.close(); return { ok: true }; });

ipcMain.handle('preview:print', (event, { size, heightPx }) => new Promise((resolve) => {
    event.sender.print({
        silent: false,
        printBackground: true,
        margins: { marginType: 'none' },
        pageSize: pageSizeMicrons(size, heightPx),
    }, (success, reason) => resolve({ success, reason }));
}));

ipcMain.handle('preview:pdf', async (event, { size, heightPx }) => {
    // printToPDF takes inches, unlike print() which takes microns
    const ps = pageSizeMicrons(size, heightPx);
    const pageSize = typeof ps === 'string' ? ps : { width: ps.width / 25400, height: ps.height / 25400 };
    const data = await event.sender.printToPDF({
        pageSize, printBackground: true, margins: { top: 0, bottom: 0, left: 0, right: 0 },
    });
    const safeTitle = String(previewState ? previewState.title : 'invoice').replace(/[^\w\-]+/g, '_');
    const result = await dialog.showSaveDialog(previewWin || mainWindow, {
        title: 'Save PDF',
        defaultPath: `${safeTitle}-${size}.pdf`,
        filters: [{ name: 'PDF', extensions: ['pdf'] }],
    });
    if (result.canceled || !result.filePath) return { saved: false };
    fs.writeFileSync(result.filePath, data);
    return { saved: true, path: result.filePath };
});
