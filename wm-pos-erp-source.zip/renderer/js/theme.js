// renderer/js/theme.js
// Applies the selected colour theme by setting data-theme on <html>. All theme
// colours live in CSS variables (see css/style.css), so switching is instant
// and no component code needs to know which theme is active.

const THEMES = [
    { id: 'royal',    name: 'Royal Blue',  desc: 'WM brand — default',      swatch: ['#12294A', '#1A3FA0', '#4FA8E0'] },
    { id: 'midnight', name: 'Midnight',    desc: 'Dark — raat ke liye',     swatch: ['#0B1220', '#4C7DF0', '#6FB4F5'] },
    { id: 'emerald',  name: 'Emerald',     desc: 'Calm green',              swatch: ['#10352A', '#157F5C', '#43BC92'] },
    { id: 'sunset',   name: 'Sunset',      desc: 'Warm orange',             swatch: ['#3D1F1B', '#C2572B', '#EE8F4E'] },
    { id: 'slate',    name: 'Slate',       desc: 'Neutral — kam glare',     swatch: ['#232A33', '#3F6DB5', '#6D9BD8'] },
    { id: 'plum',     name: 'Plum',        desc: 'Rich purple',             swatch: ['#2A1B3D', '#6B3FA0', '#A472DB'] },
];

const DEFAULT_THEME = 'royal';

function applyTheme(themeId) {
    const valid = THEMES.some(t => t.id === themeId) ? themeId : DEFAULT_THEME;
    document.documentElement.setAttribute('data-theme', valid);
    return valid;
}

// Called once at startup, before the UI renders, so there's no colour flash.
async function initTheme() {
    try {
        const res = await window.api.settings.get();
        const themeId = (res && res.ok && res.data && res.data.theme) || DEFAULT_THEME;
        return applyTheme(themeId);
    } catch (err) {
        return applyTheme(DEFAULT_THEME);
    }
}

async function saveTheme(themeId) {
    const applied = applyTheme(themeId);
    await window.api.settings.save({ theme: applied });
    return applied;
}
