const SalesPage = {
    async render() {
        const container = document.getElementById('page-sales');
        if (!AppState.business || !AppState.branch) {
            container.innerHTML = `<div class="empty-state">Pehle koi business aur branch select karein.</div>`;
            return;
        }
        const month = monthRange();
        container.innerHTML = `
            <div class="page-header"><h2>Sales History</h2></div>
            <div class="toolbar">
                <label style="margin:0;">From</label><input type="date" id="sh-from" value="${month.from.slice(0,10)}" />
                <label style="margin:0;">To</label><input type="date" id="sh-to" value="${month.to.slice(0,10)}" />
                <button id="sh-run" class="btn btn-primary btn-sm">Filter</button>
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>Payment</th><th class="text-right">Total</th><th class="text-right">Paid</th><th>Status</th><th></th></tr></thead>
                    <tbody id="sh-table-body"></tbody>
                </table>
            </div>
        `;
        document.getElementById('sh-run').addEventListener('click', () => this.load());
        await this.load();
    },

    async load() {
        const from = document.getElementById('sh-from').value + ' 00:00:00';
        const to = document.getElementById('sh-to').value + ' 23:59:59';
        const sales = await call(window.api.sale.list(AppState.business.id, AppState.branch.id, from, to));
        const tbody = document.getElementById('sh-table-body');
        if (!sales.length) {
            tbody.innerHTML = `<tr><td colspan="8" class="empty-state">Is date range mein koi sale nahi.</td></tr>`;
            return;
        }
        tbody.innerHTML = sales.map(s => `
            <tr>
                <td>${s.invoice_no}</td>
                <td>${s.sale_date}</td>
                <td>${s.customer_name || 'Walk-in'}</td>
                <td>${s.payment_method}</td>
                <td class="text-right">${money(s.total)}</td>
                <td class="text-right">${money(s.paid_amount)}</td>
                <td><span class="badge ${s.status === 'refunded' ? 'red' : 'green'}">${s.status}</span></td>
                <td>
                    <button class="btn-link" data-act="view" data-id="${s.id}">View</button>
                    ${(s.status !== 'refunded' && can('sales.refund')) ? `<button class="btn-link" data-act="refund" data-id="${s.id}" style="color:var(--red);">Refund</button>` : ''}
                </td>
            </tr>
        `).join('');

        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = Number(btn.dataset.id);
                const sale = sales.find(s => s.id === id);
                if (btn.dataset.act === 'view') this.viewSale(sale);
                else this.confirmRefund(sale);
            });
        });
    },

    async viewSale(sale) {
        const items = await call(window.api.sale.items(sale.id));
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>Invoice ${sale.invoice_no}</h3>
                    <p class="hint">${sale.sale_date} — ${sale.customer_name || 'Walk-in'} — <span class="badge ${sale.status === 'refunded' ? 'red' : 'green'}">${sale.status}</span></p>
                    <table>
                        <thead><tr><th>Item</th><th class="text-right">Qty</th><th class="text-right">Price</th><th class="text-right">Total</th></tr></thead>
                        <tbody>${items.map(it => `<tr><td>${esc(it.product_name)}${it.chassis_no ? '<br/><span style="color:var(--text-muted); font-size:11px;">Chassis: ' + esc(it.chassis_no) + (it.motor_no ? ' • Motor: ' + esc(it.motor_no) : '') + '</span>' : ''}</td><td class="text-right">${it.quantity}</td><td class="text-right">${money(it.unit_price)}</td><td class="text-right">${money(it.total)}</td></tr>`).join('')}</tbody>
                    </table>
                    <div style="text-align:right; margin-top:10px; font-weight:700;">Total: ${money(sale.total)}</div>
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="view-close">Close</button>
                        ${can('sales.reprint') ? '<button class="btn btn-primary" id="view-print">Print Receipt</button>' : ''}
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#view-close').addEventListener('click', () => overlay.remove());
        const printBtn = overlay.querySelector('#view-print');
        if (printBtn) printBtn.addEventListener('click', async () => {
            const customer = sale.customer_id ? await call(window.api.customer.get(sale.customer_id)) : null;
            printReceipt({ business: AppState.business, branch: AppState.branch, sale, items, customer });
        });
    },

    confirmRefund(sale) {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>Refund Invoice ${sale.invoice_no}?</h3>
                    <p class="hint">Ye stock wapis add karega aur accounts mein reverse entry post karega. Ye action wapas nahi ho sakta.</p>
                    <label>Reason (optional)</label>
                    <input type="text" id="refund-reason" placeholder="e.g. customer returned item" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="refund-cancel">Cancel</button>
                        <button class="btn btn-danger" id="refund-confirm">Confirm Refund</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#refund-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#refund-confirm').addEventListener('click', async () => {
            try {
                await call(window.api.sale.refund({
                    sale_id: sale.id, business_id: AppState.business.id, branch_id: AppState.branch.id,
                    user_id: AppState.user.id, reason: overlay.querySelector('#refund-reason').value,
                }));
                showToast('Sale refunded, stock restored', 'success');
                overlay.remove();
                this.load();
            } catch (e) { /* toast already shown */ }
        });
    },
};
