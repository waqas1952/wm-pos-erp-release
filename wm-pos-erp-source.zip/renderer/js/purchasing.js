const PurchasingPage = {
    products: [],
    suppliers: [],
    cart: [],

    async render() {
        const container = document.getElementById('page-purchasing');
        if (!AppState.business || !AppState.branch) {
            container.innerHTML = `<div class="empty-state">Pehle koi business aur branch select karein.</div>`;
            return;
        }
        this.cart = [];
        container.innerHTML = `
            <div class="page-header">
                <h2>Purchasing</h2>
                <div style="display:flex; gap:8px;">
                    ${can('purchasing.manage') ? '<button id="pur-add-supplier" class="btn btn-secondary">+ Supplier</button>' : ''}
                    ${can('purchasing.manage') ? '<button id="pur-new" class="btn btn-primary">+ New Purchase</button>' : ''}
                </div>
            </div>
            <div class="card">
                <h3 style="margin-top:0;">Recent Purchases</h3>
                <table>
                    <thead><tr><th>Invoice</th><th>Supplier</th><th>Date</th><th class="text-right">Total</th><th class="text-right">Paid</th><th class="text-right">Balance</th></tr></thead>
                    <tbody id="pur-table-body"></tbody>
                </table>
            </div>
        `;
        this.suppliers = await call(window.api.supplier.list(AppState.business.id));
        this.products = await call(window.api.product.list(AppState.business.id, {}));
        await this.loadTable();

        const addSup = document.getElementById('pur-add-supplier');
        if (addSup) addSup.addEventListener('click', () => this.openSupplierModal());
        const newPur = document.getElementById('pur-new');
        if (newPur) newPur.addEventListener('click', () => this.openPurchaseModal());
    },

    async loadTable() {
        const purchases = await call(window.api.purchase.list(AppState.business.id, AppState.branch.id));
        const tbody = document.getElementById('pur-table-body');
        if (!purchases.length) {
            tbody.innerHTML = `<tr><td colspan="6" class="empty-state">Koi purchase record nahi.</td></tr>`;
            return;
        }
        tbody.innerHTML = purchases.map(p => `
            <tr>
                <td>${p.invoice_no || '#' + p.id}</td>
                <td>${p.supplier_name || '-'}</td>
                <td>${p.purchase_date}</td>
                <td class="text-right">${money(p.total_amount)}</td>
                <td class="text-right">${money(p.paid_amount)}</td>
                <td class="text-right">${money(p.total_amount - p.paid_amount)}</td>
            </tr>
        `).join('');
    },

    openSupplierModal() {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>New Supplier</h3>
                    <label>Name</label><input type="text" id="sup-name" />
                    <label>Phone</label><input type="text" id="sup-phone" />
                    <label>Address</label><input type="text" id="sup-address" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="sup-cancel">Cancel</button>
                        <button class="btn btn-primary" id="sup-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#sup-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#sup-save').addEventListener('click', async () => {
            const name = overlay.querySelector('#sup-name').value.trim();
            if (!name) { showToast('Name required', 'error'); return; }
            await call(window.api.supplier.create({
                business_id: AppState.business.id, name,
                phone: overlay.querySelector('#sup-phone').value,
                address: overlay.querySelector('#sup-address').value,
            }));
            this.suppliers = await call(window.api.supplier.list(AppState.business.id));
            showToast('Supplier added', 'success');
            overlay.remove();
        });
    },

    openPurchaseModal() {
        this.cart = [];
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box" style="width:640px;">
                    <h3>New Purchase</h3>
                    <div class="grid-2">
                        <div><label>Supplier</label><select id="po-supplier"><option value="">-- none --</option>${this.suppliers.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}</select></div>
                        <div><label>Invoice / Ref No.</label><input type="text" id="po-invoice" /></div>
                    </div>
                    <hr/>
                    <label>Add Item</label>
                    <div class="grid-3">
                        <select id="po-product">${this.products.map(p => `<option value="${p.id}" data-cost="${p.cost_price}">${p.name}</option>`).join('')}</select>
                        <input type="number" id="po-qty" placeholder="Qty" value="1" min="1" />
                        <input type="number" id="po-cost" placeholder="Cost Price" value="0" />
                    </div>
                    <button class="btn btn-secondary btn-sm" id="po-add-item" style="margin-top:8px;">+ Add to List</button>

                    <table style="margin-top:12px;">
                        <thead><tr><th>Product</th><th class="text-right">Qty</th><th class="text-right">Cost</th><th class="text-right">Total</th><th></th></tr></thead>
                        <tbody id="po-items"></tbody>
                    </table>

                    <div class="grid-2" style="margin-top:10px;">
                        <div><label>Amount Paid Now</label><input type="number" id="po-paid" value="0" /></div>
                        <div><label>Payment Account</label>
                            <select id="po-account"><option value="Cash in Hand">Cash</option><option value="Bank Account">Bank</option></select>
                        </div>
                    </div>
                    <div style="text-align:right; font-weight:700; margin-top:8px;" id="po-grand-total">Total: Rs 0</div>

                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="po-cancel">Cancel</button>
                        <button class="btn btn-primary" id="po-save">Save Purchase</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);

        const productSelect = overlay.querySelector('#po-product');
        productSelect.addEventListener('change', () => {
            const opt = productSelect.selectedOptions[0];
            overlay.querySelector('#po-cost').value = opt.dataset.cost;
        });
        if (productSelect.options.length) overlay.querySelector('#po-cost').value = productSelect.selectedOptions[0].dataset.cost;

        const renderItems = () => {
            const tbody = overlay.querySelector('#po-items');
            tbody.innerHTML = this.cart.map((c, i) => `
                <tr><td>${c.name}</td><td class="text-right">${c.quantity}</td><td class="text-right">${money(c.cost_price)}</td>
                <td class="text-right">${money(c.quantity * c.cost_price)}</td>
                <td><button data-i="${i}" class="btn-link po-rm" style="color:var(--red);">✕</button></td></tr>
            `).join('');
            tbody.querySelectorAll('.po-rm').forEach(btn => btn.addEventListener('click', () => { this.cart.splice(Number(btn.dataset.i), 1); renderItems(); }));
            const total = this.cart.reduce((s, c) => s + c.quantity * c.cost_price, 0);
            overlay.querySelector('#po-grand-total').textContent = 'Total: ' + money(total);
            overlay.querySelector('#po-paid').value = total;
        };

        overlay.querySelector('#po-add-item').addEventListener('click', () => {
            const opt = productSelect.selectedOptions[0];
            if (!opt) return;
            const productId = Number(opt.value);
            const product = this.products.find(p => p.id === productId);
            const qty = Number(overlay.querySelector('#po-qty').value || 1);
            const cost = Number(overlay.querySelector('#po-cost').value || 0);
            this.cart.push({ product_id: productId, name: product.name, quantity: qty, cost_price: cost });
            renderItems();
        });

        overlay.querySelector('#po-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#po-save').addEventListener('click', async () => {
            if (!this.cart.length) { showToast('Kam az kam ek item add karein', 'error'); return; }
            const supplierId = overlay.querySelector('#po-supplier').value ? Number(overlay.querySelector('#po-supplier').value) : null;
            await call(window.api.purchase.create({
                business_id: AppState.business.id,
                branch_id: AppState.branch.id,
                supplier_id: supplierId,
                invoice_no: overlay.querySelector('#po-invoice').value,
                items: this.cart,
                paid_amount: Number(overlay.querySelector('#po-paid').value || 0),
                payment_account_name: overlay.querySelector('#po-account').value,
                user_id: AppState.user.id,
            }));
            showToast('Purchase saved, stock updated', 'success');
            overlay.remove();
            this.loadTable();
        });
    },
};
