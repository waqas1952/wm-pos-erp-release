const AccountsPage = {
    accounts: [],

    async render() {
        const container = document.getElementById('page-accounts');
        if (!AppState.business) {
            container.innerHTML = `<div class="empty-state">Pehle koi business select karein.</div>`;
            return;
        }
        container.innerHTML = `
            <div class="page-header">
                <h2>Accounts</h2>
                ${can('accounts.expense') ? '<button id="acc-add-expense" class="btn btn-primary">+ Record Expense</button>' : ''}
            </div>
            <div class="grid-3" id="acc-balances" style="margin-bottom:18px;"></div>
            <div class="card">
                <div class="toolbar">
                    <select id="acc-select"></select>
                </div>
                <table>
                    <thead><tr><th>Date</th><th>Description</th><th>Type</th><th class="text-right">Debit</th><th class="text-right">Credit</th></tr></thead>
                    <tbody id="acc-ledger-body"></tbody>
                </table>
            </div>
        `;
        this.accounts = await call(window.api.account.list(AppState.business.id));
        await this.renderBalances();

        const select = document.getElementById('acc-select');
        select.innerHTML = this.accounts.map(a => `<option value="${a.id}">${a.name}</option>`).join('');
        select.addEventListener('change', () => this.loadLedger(Number(select.value)));
        if (this.accounts.length) this.loadLedger(this.accounts[0].id);

        const addExp = document.getElementById('acc-add-expense');
        if (addExp) addExp.addEventListener('click', () => this.openExpenseModal());
    },

    async renderBalances() {
        const balancesEl = document.getElementById('acc-balances');
        const balances = await Promise.all(this.accounts.map(a => call(window.api.account.balance(a.id))));
        balancesEl.innerHTML = this.accounts.map((a, i) => `
            <div class="stat-card">
                <div class="label">${a.name}</div>
                <div class="value ${balances[i] < 0 ? 'red' : ''}">${money(balances[i])}</div>
            </div>
        `).join('');
    },

    async loadLedger(accountId) {
        const entries = await call(window.api.ledger.list(AppState.business.id, accountId, null, null));
        const tbody = document.getElementById('acc-ledger-body');
        if (!entries.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Is account mein koi entry nahi.</td></tr>`;
            return;
        }
        tbody.innerHTML = entries.map(e => `
            <tr>
                <td>${e.entry_date}</td>
                <td>${e.description}</td>
                <td><span class="badge amber">${e.reference_type}</span></td>
                <td class="text-right">${e.debit ? money(e.debit) : '-'}</td>
                <td class="text-right">${e.credit ? money(e.credit) : '-'}</td>
            </tr>
        `).join('');
    },

    openExpenseModal() {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>Record Expense</h3>
                    <label>Category</label>
                    <input type="text" id="exp-category" placeholder="e.g. Rent, Electricity, Salary" />
                    <label>Description</label>
                    <input type="text" id="exp-desc" />
                    <label>Amount</label>
                    <input type="number" id="exp-amount" value="0" />
                    <label>Paid From</label>
                    <select id="exp-account"><option value="Cash in Hand">Cash</option><option value="Bank Account">Bank</option></select>
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="exp-cancel">Cancel</button>
                        <button class="btn btn-primary" id="exp-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#exp-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#exp-save').addEventListener('click', async () => {
            const amount = Number(overlay.querySelector('#exp-amount').value || 0);
            if (!amount) { showToast('Amount required', 'error'); return; }
            await call(window.api.expense.create({
                business_id: AppState.business.id,
                branch_id: AppState.branch ? AppState.branch.id : null,
                category: overlay.querySelector('#exp-category').value || 'general',
                description: overlay.querySelector('#exp-desc').value,
                amount,
                payment_account_name: overlay.querySelector('#exp-account').value,
                user_id: AppState.user.id,
            }));
            showToast('Expense recorded', 'success');
            overlay.remove();
            this.render();
        });
    },
};
