const AutomobilePage = {
    tab: 'jobs',
    vehicles: [],
    mechanics: [],
    customers: [],
    products: [],
    vehicleUnits: [],

    async render() {
        const container = document.getElementById('page-automobile');
        if (!AppState.business || !AppState.branch) {
            container.innerHTML = `<div class="empty-state">Pehle koi business aur branch select karein.</div>`;
            return;
        }
        container.innerHTML = `
            <div class="page-header"><h2>Automobile</h2></div>
            <div class="toolbar" style="margin-bottom:16px; flex-wrap:wrap;">
                <button class="btn ${this.tab === 'jobs' ? 'btn-primary' : 'btn-secondary'} btn-sm" data-tab="jobs">Service Jobs</button>
                <button class="btn ${this.tab === 'stock' ? 'btn-primary' : 'btn-secondary'} btn-sm" data-tab="stock">Vehicle Stock</button>
                <button class="btn ${this.tab === 'sales' ? 'btn-primary' : 'btn-secondary'} btn-sm" data-tab="sales">Vehicle Sales</button>
                <button class="btn ${this.tab === 'vehicles' ? 'btn-primary' : 'btn-secondary'} btn-sm" data-tab="vehicles">Customer Vehicles</button>
                <button class="btn ${this.tab === 'mechanics' ? 'btn-primary' : 'btn-secondary'} btn-sm" data-tab="mechanics">Mechanics</button>
            </div>
            <div id="auto-tab-content"></div>
        `;
        container.querySelectorAll('[data-tab]').forEach(btn => {
            btn.addEventListener('click', () => { this.tab = btn.dataset.tab; this.render(); });
        });

        if (this.tab === 'jobs') await this.renderJobsTab();
        else if (this.tab === 'stock') await this.renderStockTab();
        else if (this.tab === 'sales') await this.renderSalesTab();
        else if (this.tab === 'vehicles') await this.renderVehiclesTab();
        else await this.renderMechanicsTab();
    },

    statusBadge(status) {
        const map = {
            pending: 'amber', in_progress: 'amber', completed: 'green',
            delivered: 'green', cancelled: 'red',
        };
        const label = { pending: 'Pending', in_progress: 'In Progress', completed: 'Completed', delivered: 'Delivered', cancelled: 'Cancelled' }[status] || status;
        return `<span class="badge ${map[status] || 'amber'}">${label}</span>`;
    },

    // ==================== JOBS TAB ====================
    async renderJobsTab() {
        const box = document.getElementById('auto-tab-content');
        box.innerHTML = `
            <div class="toolbar">
                <select id="job-status-filter">
                    <option value="">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="in_progress">In Progress</option>
                    <option value="completed">Completed</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                </select>
                ${can('automobile.jobs.manage') ? '<button id="job-new" class="btn btn-primary btn-sm">+ New Job</button>' : ''}
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Job #</th><th>Vehicle</th><th>Customer</th><th>Mechanic</th><th>Status</th><th class="text-right">Total</th><th>Opened</th><th></th></tr></thead>
                    <tbody id="job-table-body"></tbody>
                </table>
            </div>
        `;
        await this.loadJobsTable();
        document.getElementById('job-status-filter').addEventListener('change', () => this.loadJobsTable());
        const newBtn = document.getElementById('job-new');
        if (newBtn) newBtn.addEventListener('click', () => this.openNewJobModal());
    },

    async loadJobsTable() {
        const status = document.getElementById('job-status-filter').value;
        const jobs = await call(window.api.serviceJob.list(AppState.business.id, AppState.branch.id, status || null));
        const tbody = document.getElementById('job-table-body');
        if (!jobs.length) {
            tbody.innerHTML = `<tr><td colspan="8" class="empty-state">Koi service job nahi mili.</td></tr>`;
            return;
        }
        tbody.innerHTML = jobs.map(j => `
            <tr>
                <td>${esc(j.job_no)}</td>
                <td>${esc(j.registration_no)} <span style="color:var(--text-muted);">${esc(j.make || '')} ${esc(j.model || '')}</span></td>
                <td>${esc(j.customer_name || '-')}</td>
                <td>${esc(j.mechanic_name || '-')}</td>
                <td>${this.statusBadge(j.status)}</td>
                <td class="text-right">${money(j.total)}</td>
                <td>${j.opened_date}</td>
                <td><button class="btn-link" data-id="${j.id}">Open</button></td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => this.openJobDetail(Number(btn.dataset.id)));
        });
    },

    async openNewJobModal() {
        this.vehicles = await call(window.api.vehicle.list(AppState.business.id));
        this.mechanics = await call(window.api.mechanic.list(AppState.business.id));

        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>New Service Job</h3>
                    <label>Vehicle</label>
                    <div style="display:flex; gap:8px;">
                        <select id="job-vehicle" style="flex:1;">
                            <option value="">-- select vehicle --</option>
                            ${this.vehicles.map(v => `<option value="${v.id}">${esc(v.registration_no)} — ${esc(v.make || '')} ${esc(v.model || '')} ${v.customer_name ? '(' + esc(v.customer_name) + ')' : ''}</option>`).join('')}
                        </select>
                        <button class="btn btn-secondary btn-sm" id="job-new-vehicle" style="white-space:nowrap;">+ New</button>
                    </div>
                    <label>Mechanic (optional)</label>
                    <select id="job-mechanic"><option value="">-- unassigned --</option>${this.mechanics.map(m => `<option value="${m.id}">${esc(m.name)}</option>`).join('')}</select>
                    <label>Odometer Reading (optional)</label>
                    <input type="text" id="job-odometer" placeholder="e.g. 45000 km" />
                    <label>Complaint / Work Requested</label>
                    <input type="text" id="job-complaint" placeholder="e.g. Brake noise, oil change" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="job-cancel">Cancel</button>
                        <button class="btn btn-primary" id="job-create">Open Job</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);

        overlay.querySelector('#job-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#job-new-vehicle').addEventListener('click', () => {
            overlay.remove();
            this.openVehicleModal(null, (newVehicleId) => {
                this.openNewJobModal().then(() => {
                    setTimeout(() => {
                        const sel = document.getElementById('job-vehicle');
                        if (sel) sel.value = newVehicleId;
                    }, 50);
                });
            });
        });

        overlay.querySelector('#job-create').addEventListener('click', async () => {
            const vehicle_id = Number(overlay.querySelector('#job-vehicle').value);
            if (!vehicle_id) { showToast('Vehicle select karein', 'error'); return; }
            const vehicle = this.vehicles.find(v => v.id === vehicle_id);
            try {
                const jobId = await call(window.api.serviceJob.create({
                    business_id: AppState.business.id, branch_id: AppState.branch.id,
                    vehicle_id, customer_id: vehicle ? vehicle.customer_id : null,
                    mechanic_id: overlay.querySelector('#job-mechanic').value ? Number(overlay.querySelector('#job-mechanic').value) : null,
                    complaint: overlay.querySelector('#job-complaint').value.trim(),
                    odometer_reading: overlay.querySelector('#job-odometer').value.trim(),
                    user_id: AppState.user.id,
                }));
                showToast('Job opened: ' + jobId, 'success');
                overlay.remove();
                await this.loadJobsTable();
                this.openJobDetail(jobId);
            } catch (e) { /* toast shown */ }
        });
    },

    async openJobDetail(jobId) {
        const job = await call(window.api.serviceJob.get(jobId));
        const items = await call(window.api.serviceJob.items(jobId));
        const isOpen = job.status !== 'delivered' && job.status !== 'cancelled';

        this.products = await call(window.api.product.list(AppState.business.id, {}));

        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box" style="max-width:640px;">
                    <h3>${esc(job.job_no)} ${this.statusBadge(job.status)}</h3>
                    <p class="hint">
                        <strong>${esc(job.registration_no)}</strong> — ${esc(job.make || '')} ${esc(job.model || '')} ${job.vehicle_year ? '(' + esc(job.vehicle_year) + ')' : ''}<br/>
                        ${job.customer_name ? 'Customer: ' + esc(job.customer_name) + (job.customer_phone ? ' — ' + esc(job.customer_phone) : '') + '<br/>' : ''}
                        ${job.mechanic_name ? 'Mechanic: ' + esc(job.mechanic_name) + '<br/>' : ''}
                        ${job.odometer_reading ? 'Odometer: ' + esc(job.odometer_reading) + '<br/>' : ''}
                        Complaint: ${esc(job.complaint || '-')}
                    </p>

                    <table>
                        <thead><tr><th>Item</th><th class="text-right">Qty</th><th class="text-right">Price</th><th class="text-right">Total</th>${isOpen && can('automobile.jobs.manage') ? '<th></th>' : ''}</tr></thead>
                        <tbody id="job-items-body"></tbody>
                    </table>
                    <div style="text-align:right; margin-top:8px; font-weight:700;">Subtotal: ${money(job.subtotal)}</div>

                    ${isOpen && can('automobile.jobs.manage') ? `
                    <div style="margin-top:14px; border-top:1px solid var(--border); padding-top:12px;">
                        <label>Add Item</label>
                        <div class="grid-2">
                            <select id="job-item-type">
                                <option value="part">Part (from inventory)</option>
                                <option value="labor">Labor / Service</option>
                            </select>
                            <div></div>
                        </div>
                        <div id="job-item-part-fields" class="grid-3">
                            <select id="job-item-product">${this.products.map(p => `<option value="${p.id}" data-price="${p.sale_price}">${esc(p.name)}</option>`).join('')}</select>
                            <input type="number" id="job-item-qty" value="1" min="1" placeholder="Qty" />
                            <input type="number" id="job-item-price" value="0" placeholder="Price" />
                        </div>
                        <div id="job-item-labor-fields" class="grid-2 hidden">
                            <input type="text" id="job-item-desc" placeholder="e.g. Labor - brake replacement" />
                            <input type="number" id="job-item-labor-price" value="0" placeholder="Amount" />
                        </div>
                        <button class="btn btn-secondary btn-sm" id="job-add-item" style="margin-top:8px;">+ Add to Job</button>
                    </div>` : ''}

                    ${isOpen && can('automobile.jobs.manage') ? `
                    <div style="margin-top:14px; border-top:1px solid var(--border); padding-top:12px; display:flex; gap:8px; flex-wrap:wrap;">
                        ${job.status === 'pending' ? '<button class="btn btn-secondary btn-sm" id="job-start">Start Job</button>' : ''}
                        ${job.status === 'in_progress' ? '<button class="btn btn-secondary btn-sm" id="job-complete">Mark Completed</button>' : ''}
                        ${(job.status === 'completed' || job.status === 'in_progress' || job.status === 'pending') && can('automobile.jobs.finalize') ? '<button class="btn btn-primary btn-sm" id="job-finalize">Finalize &amp; Deliver</button>' : ''}
                        <button class="btn btn-danger btn-sm" id="job-cancel-job">Cancel Job</button>
                    </div>` : ''}

                    ${!isOpen ? `<div style="text-align:right; margin-top:10px;"><strong>Total: ${money(job.total)}</strong> — Paid: ${money(job.paid_amount)} — Balance: ${money(job.total - job.paid_amount)}</div>
                    <div class="modal-actions"><button class="btn btn-secondary" id="job-print">Print</button></div>` : ''}

                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="job-close">Close</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);

        const renderItems = (itemsList) => {
            const tbody = overlay.querySelector('#job-items-body');
            tbody.innerHTML = itemsList.length ? itemsList.map(it => `
                <tr>
                    <td>${esc(it.product_name || it.description)}</td>
                    <td class="text-right">${it.quantity}</td>
                    <td class="text-right">${money(it.unit_price)}</td>
                    <td class="text-right">${money(it.total)}</td>
                    ${isOpen && can('automobile.jobs.manage') ? `<td><button class="btn-link jli-rm" data-id="${it.id}" style="color:var(--red);">✕</button></td>` : ''}
                </tr>`).join('') : `<tr><td colspan="5" class="empty-state">Koi item nahi. Parts ya labor add karein.</td></tr>`;
            tbody.querySelectorAll('.jli-rm').forEach(btn => btn.addEventListener('click', async () => {
                await call(window.api.serviceJob.removeItem(Number(btn.dataset.id)));
                overlay.remove();
                this.openJobDetail(jobId);
            }));
        };
        renderItems(items);

        overlay.querySelector('#job-close').addEventListener('click', () => { overlay.remove(); this.loadJobsTable(); });

        const typeSelect = overlay.querySelector('#job-item-type');
        if (typeSelect) {
            typeSelect.addEventListener('change', () => {
                const isPart = typeSelect.value === 'part';
                overlay.querySelector('#job-item-part-fields').classList.toggle('hidden', !isPart);
                overlay.querySelector('#job-item-labor-fields').classList.toggle('hidden', isPart);
            });
            const productSelect = overlay.querySelector('#job-item-product');
            const syncPrice = () => {
                const opt = productSelect.selectedOptions[0];
                if (opt) overlay.querySelector('#job-item-price').value = opt.dataset.price;
            };
            productSelect.addEventListener('change', syncPrice);
            syncPrice();

            overlay.querySelector('#job-add-item').addEventListener('click', async () => {
                const isPart = typeSelect.value === 'part';
                try {
                    if (isPart) {
                        const opt = productSelect.selectedOptions[0];
                        if (!opt) { showToast('Part select karein', 'error'); return; }
                        await call(window.api.serviceJob.addItem({
                            job_id: jobId, product_id: Number(opt.value), description: opt.textContent,
                            quantity: Number(overlay.querySelector('#job-item-qty').value || 1),
                            unit_price: Number(overlay.querySelector('#job-item-price').value || 0),
                        }));
                    } else {
                        const desc = overlay.querySelector('#job-item-desc').value.trim();
                        if (!desc) { showToast('Labor description likhein', 'error'); return; }
                        await call(window.api.serviceJob.addItem({
                            job_id: jobId, product_id: null, description: desc, quantity: 1,
                            unit_price: Number(overlay.querySelector('#job-item-labor-price').value || 0),
                        }));
                    }
                    overlay.remove();
                    this.openJobDetail(jobId);
                } catch (e) { /* toast shown */ }
            });
        }

        const startBtn = overlay.querySelector('#job-start');
        if (startBtn) startBtn.addEventListener('click', async () => {
            await call(window.api.serviceJob.updateStatus(jobId, 'in_progress'));
            overlay.remove(); this.openJobDetail(jobId);
        });
        const completeBtn = overlay.querySelector('#job-complete');
        if (completeBtn) completeBtn.addEventListener('click', async () => {
            await call(window.api.serviceJob.updateStatus(jobId, 'completed'));
            overlay.remove(); this.openJobDetail(jobId);
        });
        const cancelJobBtn = overlay.querySelector('#job-cancel-job');
        if (cancelJobBtn) cancelJobBtn.addEventListener('click', async () => {
            if (!confirm('Ye job cancel karein? Wapas nahi ho sakta.')) return;
            try {
                await call(window.api.serviceJob.updateStatus(jobId, 'cancelled'));
                showToast('Job cancelled', 'success');
                overlay.remove(); this.loadJobsTable();
            } catch (e) { /* toast shown */ }
        });
        const finalizeBtn = overlay.querySelector('#job-finalize');
        if (finalizeBtn) finalizeBtn.addEventListener('click', () => { overlay.remove(); this.openFinalizeModal(jobId, job); });

        const printBtn = overlay.querySelector('#job-print');
        if (printBtn) printBtn.addEventListener('click', async () => {
            const customer = job.customer_id ? await call(window.api.customer.get(job.customer_id)) : null;
            printReceipt({
                business: AppState.business, branch: AppState.branch, customer,
                sale: { invoice_no: job.job_no, sale_date: job.closed_date || job.opened_date, subtotal: job.subtotal, discount: job.discount, total: job.total, paid_amount: job.paid_amount, payment_method: job.payment_method, customer_name: job.customer_name },
                items: items.map(it => ({ product_name: it.product_name || it.description, quantity: it.quantity, unit_price: it.unit_price, total: it.total })),
            });
        });
    },

    openFinalizeModal(jobId, job) {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>Finalize &amp; Deliver — ${esc(job.job_no)}</h3>
                    <div style="display:flex; justify-content:space-between; font-size:16px; margin-bottom:10px;"><span>Subtotal</span><span>${money(job.subtotal)}</span></div>
                    <label>Discount</label><input type="number" id="fin-discount" value="${job.discount || 0}" />
                    <label>Tax</label><input type="number" id="fin-tax" value="${job.tax || 0}" />
                    <label>Payment Method</label>
                    <select id="fin-method"><option value="cash">Cash</option><option value="card">Card</option><option value="bank">Bank Transfer</option><option value="easypaisa">Easypaisa</option><option value="jazzcash">JazzCash</option><option value="credit">Credit (Udhaar)</option></select>
                    <label>Amount Paid Now</label><input type="number" id="fin-paid" value="${job.subtotal}" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="fin-cancel">Cancel</button>
                        <button class="btn btn-primary" id="fin-confirm">Confirm &amp; Deliver</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);

        const recalc = () => {
            const disc = Number(overlay.querySelector('#fin-discount').value || 0);
            const tax = Number(overlay.querySelector('#fin-tax').value || 0);
            const total = Math.max(0, job.subtotal - disc + tax);
            overlay.querySelector('#fin-paid').value = total;
        };
        overlay.querySelector('#fin-discount').addEventListener('input', recalc);
        overlay.querySelector('#fin-tax').addEventListener('input', recalc);

        overlay.querySelector('#fin-cancel').addEventListener('click', () => { overlay.remove(); this.openJobDetail(jobId); });
        overlay.querySelector('#fin-confirm').addEventListener('click', async () => {
            try {
                await call(window.api.serviceJob.updateStatus(jobId, 'delivered', {
                    discount: Number(overlay.querySelector('#fin-discount').value || 0),
                    tax: Number(overlay.querySelector('#fin-tax').value || 0),
                    paid_amount: Number(overlay.querySelector('#fin-paid').value || 0),
                    payment_method: overlay.querySelector('#fin-method').value,
                }));
                showToast('Job delivered aur bill ho gayi', 'success');
                overlay.remove();
                await this.loadJobsTable();
                this.openJobDetail(jobId);
            } catch (e) { /* toast shown */ }
        });
    },

    // ==================== VEHICLES TAB ====================
    async renderVehiclesTab() {
        const box = document.getElementById('auto-tab-content');
        box.innerHTML = `
            <div class="toolbar">
                <input type="text" id="veh-search" placeholder="Search by registration number..." />
                ${can('automobile.vehicles') ? '<button id="veh-new" class="btn btn-primary btn-sm">+ Add Vehicle</button>' : ''}
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Registration</th><th>Make / Model</th><th>Year</th><th>Customer</th><th></th></tr></thead>
                    <tbody id="veh-table-body"></tbody>
                </table>
            </div>
        `;
        await this.loadVehiclesTable();
        document.getElementById('veh-search').addEventListener('input', (e) => this.loadVehiclesTable(e.target.value));
        const newBtn = document.getElementById('veh-new');
        if (newBtn) newBtn.addEventListener('click', () => this.openVehicleModal());
    },

    async loadVehiclesTable(search) {
        const vehicles = await call(window.api.vehicle.list(AppState.business.id, search));
        const tbody = document.getElementById('veh-table-body');
        if (!vehicles.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Koi vehicle nahi mili.</td></tr>`;
            return;
        }
        tbody.innerHTML = vehicles.map(v => `
            <tr>
                <td><strong>${esc(v.registration_no)}</strong></td>
                <td>${esc(v.make || '-')} ${esc(v.model || '')}</td>
                <td>${esc(v.year || '-')}</td>
                <td>${esc(v.customer_name || '-')} ${v.customer_phone ? '<br/><span style="color:var(--text-muted); font-size:11px;">' + esc(v.customer_phone) + '</span>' : ''}</td>
                <td>${can('automobile.vehicles') ? `<button class="btn-link" data-id="${v.id}">Edit</button>` : ''}</td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', async () => {
                const v = await call(window.api.vehicle.get(Number(btn.dataset.id)));
                this.openVehicleModal(v);
            });
        });
    },

    async openVehicleModal(vehicle, onCreated) {
        const isEdit = !!vehicle;
        this.customers = await call(window.api.customer.list(AppState.business.id));

        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>${isEdit ? 'Edit Vehicle' : 'New Vehicle'}</h3>
                    <label>Registration Number</label><input type="text" id="v-reg" value="${isEdit ? esc(vehicle.registration_no) : ''}" placeholder="e.g. SBA-2024" />
                    <div class="grid-2">
                        <div><label>Make</label><input type="text" id="v-make" value="${isEdit ? esc(vehicle.make || '') : ''}" placeholder="e.g. Honda" /></div>
                        <div><label>Model</label><input type="text" id="v-model" value="${isEdit ? esc(vehicle.model || '') : ''}" placeholder="e.g. Civic" /></div>
                    </div>
                    <div class="grid-2">
                        <div><label>Year</label><input type="text" id="v-year" value="${isEdit ? esc(vehicle.year || '') : ''}" /></div>
                        <div><label>Color</label><input type="text" id="v-color" value="${isEdit ? esc(vehicle.color || '') : ''}" /></div>
                    </div>
                    <label>Owner (Customer)</label>
                    <select id="v-customer"><option value="">-- walk-in / none --</option>${this.customers.map(c => `<option value="${c.id}" ${isEdit && vehicle.customer_id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
                    <label>Notes</label><input type="text" id="v-notes" value="${isEdit ? esc(vehicle.notes || '') : ''}" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="v-cancel">Cancel</button>
                        <button class="btn btn-primary" id="v-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#v-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#v-save').addEventListener('click', async () => {
            const payload = {
                registration_no: overlay.querySelector('#v-reg').value.trim(),
                make: overlay.querySelector('#v-make').value.trim(),
                model: overlay.querySelector('#v-model').value.trim(),
                year: overlay.querySelector('#v-year').value.trim(),
                color: overlay.querySelector('#v-color').value.trim(),
                customer_id: overlay.querySelector('#v-customer').value ? Number(overlay.querySelector('#v-customer').value) : null,
                notes: overlay.querySelector('#v-notes').value.trim(),
            };
            try {
                if (isEdit) {
                    await call(window.api.vehicle.update(vehicle.id, payload));
                    showToast('Vehicle updated', 'success');
                    overlay.remove();
                    this.loadVehiclesTable();
                } else {
                    const newId = await call(window.api.vehicle.create({ business_id: AppState.business.id, ...payload }));
                    showToast('Vehicle added', 'success');
                    overlay.remove();
                    if (onCreated) onCreated(newId); else this.loadVehiclesTable();
                }
            } catch (e) { /* toast shown */ }
        });
    },

    // ==================== VEHICLE STOCK TAB (bikes/cars/scooters) ====================
    async renderStockTab() {
        const box = document.getElementById('auto-tab-content');
        box.innerHTML = `
            <div class="toolbar">
                <input type="text" id="stk-search" placeholder="Search model, make, chassis, motor no..." />
                <select id="stk-status">
                    <option value="in_stock">In Stock</option>
                    <option value="sold">Sold</option>
                    <option value="">All</option>
                </select>
                ${can('automobile.vehicleStock.manage') ? '<button id="stk-new" class="btn btn-primary btn-sm">+ Add Vehicle</button>' : ''}
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Model</th><th>Color</th><th>Motor Power</th><th>Chassis No</th><th class="text-right">Sale Price</th><th>Status</th><th></th></tr></thead>
                    <tbody id="stk-table-body"></tbody>
                </table>
            </div>
        `;
        await this.loadStockTable();
        document.getElementById('stk-search').addEventListener('input', () => this.loadStockTable());
        document.getElementById('stk-status').addEventListener('change', () => this.loadStockTable());
        const newBtn = document.getElementById('stk-new');
        if (newBtn) newBtn.addEventListener('click', () => this.openVehicleUnitModal());
    },

    async loadStockTable() {
        const search = document.getElementById('stk-search').value;
        const status = document.getElementById('stk-status').value;
        const units = await call(window.api.vehicleUnit.list(AppState.business.id, { search, status: status || undefined }));
        this.vehicleUnits = units;
        const tbody = document.getElementById('stk-table-body');
        if (!units.length) {
            tbody.innerHTML = `<tr><td colspan="7" class="empty-state">Koi vehicle nahi mili.</td></tr>`;
            return;
        }
        tbody.innerHTML = units.map(u => `
            <tr>
                <td><strong>${esc(u.make || '')} ${esc(u.model)}</strong></td>
                <td>${esc(u.color || '-')}</td>
                <td>${esc(u.motor_power || '-')}</td>
                <td>${esc(u.chassis_no || '-')}</td>
                <td class="text-right">${money(u.sale_price)}</td>
                <td><span class="badge ${u.status === 'sold' ? 'red' : 'green'}">${u.status === 'sold' ? 'Sold' : 'In Stock'}</span></td>
                <td>
                    ${can('automobile.vehicleStock.manage') ? `<button class="btn-link" data-act="edit" data-id="${u.id}">Edit</button>` : ''}
                    ${u.status === 'in_stock' && can('automobile.vehicleSales.sell') ? `<button class="btn-link" data-act="sell" data-id="${u.id}">Sell</button>` : ''}
                </td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                const unit = units.find(x => x.id === Number(btn.dataset.id));
                if (btn.dataset.act === 'edit') this.openVehicleUnitModal(unit);
                else this.openSellModal(unit);
            });
        });
    },

    openVehicleUnitModal(unit) {
        const isEdit = !!unit;
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>${isEdit ? 'Edit Vehicle' : 'Add Vehicle to Stock'}</h3>
                    <label>Type</label>
                    <select id="vu-type">
                        <option value="bike" ${isEdit && unit.vehicle_type === 'bike' ? 'selected' : ''}>Motorcycle</option>
                        <option value="scooter" ${isEdit && unit.vehicle_type === 'scooter' ? 'selected' : ''}>Electric Scooter</option>
                        <option value="car" ${isEdit && unit.vehicle_type === 'car' ? 'selected' : ''}>Car</option>
                        <option value="other" ${isEdit && unit.vehicle_type === 'other' ? 'selected' : ''}>Other</option>
                    </select>
                    <div class="grid-2">
                        <div><label>Make</label><input type="text" id="vu-make" value="${isEdit ? esc(unit.make || '') : ''}" placeholder="e.g. EVEE" /></div>
                        <div><label>Model</label><input type="text" id="vu-model" value="${isEdit ? esc(unit.model) : ''}" placeholder="e.g. Electric Scooter" /></div>
                    </div>
                    <div class="grid-2">
                        <div><label>Color</label><input type="text" id="vu-color" value="${isEdit ? esc(unit.color || '') : ''}" /></div>
                        <div><label>Motor Power</label><input type="text" id="vu-power" value="${isEdit ? esc(unit.motor_power || '') : ''}" placeholder="e.g. 1500W or 70cc" /></div>
                    </div>
                    <div class="grid-2">
                        <div><label>Motor No</label><input type="text" id="vu-motorno" value="${isEdit ? esc(unit.motor_no || '') : ''}" /></div>
                        <div><label>Chassis No</label><input type="text" id="vu-chassis" value="${isEdit ? esc(unit.chassis_no || '') : ''}" /></div>
                    </div>
                    <div class="grid-2">
                        <div><label>Cost Price</label><input type="number" id="vu-cost" value="${isEdit ? unit.cost_price : 0}" /></div>
                        <div><label>Sale Price</label><input type="number" id="vu-sale" value="${isEdit ? unit.sale_price : 0}" /></div>
                    </div>
                    <label>Notes</label><input type="text" id="vu-notes" value="${isEdit ? esc(unit.notes || '') : ''}" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="vu-cancel">Cancel</button>
                        <button class="btn btn-primary" id="vu-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#vu-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#vu-save').addEventListener('click', async () => {
            const payload = {
                vehicle_type: overlay.querySelector('#vu-type').value,
                make: overlay.querySelector('#vu-make').value.trim(),
                model: overlay.querySelector('#vu-model').value.trim(),
                color: overlay.querySelector('#vu-color').value.trim(),
                motor_power: overlay.querySelector('#vu-power').value.trim(),
                motor_no: overlay.querySelector('#vu-motorno').value.trim(),
                chassis_no: overlay.querySelector('#vu-chassis').value.trim(),
                cost_price: Number(overlay.querySelector('#vu-cost').value || 0),
                sale_price: Number(overlay.querySelector('#vu-sale').value || 0),
                notes: overlay.querySelector('#vu-notes').value.trim(),
            };
            if (!payload.model) { showToast('Model zaroori hai', 'error'); return; }
            try {
                if (isEdit) await call(window.api.vehicleUnit.update(unit.id, payload));
                else await call(window.api.vehicleUnit.create({ business_id: AppState.business.id, branch_id: AppState.branch.id, ...payload }));
                showToast('Vehicle saved', 'success');
                overlay.remove();
                this.loadStockTable();
            } catch (e) { /* toast shown */ }
        });
    },

    async openSellModal(unit) {
        this.customers = await call(window.api.customer.list(AppState.business.id));
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box" style="max-width:520px;">
                    <h3>Sell: ${esc(unit.make || '')} ${esc(unit.model)}</h3>
                    <p class="hint">${esc(unit.color || '')} ${unit.chassis_no ? '— Chassis: ' + esc(unit.chassis_no) : ''}</p>
                    <label>Customer</label>
                    <select id="sl-existing">
                        <option value="">-- Naya customer (neeche details likhein) --</option>
                        ${this.customers.map(c => `<option value="${c.id}">${esc(c.name)}${c.cnic_no ? ' — ' + esc(c.cnic_no) : c.phone ? ' — ' + esc(c.phone) : ''}</option>`).join('')}
                    </select>
                    <label>Full Name</label><input type="text" id="sl-name" />
                    <label>S/O D/O W/O</label><input type="text" id="sl-guardian" placeholder="e.g. S/O Muhammad Ali" />
                    <div class="grid-2">
                        <div><label>CNIC No</label><input type="text" id="sl-cnic" placeholder="00000-0000000-0" /></div>
                        <div><label>Contact No</label><input type="text" id="sl-contact" /></div>
                    </div>
                    <label>Address</label><input type="text" id="sl-address" />
                    <div class="grid-2">
                        <div><label>Amount</label><input type="number" id="sl-amount" value="${unit.sale_price}" /></div>
                        <div><label>Payment Method</label><select id="sl-method"><option value="cash">Cash</option><option value="online">Online</option></select></div>
                    </div>
                    <label>Amount Paid Now</label><input type="number" id="sl-paid" value="${unit.sale_price}" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="sl-cancel">Cancel</button>
                        <button class="btn btn-primary" id="sl-confirm">Complete Sale</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#sl-cancel').addEventListener('click', () => overlay.remove());

        // Picking an existing customer fills in their invoice details
        overlay.querySelector('#sl-existing').addEventListener('change', (e) => {
            const c = this.customers.find(x => x.id === Number(e.target.value));
            overlay.querySelector('#sl-name').value = c ? c.name : '';
            overlay.querySelector('#sl-guardian').value = c ? (c.guardian_name || '') : '';
            overlay.querySelector('#sl-cnic').value = c ? (c.cnic_no || '') : '';
            overlay.querySelector('#sl-contact').value = c ? (c.phone || '') : '';
            overlay.querySelector('#sl-address').value = c ? (c.address || '') : '';
        });

        overlay.querySelector('#sl-confirm').addEventListener('click', async () => {
            const name = overlay.querySelector('#sl-name').value.trim();
            if (!name) { showToast('Buyer ka naam zaroori hai', 'error'); return; }
            try {
                const saleId = await call(window.api.vehicleSale.create({
                    business_id: AppState.business.id, branch_id: AppState.branch.id, vehicle_unit_id: unit.id,
                    customer_id: Number(overlay.querySelector('#sl-existing').value) || null,
                    customer_name: name,
                    guardian_name: overlay.querySelector('#sl-guardian').value.trim(),
                    cnic_no: overlay.querySelector('#sl-cnic').value.trim(),
                    contact_no: overlay.querySelector('#sl-contact').value.trim(),
                    address: overlay.querySelector('#sl-address').value.trim(),
                    amount: Number(overlay.querySelector('#sl-amount').value || 0),
                    paid_amount: Number(overlay.querySelector('#sl-paid').value || 0),
                    payment_method: overlay.querySelector('#sl-method').value,
                    user_id: AppState.user.id,
                }));
                showToast('Vehicle sold!', 'success');
                overlay.remove();
                this.tab = 'sales';
                await this.render();
                const sale = await call(window.api.vehicleSale.get(saleId));
                chooseInvoiceSizeAndPrint({ business: AppState.business, branch: AppState.branch, sale });
            } catch (e) { /* toast shown */ }
        });
    },

    // ==================== VEHICLE SALES TAB ====================
    async renderSalesTab() {
        const box = document.getElementById('auto-tab-content');
        const month = monthRange();
        box.innerHTML = `
            <div class="toolbar">
                <label style="margin:0;">From</label><input type="date" id="vs-from" value="${month.from.slice(0,10)}" />
                <label style="margin:0;">To</label><input type="date" id="vs-to" value="${month.to.slice(0,10)}" />
                <button id="vs-run" class="btn btn-primary btn-sm">Filter</button>
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Invoice</th><th>Vehicle</th><th>Buyer</th><th class="text-right">Amount</th><th class="text-right">Paid</th><th>Status</th><th>Date</th><th></th></tr></thead>
                    <tbody id="vs-table-body"></tbody>
                </table>
            </div>
        `;
        document.getElementById('vs-run').addEventListener('click', () => this.loadSalesTable());
        await this.loadSalesTable();
    },

    async loadSalesTable() {
        const from = document.getElementById('vs-from').value + ' 00:00:00';
        const to = document.getElementById('vs-to').value + ' 23:59:59';
        const sales = await call(window.api.vehicleSale.list(AppState.business.id, AppState.branch.id, from, to));
        const tbody = document.getElementById('vs-table-body');
        if (!sales.length) {
            tbody.innerHTML = `<tr><td colspan="8" class="empty-state">Is date range mein koi vehicle sale nahi.</td></tr>`;
            return;
        }
        tbody.innerHTML = sales.map(s => `
            <tr>
                <td>${esc(s.invoice_no)}</td>
                <td>${esc(s.make || '')} ${esc(s.model)}</td>
                <td>${esc(s.customer_name || '-')}</td>
                <td class="text-right">${money(s.amount)}</td>
                <td class="text-right">${money(s.paid_amount)}</td>
                <td><span class="badge ${s.status === 'cancelled' ? 'red' : 'green'}">${s.status}</span></td>
                <td>${s.sale_date}</td>
                <td><button class="btn-link" data-id="${s.id}">View</button></td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => this.openSaleDetail(Number(btn.dataset.id)));
        });
    },

    async openSaleDetail(saleId) {
        const sale = await call(window.api.vehicleSale.get(saleId));
        const balance = sale.amount - sale.paid_amount;
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>${esc(sale.invoice_no)} <span class="badge ${sale.status === 'cancelled' ? 'red' : 'green'}">${sale.status}</span></h3>
                    <p class="hint">
                        <strong>${esc(sale.make || '')} ${esc(sale.model)}</strong> — ${esc(sale.color || '')}<br/>
                        ${sale.chassis_no ? 'Chassis: ' + esc(sale.chassis_no) + '<br/>' : ''}
                        Buyer: ${esc(sale.customer_name || '-')} ${sale.contact_no ? '— ' + esc(sale.contact_no) : ''}<br/>
                        ${sale.cnic_no ? 'CNIC: ' + esc(sale.cnic_no) + '<br/>' : ''}
                        Date: ${esc(sale.sale_date)}
                    </p>
                    <div style="text-align:right; margin-top:10px;">
                        <div>Amount: ${money(sale.amount)}</div>
                        <div>Paid: ${money(sale.paid_amount)}</div>
                        <div style="font-weight:700;">Balance: ${money(balance)}</div>
                    </div>
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="sd-close">Close</button>
                        <button class="btn btn-secondary" id="sd-print">Print Invoice</button>
                        ${sale.status !== 'cancelled' && can('automobile.vehicleSales.sell') ? '<button class="btn btn-danger" id="sd-cancel">Cancel Sale</button>' : ''}
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#sd-close').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#sd-print').addEventListener('click', () => {
            chooseInvoiceSizeAndPrint({ business: AppState.business, branch: AppState.branch, sale });
        });
        const cancelBtn = overlay.querySelector('#sd-cancel');
        if (cancelBtn) cancelBtn.addEventListener('click', async () => {
            if (!confirm('Ye sale cancel karein? Vehicle wapis stock mein aa jayegi aur accounts reverse ho jayenge.')) return;
            try {
                await call(window.api.vehicleSale.cancel(saleId));
                showToast('Sale cancelled, vehicle stock mein wapis aa gayi', 'success');
                overlay.remove();
                this.loadSalesTable();
            } catch (e) { /* toast shown */ }
        });
    },

    // ==================== MECHANICS TAB ====================
    async renderMechanicsTab() {
        const box = document.getElementById('auto-tab-content');
        box.innerHTML = `
            <div class="toolbar">
                ${can('automobile.mechanics') ? '<button id="mech-new" class="btn btn-primary btn-sm">+ Add Mechanic</button>' : ''}
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Name</th><th>Phone</th><th>Specialty</th><th>Status</th><th></th></tr></thead>
                    <tbody id="mech-table-body"></tbody>
                </table>
            </div>
        `;
        await this.loadMechanicsTable();
        const newBtn = document.getElementById('mech-new');
        if (newBtn) newBtn.addEventListener('click', () => this.openMechanicModal());
    },

    async loadMechanicsTable() {
        const mechanics = await call(window.api.mechanic.list(AppState.business.id, true));
        const tbody = document.getElementById('mech-table-body');
        if (!mechanics.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="empty-state">Koi mechanic add nahi hua.</td></tr>`;
            return;
        }
        tbody.innerHTML = mechanics.map(m => `
            <tr>
                <td>${esc(m.name)}</td>
                <td>${esc(m.phone || '-')}</td>
                <td>${esc(m.specialty || '-')}</td>
                <td><span class="badge ${m.active ? 'green' : 'red'}">${m.active ? 'Active' : 'Disabled'}</span></td>
                <td>${can('automobile.mechanics') ? `<button class="btn-link" data-id="${m.id}">Edit</button>` : ''}</td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                const m = mechanics.find(x => x.id === Number(btn.dataset.id));
                this.openMechanicModal(m);
            });
        });
    },

    openMechanicModal(mechanic) {
        const isEdit = !!mechanic;
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>${isEdit ? 'Edit Mechanic' : 'New Mechanic'}</h3>
                    <label>Name</label><input type="text" id="m-name" value="${isEdit ? esc(mechanic.name) : ''}" />
                    <label>Phone</label><input type="text" id="m-phone" value="${isEdit ? esc(mechanic.phone || '') : ''}" />
                    <label>Specialty</label><input type="text" id="m-specialty" value="${isEdit ? esc(mechanic.specialty || '') : ''}" placeholder="e.g. Engine, AC, Electrical" />
                    ${isEdit ? `<label style="margin-top:12px;"><input type="checkbox" id="m-active" style="width:auto;" ${mechanic.active ? 'checked' : ''} /> Active</label>` : ''}
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="m-cancel">Cancel</button>
                        <button class="btn btn-primary" id="m-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#m-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#m-save').addEventListener('click', async () => {
            const name = overlay.querySelector('#m-name').value.trim();
            if (!name) { showToast('Naam zaroori hai', 'error'); return; }
            try {
                if (isEdit) {
                    await call(window.api.mechanic.update(mechanic.id, {
                        name, phone: overlay.querySelector('#m-phone').value.trim(),
                        specialty: overlay.querySelector('#m-specialty').value.trim(),
                        active: overlay.querySelector('#m-active').checked,
                    }));
                } else {
                    await call(window.api.mechanic.create({
                        business_id: AppState.business.id, name,
                        phone: overlay.querySelector('#m-phone').value.trim(),
                        specialty: overlay.querySelector('#m-specialty').value.trim(),
                    }));
                }
                showToast('Mechanic saved', 'success');
                overlay.remove();
                this.loadMechanicsTable();
            } catch (e) { /* toast shown */ }
        });
    },
};
