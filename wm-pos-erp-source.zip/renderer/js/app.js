const App = {
    pages: {
        dashboard: DashboardPage,
        pos: PosPage,
        customers: CustomersPage,
        sales: SalesPage,
        inventory: InventoryPage,
        purchasing: PurchasingPage,
        automobile: AutomobilePage,
        accounts: AccountsPage,
        reports: ReportsPage,
        settings: SettingsPage,
    },
    currentPage: 'dashboard',

    async init() {
        await initTheme();
        await this.paintLoginBranding();

        document.getElementById('login-form').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('setup-form').addEventListener('submit', (e) => this.handleSetup(e));
        document.getElementById('logout-btn').addEventListener('click', () => this.logout());

        document.querySelectorAll('.nav-item').forEach(btn => {
            btn.addEventListener('click', () => this.navigate(btn.dataset.page));
        });

        document.getElementById('business-select').addEventListener('change', (e) => this.selectBusiness(Number(e.target.value)));
        document.getElementById('branch-select').addEventListener('change', (e) => this.selectBranch(Number(e.target.value)));
    },

    // The login screen shows the shop's own branding. It runs before any
    // business is selected, so we use the first business on file.
    async paintLoginBranding() {
        try {
            const businesses = await call(window.api.business.list());
            if (!businesses.length) return;   // fresh install: keep WM defaults
            const b = businesses[0];
            paintBrandMark(document.getElementById('login-logo'), b);
            document.getElementById('login-title').textContent = b.name;
            document.getElementById('login-subtitle').textContent = b.tagline || b.address || 'Point of Sale & ERP';
        } catch (err) { /* keep defaults */ }
    },

    paintSidebarBranding() {
        const b = AppState.business;
        paintBrandMark(document.getElementById('sidebar-logo'), b);
        document.getElementById('sidebar-title').textContent = (b && b.name) || 'POS ERP';
    },

    // Hide sidebar entries the user has no permission for, and make sure the
    // landing page is one they can actually open.
    applyPermissionsToNav() {
        const pagePerm = (AppState.permCatalog && AppState.permCatalog.pagePermission) || {};
        let firstVisible = null;

        document.querySelectorAll('.nav-item').forEach(btn => {
            const page = btn.dataset.page;
            let visible = true;

            if (page === 'settings') {
                // Settings is visible if the user can do at least one thing there
                visible = ['settings.shop', 'settings.users', 'settings.backup', 'settings.business'].some(can);
            } else if (page === 'automobile') {
                // Industry-specific module: only for automobile businesses, and only with permission
                const isAutomobile = AppState.business && AppState.business.business_type === 'automobile';
                visible = isAutomobile && can(pagePerm.automobile);
            } else if (pagePerm[page]) {
                visible = can(pagePerm[page]);
            }

            btn.classList.toggle('hidden', !visible);
            if (visible && !firstVisible) firstVisible = page;
        });

        const currentBtn = document.querySelector(`.nav-item[data-page="${this.currentPage}"]`);
        if (!currentBtn || currentBtn.classList.contains('hidden')) {
            this.currentPage = firstVisible || 'dashboard';
        }
        document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === this.currentPage));
        document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
        const pageEl = document.getElementById('page-' + this.currentPage);
        if (pageEl) pageEl.classList.remove('hidden');
    },

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;
        const errorEl = document.getElementById('login-error');
        errorEl.textContent = '';
        try {
            const user = await call(window.api.auth.login(username, password));
            AppState.user = user;
            await this.afterLogin();
        } catch (err) {
            errorEl.textContent = 'Ghalat username ya password.';
        }
    },

    async afterLogin() {
        AppState.permissions = AppState.user.effective_permissions || [];
        AppState.permCatalog = await call(window.api.perms.catalog());
        this.applyPermissionsToNav();

        const businesses = await call(window.api.business.list());
        if (!businesses.length) {
            document.getElementById('login-screen').classList.add('hidden');
            document.getElementById('setup-screen').classList.remove('hidden');
            return;
        }
        AppState.businesses = businesses;
        document.getElementById('login-screen').classList.add('hidden');
        document.getElementById('app-screen').classList.remove('hidden');
        document.getElementById('current-user-name').textContent = `${AppState.user.full_name || AppState.user.username} (${AppState.user.role})`;
        this.populateBusinessSelect();
        await this.selectBusiness(businesses[0].id);
    },

    async handleSetup(e) {
        e.preventDefault();
        const payload = {
            name: document.getElementById('setup-name').value,
            business_type: document.getElementById('setup-type').value,
            address: document.getElementById('setup-address').value,
            phone: document.getElementById('setup-phone').value,
        };
        await call(window.api.business.create(payload));
        showToast('Business created!', 'success');
        document.getElementById('setup-screen').classList.add('hidden');
        document.getElementById('app-screen').classList.remove('hidden');
        document.getElementById('current-user-name').textContent = `${AppState.user.full_name || AppState.user.username} (${AppState.user.role})`;
        const businesses = await call(window.api.business.list());
        AppState.businesses = businesses;
        this.populateBusinessSelect();
        await this.selectBusiness(businesses[0].id);
    },

    populateBusinessSelect() {
        const sel = document.getElementById('business-select');
        sel.innerHTML = AppState.businesses.map(b => `<option value="${b.id}">${b.name}</option>`).join('');
    },

    async loadBusinesses() {
        AppState.businesses = await call(window.api.business.list());
        this.populateBusinessSelect();
    },

    async selectBusiness(businessId) {
        const business = AppState.businesses.find(b => b.id === businessId);
        AppState.business = business;
        document.getElementById('business-select').value = businessId;
        this.paintSidebarBranding();
        this.applyPermissionsToNav();
        await this.loadBranches();
    },

    async loadBranches() {
        if (!AppState.business) return;
        const branches = await call(window.api.branch.list(AppState.business.id));
        AppState.branches = branches;
        const sel = document.getElementById('branch-select');
        sel.innerHTML = branches.map(b => `<option value="${b.id}">${b.name}</option>`).join('');
        if (branches.length) await this.selectBranch(branches[0].id);
        else { AppState.branch = null; this.renderCurrentPage(); }
    },

    async selectBranch(branchId) {
        AppState.branch = AppState.branches.find(b => b.id === branchId);
        document.getElementById('branch-select').value = branchId;
        this.renderCurrentPage();
    },

    navigate(pageName) {
        this.currentPage = pageName;
        document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === pageName));
        document.querySelectorAll('.page').forEach(p => p.classList.add('hidden'));
        document.getElementById('page-' + pageName).classList.remove('hidden');
        this.renderCurrentPage();
    },

    renderCurrentPage() {
        const page = this.pages[this.currentPage];
        if (page) page.render();
    },

    logout() {
        AppState.user = null;
        AppState.business = null;
        AppState.branch = null;
        AppState.permissions = [];
        this.currentPage = 'dashboard';
        document.getElementById('app-screen').classList.add('hidden');
        document.getElementById('login-screen').classList.remove('hidden');
        document.getElementById('login-error').textContent = '';
    },
};

window.addEventListener('DOMContentLoaded', () => App.init());
