const PosPage = {
    cart: [],       // {product_id, name, unit_price, quantity, stock}
    products: [],
    customers: [],

    async render() {
        const container = document.getElementById('page-pos');
        if (!AppState.business || !AppState.branch) {
            container.innerHTML = `<div class="empty-state">Pehle koi business aur branch select karein.</div>`;
            return;
        }
        this.cart = [];
        container.innerHTML = `
            <div class="pos-layout">
                <div class="pos-products">
                    <div class="toolbar">
                        <input type="text" id="pos-search" placeholder="Search product name / barcode..." />
                    </div>
                    <div id="pos-product-grid" class="product-grid"></div>
                </div>
                <div class="cart-panel">
                    <div style="padding:12px; border-bottom:1px solid var(--border);">
                        <div style="display:flex; gap:6px;">
                            <select id="pos-customer" style="flex:1;"></select>
                            ${can('customers.manage') ? '<button class="btn btn-secondary btn-sm" id="pos-new-customer" title="Naya customer" style="white-space:nowrap;">+ New</button>' : ''}
                        </div>
                        <div id="pos-customer-info" class="hint" style="margin:6px 0 0;"></div>
                    </div>
                    <div id="pos-cart-items" class="cart-items"></div>
                    <div class="cart-totals">
                        <div class="row"><span>Subtotal</span><span id="pos-subtotal">Rs 0</span></div>
                        <div class="row" ${can('pos.discount') ? '' : 'style="display:none;"'}>
                            <span>Discount</span>
                            <input type="number" id="pos-discount" value="0" min="0" style="width:100px; padding:3px 6px;" />
                        </div>
                        <div class="row grand"><span>Total</span><span id="pos-total">Rs 0</span></div>
                    </div>
                    <div class="cart-footer">
                        <button id="pos-hold" class="btn btn-secondary">Clear</button>
                        <button id="pos-checkout" class="btn btn-primary btn-block">Checkout</button>
                    </div>
                </div>
            </div>
        `;

        this.products = await call(window.api.product.list(AppState.business.id, {}));
        const stockList = await call(window.api.stock.listForBranch(AppState.branch.id));
        const stockMap = {};
        stockList.forEach(s => stockMap[s.product_id] = s.quantity);
        this.products.forEach(p => p.stock = stockMap[p.id] || 0);

        await this.loadCustomers();
        const newCustBtn = document.getElementById('pos-new-customer');
        if (newCustBtn) newCustBtn.addEventListener('click', () => {
            openCustomerModal(null, async (id) => { await this.loadCustomers(id); });
        });
        document.getElementById('pos-customer').addEventListener('change', () => this.showCustomerInfo());

        this.renderProductGrid(this.products);

        document.getElementById('pos-search').addEventListener('input', (e) => {
            const q = e.target.value.toLowerCase();
            const filtered = this.products.filter(p => p.name.toLowerCase().includes(q) || (p.barcode || '').includes(q));
            this.renderProductGrid(filtered);
        });
        document.getElementById('pos-discount').addEventListener('input', () => this.renderCart());
        document.getElementById('pos-hold').addEventListener('click', () => { this.cart = []; this.renderCart(); });
        document.getElementById('pos-checkout').addEventListener('click', () => this.openCheckout());
    },

    // Fill the customer dropdown; "Walk-in" (no customer) is the default.
    async loadCustomers(selectId) {
        this.customers = await call(window.api.customer.list(AppState.business.id));
        const sel = document.getElementById('pos-customer');
        sel.innerHTML = `<option value="">Walk-in Customer</option>` +
            this.customers.map(c => `<option value="${c.id}">${esc(c.name)}${c.phone ? ' — ' + esc(c.phone) : ''}</option>`).join('');
        if (selectId) sel.value = String(selectId);
        this.showCustomerInfo();
    },

    showCustomerInfo() {
        const box = document.getElementById('pos-customer-info');
        const id = Number(document.getElementById('pos-customer').value);
        const c = this.customers.find(x => x.id === id);
        if (!box) return;
        box.innerHTML = c && c.balance > 0
            ? `Pehle se baqi: <strong style="color:var(--red);">${money(c.balance)}</strong>`
            : '';
    },

    renderProductGrid(list) {
        const grid = document.getElementById('pos-product-grid');
        if (!list.length) { grid.innerHTML = `<div class="empty-state">Koi product nahi mila.</div>`; return; }
        grid.innerHTML = list.map(p => `
            <div class="product-tile" data-id="${p.id}">
                <div class="name">${p.name}</div>
                <div class="price">${money(p.sale_price)}</div>
                <div class="${p.stock <= p.reorder_level ? 'stock-low' : ''}">Stock: ${p.stock}</div>
            </div>
        `).join('');
        grid.querySelectorAll('.product-tile').forEach(tile => {
            tile.addEventListener('click', () => this.addToCart(Number(tile.dataset.id)));
        });
    },

    addToCart(productId) {
        const p = this.products.find(x => x.id === productId);
        if (!p) return;
        // Each bike/car is its own line (quantity 1) because every unit has its
        // own chassis and motor number, entered at checkout.
        const isVehicle = AppState.business.business_type === 'automobile' && p.is_vehicle;
        const existing = !isVehicle && this.cart.find(c => c.product_id === productId);
        if (existing) existing.quantity += 1;
        else this.cart.push({
            product_id: p.id, name: p.name, unit_price: p.sale_price, quantity: 1, stock: p.stock,
            is_vehicle: !!isVehicle, color: p.color || '', model: p.model || '',
            chassis_no: '', motor_no: '', motor_power: '',
        });
        this.renderCart();
    },

    renderCart() {
        const itemsEl = document.getElementById('pos-cart-items');
        if (!this.cart.length) {
            itemsEl.innerHTML = `<div class="empty-state">Cart khali hai. Product par click karein.</div>`;
        } else {
            itemsEl.innerHTML = this.cart.map((c, i) => `
                <div class="cart-line">
                    <div>
                        <div>${esc(c.name)}${c.is_vehicle ? ' <span class="badge amber">Bike</span>' : ''}</div>
                        <div style="color:var(--text-muted); font-size:11px;">${c.is_vehicle ? [c.color, c.model].filter(Boolean).map(esc).join(' • ') + (c.color || c.model ? ' — ' : '') + money(c.unit_price) : money(c.unit_price) + ' x ' + c.quantity}</div>
                    </div>
                    <div class="qty-controls" style="display:flex; align-items:center; gap:6px;">
                        ${c.is_vehicle ? '' : `<button data-i="${i}" data-act="dec">-</button>
                        <span>${c.quantity}</span>
                        <button data-i="${i}" data-act="inc">+</button>`}
                        <button data-i="${i}" data-act="rm" style="color:var(--red);">✕</button>
                    </div>
                </div>
            `).join('');
            itemsEl.querySelectorAll('button').forEach(btn => {
                btn.addEventListener('click', () => {
                    const i = Number(btn.dataset.i);
                    if (btn.dataset.act === 'inc') this.cart[i].quantity += 1;
                    else if (btn.dataset.act === 'dec') this.cart[i].quantity = Math.max(1, this.cart[i].quantity - 1);
                    else if (btn.dataset.act === 'rm') this.cart.splice(i, 1);
                    this.renderCart();
                });
            });
        }
        const subtotal = this.cart.reduce((s, c) => s + c.quantity * c.unit_price, 0);
        const discount = Number(document.getElementById('pos-discount').value || 0);
        document.getElementById('pos-subtotal').textContent = money(subtotal);
        document.getElementById('pos-total').textContent = money(Math.max(0, subtotal - discount));
    },

    openCheckout() {
        if (!this.cart.length) { showToast('Cart khali hai', 'error'); return; }
        const subtotal = this.cart.reduce((s, c) => s + c.quantity * c.unit_price, 0);
        const discount = Number(document.getElementById('pos-discount').value || 0);
        const total = Math.max(0, subtotal - discount);

        const vehicleLines = this.cart.map((c, i) => ({ c, i })).filter(x => x.c.is_vehicle);
        const vehicleSection = vehicleLines.length ? `
                    <div style="border:1px solid var(--table-border); border-radius:8px; padding:10px 12px; margin-bottom:12px;">
                        <div style="font-weight:700; margin-bottom:4px;">Vehicle Details</div>
                        ${vehicleLines.map(({ c, i }, n) => `
                            <div style="${n ? 'border-top:1px dashed var(--table-border); margin-top:10px; padding-top:8px;' : ''}">
                                <div style="font-size:13px; font-weight:600;">${esc(c.name)}${c.color ? ' — ' + esc(c.color) : ''}${c.model ? ' — ' + esc(c.model) : ''}</div>
                                <div class="grid-3" style="gap:8px;">
                                    <div><label>Chassis No</label><input type="text" class="veh-field" data-i="${i}" data-f="chassis_no" value="${esc(c.chassis_no)}" /></div>
                                    <div><label>Motor No</label><input type="text" class="veh-field" data-i="${i}" data-f="motor_no" value="${esc(c.motor_no)}" /></div>
                                    <div><label>Motor Power</label><input type="text" class="veh-field" data-i="${i}" data-f="motor_power" value="${esc(c.motor_power)}" placeholder="e.g. 1500W" /></div>
                                </div>
                            </div>`).join('')}
                    </div>` : '';

        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box" style="max-width:${vehicleLines.length ? 620 : 460}px;">
                    <h3>Checkout</h3>
                    ${vehicleSection}
                    <div class="row" style="display:flex; justify-content:space-between; font-size:20px; font-weight:700; margin-bottom:14px;">
                        <span>Total</span><span>${money(total)}</span>
                    </div>
                    <label>Payment Method</label>
                    <select id="checkout-method">
                        <option value="cash">Cash</option>
                        <option value="card">Card</option>
                        <option value="bank">Bank Transfer</option>
                        <option value="easypaisa">Easypaisa</option>
                        <option value="jazzcash">JazzCash</option>
                        ${can('pos.credit') ? '<option value="credit">Credit (Udhaar)</option>' : ''}
                    </select>
                    <label>Amount Paid</label>
                    <input type="number" id="checkout-paid" value="${total}" min="0" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="checkout-cancel">Cancel</button>
                        <button class="btn btn-primary" id="checkout-confirm">Complete Sale</button>
                    </div>
                </div>
            </div>
        `);
        document.body.appendChild(overlay);

        overlay.querySelector('#checkout-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#checkout-confirm').addEventListener('click', async () => {
            const paid = Number(overlay.querySelector('#checkout-paid').value || 0);
            const method = overlay.querySelector('#checkout-method').value;
            const customer_id = Number(document.getElementById('pos-customer').value) || null;
            // Anything left unpaid must be owed by a named customer, otherwise
            // there is no khata to record it against.
            if (!customer_id && (method === 'credit' || paid < total)) {
                showToast('Udhaar / baqi raqam ke liye customer select karein', 'error');
                return;
            }
            // The vehicle invoice prints the buyer's name, CNIC etc., so a bike
            // can't be sold to "Walk-in Customer".
            if (vehicleLines.length && !customer_id) {
                showToast('Bike/car ki invoice ke liye customer select karein (ya + New se banayein)', 'error');
                return;
            }
            overlay.querySelectorAll('.veh-field').forEach(inp => {
                this.cart[Number(inp.dataset.i)][inp.dataset.f] = inp.value.trim();
            });
            try {
                const result = await call(window.api.sale.create({
                    business_id: AppState.business.id,
                    branch_id: AppState.branch.id,
                    customer_id,
                    items: this.cart.map(c => ({
                        product_id: c.product_id, quantity: c.quantity, unit_price: c.unit_price,
                        chassis_no: c.chassis_no || null, motor_no: c.motor_no || null, motor_power: c.motor_power || null,
                    })),
                    discount,
                    paid_amount: paid,
                    payment_method: method,
                    user_id: AppState.user.id,
                }));
                showToast(`Sale complete! Invoice ${result.invoice_no}`, 'success');
                overlay.remove();
                const items = await call(window.api.sale.items(result.saleId));
                const saleInfo = { invoice_no: result.invoice_no, subtotal, discount, total: result.total, paid_amount: paid, payment_method: method, sale_date: localDateISO() };
                const customer = this.customers.find(x => x.id === customer_id);
                printReceipt({ business: AppState.business, branch: AppState.branch, sale: saleInfo, items, customer });
                this.render();
            } catch (e) { /* toast already shown */ }
        });
    },
};
