// renderer/js/vehicle-invoice.js
// Every sale invoice (POS, bike/car sale, service job) is printed from here in
// the shop's receipt-book style: dealer logo top-left, brand logo top-right,
// SALES INVOICE, customer information on ruled lines, QTY / DESCRIPTION /
// AMOUNT table, payment boxes, signatures and an address footer.
// A4 and A5 share one layout (A5 is scaled down); 80mm thermal is condensed.
// Printing always goes through the Print Preview window (main.js).

const VEHICLE_TYPE_LABELS = { bike: 'Motorcycle', car: 'Car', scooter: 'Electric Scooter', other: 'Vehicle' };
const ONLINE_METHODS = ['online', 'bank', 'card', 'easypaisa', 'jazzcash'];

function vehicleSpecLines(sale) {
    return [
        ['Model', sale.model], ['Color', sale.color], ['Motor Power', sale.motor_power],
        ['Motor No', sale.motor_no], ['Chassis No', sale.chassis_no],
    ].filter(([, v]) => v);
}

// Invoice data is normalised to { invoice_no, sale_date, customer fields,
// amount, discount, paid_amount, payment_method, lines: [{ qty, title, specs, amount }] }
function vehicleSaleToInvoice(sale) {
    return {
        ...sale,
        discount: 0,
        lines: [{
            qty: 1,
            title: [sale.make, sale.model].filter(Boolean).join(' ') || VEHICLE_TYPE_LABELS[sale.vehicle_type] || 'Vehicle',
            specs: vehicleSpecLines(sale),
            amount: Number(sale.amount),
        }],
    };
}

function posSaleToInvoice(sale, items, customer) {
    const lines = items.map(it => {
        const specs = it.is_vehicle ? [
            ['Model', it.model], ['Color', it.color], ['Motor Power', it.motor_power],
            ['Motor No', it.motor_no], ['Chassis No', it.chassis_no],
        ] : [];
        return { qty: it.quantity, title: it.product_name, specs, amount: Number(it.total) };
    });
    const c = customer || {};
    return {
        invoice_no: sale.invoice_no,
        sale_date: String(sale.sale_date || new Date().toLocaleDateString()).slice(0, 10),
        customer_name: c.name || sale.customer_name || '',
        guardian_name: c.guardian_name || '',
        cnic_no: c.cnic_no || '',
        contact_no: c.phone || '',
        address: c.address || '',
        amount: Number(sale.total),
        discount: Number(sale.discount || 0),
        paid_amount: Number(sale.paid_amount),
        payment_method: sale.payment_method || 'cash',
        lines,
    };
}

const fmt = (n) => Number(n || 0).toLocaleString('en-PK');

// ==================== A4 / A5: receipt-book layout ====================
function buildFormalInvoice(business, branch, sale, size) {
    const k = size === 'a5' ? 0.72 : 1;               // A5 is the same design, scaled
    const px = (n) => `${(n * k).toFixed(1)}px`;
    const balance = Number(sale.amount) - Number(sale.paid_amount);
    const isCash = sale.payment_method === 'cash';
    const isOnline = ONLINE_METHODS.includes(sale.payment_method);

    const dealer = business.logo_data
        ? `<img class="dealer-logo" src="${business.logo_data}" alt="" />`
        : `<div class="dealer-name">${esc(business.name)}</div>`;
    const brand = (business.brand_logo_data || business.brand_title) ? `
        <div class="brand">
            ${business.brand_logo_data ? `<img class="brand-logo" src="${business.brand_logo_data}" alt="" />` : ''}
            ${business.brand_title ? `<div class="brand-title">${esc(business.brand_title)}</div>` : ''}
        </div>` : '<div></div>';

    const field = (label, value) => `
        <div class="field"><span class="flabel">${label}</span><span class="fline">${esc(value || '')}</span></div>`;

    const rows = sale.lines.map(line => `
        <tr>
            <td class="qty">${esc(line.qty)}</td>
            <td class="desc">
                ${line.title ? `<div class="item-title">${esc(line.title)}</div>` : ''}
                ${line.specs.map(([kk, v]) => `
                    <div class="spec"><span class="slabel">${esc(kk)}</span><span class="sline">${esc(v || '')}</span></div>`).join('')}
            </td>
            <td class="amt">${fmt(line.amount)}</td>
        </tr>`).join('');
    const totals = (sale.lines.length > 1 || sale.discount) ? `
        ${sale.discount ? `<tr class="sub"><td></td><td class="tlabel">Discount</td><td class="amt">- ${fmt(sale.discount)}</td></tr>` : ''}
        <tr class="sub"><td></td><td class="tlabel">Total</td><td class="amt"><b>${fmt(sale.amount)}</b></td></tr>` : '';

    const footer2 = [business.name, business.tagline].filter(Boolean).map(esc).join(' ');
    const note = business.receipt_footer ||
        'Sold goods cannot be refunded or exchanged. This is not a Warranty Card.';

    return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(sale.invoice_no)}</title>
    <style>
        @page { size: ${size === 'a5' ? 'A5' : 'A4'}; margin: 0; }
        * { box-sizing: border-box; }
        body { margin: 0; color: #1d1d1d; font-family: 'Segoe UI', Arial, sans-serif; font-size: ${px(14)}; }
        .serif { font-family: Georgia, 'Times New Roman', serif; }
        .top { display: flex; justify-content: space-between; align-items: flex-start; min-height: ${px(110)}; }
        .dealer-logo { max-height: ${px(120)}; max-width: ${px(230)}; object-fit: contain; }
        .dealer-name { font-family: Georgia, serif; font-size: ${px(30)}; font-weight: 700; letter-spacing: 1px; }
        .brand { text-align: center; }
        .brand-logo { max-height: ${px(95)}; max-width: ${px(170)}; object-fit: contain; display: block; margin: 0 auto ${px(4)}; }
        .brand-title { font-family: Georgia, serif; font-weight: 700; font-size: ${px(24)}; }
        .meta { width: 38%; margin-top: ${px(10)}; }
        .field { display: flex; align-items: flex-end; gap: ${px(8)}; margin: ${px(9)} 0; }
        .flabel { white-space: nowrap; letter-spacing: .3px; }
        .fline { flex: 1; border-bottom: 1px solid #333; min-height: ${px(19)}; padding: 0 ${px(4)} ${px(1)}; font-weight: 600; }
        .title-row { position: relative; margin: ${px(14)} 0 ${px(4)}; min-height: ${px(24)}; }
        .ci { font-family: Georgia, serif; font-size: ${px(16)}; position: absolute; left: 0; bottom: 0; }
        .si { text-align: center; font-weight: 800; font-size: ${px(22)}; letter-spacing: .5px; }
        .cust .flabel { text-transform: uppercase; }
        table.items { width: 100%; border-collapse: collapse; margin-top: ${px(10)};
                      border-top: ${px(4)} solid #222; border-bottom: ${px(4)} solid #222; }
        table.items th { font-family: Georgia, serif; font-size: ${px(17)}; padding: ${px(8)}; border-bottom: 2px solid #222; }
        table.items th + th, table.items td + td { border-left: 2px solid #222; }
        table.items td { padding: ${px(8)} ${px(12)}; vertical-align: top; }
        table.items tr + tr td { border-top: 1px solid #999; }
        .qty { width: 18%; text-align: center; }
        .amt { width: 22%; text-align: right; white-space: nowrap; }
        .item-title { font-weight: 700; margin-bottom: ${px(4)}; }
        .spec { display: flex; align-items: flex-end; gap: ${px(10)}; margin: ${px(6)} 0; }
        .slabel { width: 42%; text-transform: uppercase; letter-spacing: .3px; }
        .sline { flex: 1; border-bottom: 1px solid #333; min-height: ${px(18)}; font-weight: 600; padding: 0 ${px(4)}; }
        tr.sub td { border-top: 1px solid #999; }
        .tlabel { text-align: right; font-weight: 600; }
        .bottom { display: flex; margin-top: ${px(18)}; align-items: stretch; }
        .info { width: 44%; text-align: center; padding-right: ${px(16)}; border-right: 2px solid #222; }
        .info h4 { font-family: Georgia, serif; font-size: ${px(17)}; margin: 0 0 ${px(4)}; }
        .info p { margin: 0; line-height: 1.35; }
        .pay { flex: 1; padding-left: ${px(20)}; }
        .mode { display: flex; align-items: center; justify-content: space-between; margin-bottom: ${px(6)}; }
        .boxes { display: flex; gap: ${px(22)}; }
        .box { text-align: center; font-size: ${px(10)}; }
        .box .sq { width: ${px(26)}; height: ${px(26)}; border: 1.5px solid #222; margin: 0 auto ${px(2)};
                   display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: ${px(18)}; }
        .sigs { display: flex; justify-content: space-between; margin-top: ${px(56)}; }
        .sigs div { width: 30%; text-align: center; border-top: 2px solid #222; padding-top: ${px(5)}; }
        .foot { margin-top: ${px(18)}; border-top: 2px solid #222; padding-top: ${px(6)}; text-align: center; line-height: 1.45; }
    </style></head><body>
        <div class="top">
            <div>${dealer}</div>
            ${brand}
        </div>
        <div class="meta">
            ${field('Invoice No', sale.invoice_no)}
            ${field('Date', sale.sale_date || new Date().toLocaleDateString())}
        </div>
        <div class="title-row"><div class="ci">Customer Information</div><div class="si">SALES INVOICE</div></div>
        <div class="cust">
            ${field('Full Name', sale.customer_name)}
            ${field('S/O D/O W/O', sale.guardian_name)}
            ${field('CNIC No.', sale.cnic_no)}
            ${field('Contact No', sale.contact_no)}
            ${field('Address', sale.address)}
        </div>
        <table class="items">
            <thead><tr><th>QTY</th><th>DESCRIPTION</th><th>AMOUNT</th></tr></thead>
            <tbody>${rows}${totals}</tbody>
        </table>
        <div class="bottom">
            <div class="info"><h4>Important Information</h4><p>${esc(note)}</p></div>
            <div class="pay">
                <div class="mode">
                    <span>Mode of Payment</span>
                    <div class="boxes">
                        <div class="box"><div class="sq">${isCash ? '✓' : ''}</div>Cash</div>
                        <div class="box"><div class="sq">${isOnline ? '✓' : ''}</div>Online</div>
                    </div>
                </div>
                ${field('Amount Paid', fmt(sale.paid_amount))}
                ${field('Balance', fmt(balance))}
            </div>
        </div>
        <div class="sigs"><div>Authorized Signature</div><div>Buyer Signature</div></div>
        <div class="foot">
            ${business.address ? `<div>${esc(business.address)}</div>` : ''}
            <div>${footer2}${business.phone ? ` . Phone: ${esc(business.phone)}` : ''}</div>
        </div>
    </body></html>`;
}

// ==================== 80mm thermal (condensed) ====================
function buildThermalInvoice(business, branch, sale) {
    const balance = Number(sale.amount) - Number(sale.paid_amount);
    return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(sale.invoice_no)}</title>
    <style>
        body { font-family: 'Courier New', monospace; font-size: 12px; width: 74mm; margin: 0; color: #000; }
        h2 { text-align: center; margin: 2px 0; font-size: 15px; }
        .c { text-align: center; }
        hr { border: none; border-top: 1px dashed #000; margin: 5px 0; }
        .row { display: flex; justify-content: space-between; gap: 6px; }
        .b { font-weight: bold; }
        img { display: block; margin: 0 auto 3px; max-height: 55px; max-width: 60mm; object-fit: contain; }
    </style></head><body>
        ${business.logo_data ? `<img src="${business.logo_data}" />` : ''}
        <h2>${esc(business.name)}</h2>
        ${business.brand_title ? `<div class="c">${esc(business.brand_title)}</div>` : ''}
        ${business.address ? `<div class="c">${esc(business.address)}</div>` : ''}
        ${business.phone ? `<div class="c">${esc(business.phone)}</div>` : ''}
        <hr/>
        <div class="c b">SALES INVOICE</div>
        <div class="row"><span>Invoice:</span><span>${esc(sale.invoice_no)}</span></div>
        <div class="row"><span>Date:</span><span>${esc(sale.sale_date || '')}</span></div>
        ${sale.customer_name ? `<hr/><div class="b">Customer</div>
        <div>${esc(sale.customer_name)}</div>
        ${sale.guardian_name ? `<div>${esc(sale.guardian_name)}</div>` : ''}
        ${sale.cnic_no ? `<div>CNIC: ${esc(sale.cnic_no)}</div>` : ''}
        ${sale.contact_no ? `<div>Contact: ${esc(sale.contact_no)}</div>` : ''}` : ''}
        <hr/>
        ${sale.lines.map(line => `
            <div class="row b"><span>${esc(line.qty)} x ${esc(line.title)}</span><span>${fmt(line.amount)}</span></div>
            ${line.specs.filter(([, v]) => v).map(([kk, v]) => `<div class="row"><span>${esc(kk)}</span><span>${esc(v)}</span></div>`).join('')}
        `).join('<div style="height:4px;"></div>')}
        ${sale.discount ? `<div class="row"><span>Discount</span><span>- ${fmt(sale.discount)}</span></div>` : ''}
        <hr/>
        <div class="row b"><span>Total</span><span>${fmt(sale.amount)}</span></div>
        <div class="row"><span>Paid (${esc(sale.payment_method)})</span><span>${fmt(sale.paid_amount)}</span></div>
        <div class="row"><span>Balance</span><span>${fmt(balance)}</span></div>
        <hr/>
        <div class="c" style="font-size:10px;">${esc(business.receipt_footer || 'Sold goods cannot be refunded. Not a warranty card.')}</div>
        <div style="margin-top:22px;">Authorized: ______________</div>
        <div style="margin-top:16px;">Buyer: ______________</div>
        <div class="c" style="font-size:9px; margin-top:10px;">Powered by WM Tech</div>
    </body></html>`;
}

function buildInvoicePages(business, branch, inv) {
    return {
        a4: buildFormalInvoice(business, branch, inv, 'a4'),
        a5: buildFormalInvoice(business, branch, inv, 'a5'),
        thermal: buildThermalInvoice(business, branch, inv),
    };
}

function openInvoicePreview(business, branch, inv, size) {
    return call(window.api.print.preview({ pages: buildInvoicePages(business, branch, inv), size, title: inv.invoice_no }));
}

// Entry point for every invoice print. Uses the business's default paper size
// from Settings; if that is "ask", lets the person choose first. The preview
// window can still switch size afterwards.
function chooseInvoiceSizeAndPrint({ business, branch, sale }) {
    const inv = sale.lines ? sale : vehicleSaleToInvoice(sale);
    const preferred = business.invoice_size || 'ask';
    if (preferred !== 'ask') return openInvoicePreview(business, branch, inv, preferred);

    const overlay = el(`
        <div class="modal-overlay">
            <div class="modal-box">
                <h3>Print Invoice</h3>
                <p class="hint">Kis size par print karna hai? (Settings mein default size set kar sakte hain.)</p>
                <div style="display:flex; flex-direction:column; gap:8px;">
                    <button class="btn btn-secondary" data-size="a4" style="text-align:left;">A4 — Full page</button>
                    <button class="btn btn-secondary" data-size="a5" style="text-align:left;">A5 — Half page</button>
                    <button class="btn btn-secondary" data-size="thermal" style="text-align:left;">80mm Thermal Roll</button>
                </div>
                <div class="modal-actions"><button class="btn btn-secondary" id="pv-cancel">Cancel</button></div>
            </div>
        </div>`);
    document.body.appendChild(overlay);
    overlay.querySelector('#pv-cancel').addEventListener('click', () => overlay.remove());
    overlay.querySelectorAll('[data-size]').forEach(btn => {
        btn.addEventListener('click', () => {
            overlay.remove();
            openInvoicePreview(business, branch, inv, btn.dataset.size);
        });
    });
}
