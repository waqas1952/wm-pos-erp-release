const SettingsPage = {
    async render() {
        const container = document.getElementById('page-settings');
        container.innerHTML = `
            <div class="page-header"><h2>Settings</h2></div>
            <div class="card ${can('settings.shop') ? '' : 'hidden'}">
                <h3 style="margin-top:0;">Shop / Company Profile</h3>
                <p class="hint">Ye naam, logo aur details login screen, dashboard aur har bill/receipt par nazar aayenge.</p>
                <div id="shop-profile"></div>
            </div>
            <div class="card ${can('settings.shop') ? '' : 'hidden'}">
                <h3 style="margin-top:0;">Theme</h3>
                <p class="hint">Apni pasand ka color theme choose karein — turant apply ho jata hai.</p>
                <div class="theme-grid" id="theme-grid"></div>
            </div>
            <div class="grid-2 ${can('settings.business') ? '' : 'hidden'}">
                <div class="card">
                    <h3 style="margin-top:0;">Businesses</h3>
                    <table><thead><tr><th>Name</th><th>Type</th></tr></thead><tbody id="set-businesses"></tbody></table>
                    <button id="set-add-business" class="btn btn-secondary btn-sm" style="margin-top:10px;">+ Add Business</button>
                </div>
                <div class="card">
                    <h3 style="margin-top:0;">Branches (${AppState.business ? AppState.business.name : '-'})</h3>
                    <table><thead><tr><th>Name</th><th>Main?</th></tr></thead><tbody id="set-branches"></tbody></table>
                    <button id="set-add-branch" class="btn btn-secondary btn-sm" style="margin-top:10px;">+ Add Branch</button>
                </div>
            </div>
            <div class="card ${can('settings.users') ? '' : 'hidden'}">
                <h3 style="margin-top:0;">Users &amp; Permissions</h3>
                <p class="hint">Har user ko alag se tay karein ke wo kya kar sakta hai. Role choose karne par default permissions lag jati hain, jinhe aap badal sakte hain.</p>
                <table><thead><tr><th>Username</th><th>Full Name</th><th>Role</th><th>Status</th><th></th></tr></thead><tbody id="set-users"></tbody></table>
                <button id="set-add-user" class="btn btn-primary btn-sm" style="margin-top:10px;">+ Add User</button>
            </div>
            <div class="card ${can('settings.backup') ? '' : 'hidden'}">
                <h3 style="margin-top:0;">Automatic Backup</h3>
                <p class="hint">Data khud ba khud backup hota rahega. Backup folder koi bhi ho sakta hai — D: drive, USB, ya Google Drive/OneDrive ka sync folder (phir wo khud cloud par chala jayega, internet ke baghair bhi app kaam karti rahegi).</p>
                <div id="backup-settings"></div>
            </div>
            <div class="card ${can('settings.backup') ? '' : 'hidden'}">
                <h3 style="margin-top:0;">Available Backups</h3>
                <table><thead><tr><th>File</th><th>Date</th><th class="text-right">Size</th><th></th></tr></thead><tbody id="backup-list"></tbody></table>
            </div>
            <div class="card">
                <h3 style="margin-top:0;">Software Update</h3>
                <div id="update-panel"></div>
            </div>
        `;

        document.getElementById('set-businesses').innerHTML = AppState.businesses.map(b => `<tr><td>${esc(b.name)}</td><td>${esc(b.business_type)}</td></tr>`).join('');
        document.getElementById('set-branches').innerHTML = AppState.business ? AppState.branches.map(b => `<tr><td>${esc(b.name)}</td><td>${b.is_main ? 'Yes' : ''}</td></tr>`).join('') : '';

        if (can('settings.users')) await this.renderUsers();

        const addBiz = document.getElementById('set-add-business');
        if (addBiz) addBiz.addEventListener('click', () => this.openBusinessModal());
        const addBr = document.getElementById('set-add-branch');
        if (addBr) addBr.addEventListener('click', () => this.openBranchModal());
        const addUser = document.getElementById('set-add-user');
        if (addUser) addUser.addEventListener('click', () => this.openUserModal());

        if (can('settings.shop')) {
            this.renderShopProfile();
            await this.renderThemePicker();
        }
        if (can('settings.backup')) {
            await this.renderBackupSettings();
            await this.renderBackupList();
        }
        await this.renderUpdatePanel();
    },

    // ---------- Shop / company branding ----------
    renderShopProfile() {
        const box = document.getElementById('shop-profile');
        const b = AppState.business;
        if (!b) {
            box.innerHTML = `<div class="empty-state">Pehle koi business banayein.</div>`;
            return;
        }
        const logoInner = b.logo_data ? `<img src="${b.logo_data}" alt="logo" />` : 'Shop logo';
        const brandInner = b.brand_logo_data ? `<img src="${b.brand_logo_data}" alt="brand" />` : 'Brand logo';
        const size = b.invoice_size || 'ask';
        const sizeOpt = (val, label, hint) => `
            <label style="display:flex; align-items:flex-start; gap:8px; margin:6px 0; cursor:pointer;">
                <input type="radio" name="sp-size" value="${val}" style="width:auto; margin-top:3px;" ${size === val ? 'checked' : ''} />
                <span style="color:var(--text);"><strong>${label}</strong><br/><span style="color:var(--text-muted); font-size:12px;">${hint}</span></span>
            </label>`;
        box.innerHTML = `
            <div style="display:flex; gap:18px; flex-wrap:wrap; align-items:flex-start;">
                <div style="display:flex; flex-direction:column; gap:14px;">
                    <div>
                        <div class="hint" style="margin:0 0 4px;">Shop logo (invoice par left)</div>
                        <div class="logo-preview" id="sp-logo-preview">${logoInner}</div>
                        <div style="display:flex; gap:6px; margin-top:8px;">
                            <button class="btn btn-secondary btn-sm" id="sp-pick-logo">Upload</button>
                            <button class="btn btn-secondary btn-sm" id="sp-clear-logo" ${b.logo_data ? '' : 'disabled'}>Remove</button>
                        </div>
                    </div>
                    <div>
                        <div class="hint" style="margin:0 0 4px;">Brand logo (invoice par right)</div>
                        <div class="logo-preview">${brandInner}</div>
                        <div style="display:flex; gap:6px; margin-top:8px;">
                            <button class="btn btn-secondary btn-sm" id="sp-pick-brand">Upload</button>
                            <button class="btn btn-secondary btn-sm" id="sp-clear-brand" ${b.brand_logo_data ? '' : 'disabled'}>Remove</button>
                        </div>
                    </div>
                </div>
                <div style="flex:1; min-width:260px;">
                    <label>Shop / Company Name</label>
                    <input type="text" id="sp-name" value="${esc(b.name)}" />
                    <label>Tagline (optional)</label>
                    <input type="text" id="sp-tagline" value="${esc(b.tagline || '')}" placeholder="e.g. Quality you can trust" />
                    <div class="grid-2">
                        <div><label>Phone</label><input type="text" id="sp-phone" value="${esc(b.phone || '')}" /></div>
                        <div><label>Address</label><input type="text" id="sp-address" value="${esc(b.address || '')}" /></div>
                    </div>
                    <label>Brand Title (brand logo ke neeche, optional)</label>
                    <input type="text" id="sp-brand-title" value="${esc(b.brand_title || '')}" placeholder="e.g. Electric Scooter" />
                    <label>Important Information / Receipt Footer</label>
                    <textarea id="sp-footer" rows="3" placeholder="e.g. Sold goods cannot be refunded or exchanged...">${esc(b.receipt_footer || '')}</textarea>
                    <div style="margin-top:14px; padding-top:10px; border-top:1px solid var(--border);">
                        <strong style="font-size:13px;">Invoice Print Size</strong>
                        ${sizeOpt('a4', 'A4 — Full page', 'Receipt book jaisa bara invoice')}
                        ${sizeOpt('a5', 'A5 — Half page', 'Wohi design, aadhe page par')}
                        ${sizeOpt('thermal', '80mm Thermal', 'Chhoti receipt printer ke liye')}
                        ${sizeOpt('ask', 'Har dafa poochein', 'Print karte waqt size chunein')}
                    </div>
                    <div style="display:flex; gap:8px; margin-top:14px; flex-wrap:wrap;">
                        <button class="btn btn-primary" id="sp-save">Save Profile</button>
                        <button class="btn btn-secondary" id="sp-preview">Preview Invoice</button>
                    </div>
                </div>
            </div>
            <p class="hint" style="margin-top:12px;">Logo database mein save hota hai, is liye backup/restore ke sath khud chala jata hai — alag se file rakhne ki zarurat nahi.</p>
        `;

        document.getElementById('sp-pick-logo').addEventListener('click', () => this.pickLogo());
        document.getElementById('sp-clear-logo').addEventListener('click', () => this.saveProfile({ logo_data: null }));
        document.getElementById('sp-pick-brand').addEventListener('click', () => this.pickLogo('brand_logo_data'));
        document.getElementById('sp-clear-brand').addEventListener('click', () => this.saveProfile({ brand_logo_data: null }));
        // Paper size saves as soon as it is picked
        box.querySelectorAll('input[name="sp-size"]').forEach(r => r.addEventListener('change', () => {
            this.saveProfile({ invoice_size: r.value });
        }));
        document.getElementById('sp-save').addEventListener('click', () => this.saveProfile());
        document.getElementById('sp-preview').addEventListener('click', () => this.previewBill());
    },

    // Shrink the chosen image before storing so the database stays small and
    // the logo prints cleanly on a narrow receipt.
    async pickLogo(field = 'logo_data') {
        const res = await call(window.api.business.pickLogo());
        if (res.cancelled) return;
        try {
            const resized = await this.resizeDataUri(res.dataUri, 500, 500);
            await this.saveProfile({ [field]: resized });
        } catch (err) {
            showToast('Logo process nahi ho saka', 'error');
        }
    },

    resizeDataUri(dataUri, maxW, maxH) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                const scale = Math.min(1, maxW / img.width, maxH / img.height);
                const w = Math.max(1, Math.round(img.width * scale));
                const h = Math.max(1, Math.round(img.height * scale));
                const canvas = document.createElement('canvas');
                canvas.width = w; canvas.height = h;
                canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                // PNG keeps transparency, which matters for logos on white receipts
                resolve(canvas.toDataURL('image/png'));
            };
            img.onerror = () => reject(new Error('Invalid image'));
            img.src = dataUri;
        });
    },

    async saveProfile(extraPatch) {
        const b = AppState.business;
        if (!b) return;
        const patch = extraPatch || {};
        if (!extraPatch) {
            const name = document.getElementById('sp-name').value.trim();
            if (!name) { showToast('Shop ka naam zaroori hai', 'error'); return; }
            Object.assign(patch, {
                name,
                tagline: document.getElementById('sp-tagline').value.trim(),
                phone: document.getElementById('sp-phone').value.trim(),
                address: document.getElementById('sp-address').value.trim(),
                receipt_footer: document.getElementById('sp-footer').value.trim(),
                brand_title: document.getElementById('sp-brand-title').value.trim(),
            });
        }

        const updated = await call(window.api.business.update(b.id, patch));

        // Keep in-memory state in sync so branding updates everywhere at once
        AppState.business = updated;
        const idx = AppState.businesses.findIndex(x => x.id === updated.id);
        if (idx >= 0) AppState.businesses[idx] = updated;
        App.populateBusinessSelect();
        document.getElementById('business-select').value = updated.id;
        App.paintSidebarBranding();

        showToast('Profile saved', 'success');
        this.renderShopProfile();
    },

    previewBill() {
        const b = AppState.business;
        const isAuto = b.business_type === 'automobile';
        printReceipt({
            business: b,
            branch: AppState.branch || { name: 'Main Branch' },
            customer: { name: 'Ahmed Raza', guardian_name: 'S/O Muhammad Ali', cnic_no: '45102-1234567-1', phone: '0300-1234567', address: 'Court Road, Nawabshah' },
            sale: {
                invoice_no: 'SAMPLE-0001', sale_date: new Date().toISOString().slice(0, 10),
                total: isAuto ? 230000 : 1300, discount: 0, paid_amount: isAuto ? 200000 : 1300, payment_method: 'cash',
            },
            items: isAuto ? [{
                product_name: 'EVEE S QUBE', quantity: 1, total: 230000, is_vehicle: 1,
                model: '2026', color: 'Black', motor_power: '1500W', motor_no: 'MTR-00001', chassis_no: 'CHS-00001',
            }] : [
                { product_name: 'Sample Item A', quantity: 2, total: 1000 },
                { product_name: 'Sample Item B', quantity: 1, total: 300 },
            ],
        });
    },

    // ---------- Theme ----------
    async renderThemePicker() {
        const current = document.documentElement.getAttribute('data-theme') || 'royal';
        const grid = document.getElementById('theme-grid');
        grid.innerHTML = THEMES.map(t => `
            <button class="theme-option ${t.id === current ? 'active' : ''}" data-theme-id="${t.id}">
                <div class="swatches">
                    ${t.swatch.map(c => `<span class="sw" style="background:${c}"></span>`).join('')}
                </div>
                <div class="t-name">${t.name}</div>
                <div class="t-desc">${t.desc}</div>
            </button>
        `).join('');

        grid.querySelectorAll('.theme-option').forEach(btn => {
            btn.addEventListener('click', async () => {
                await saveTheme(btn.dataset.themeId);
                grid.querySelectorAll('.theme-option').forEach(x => x.classList.remove('active'));
                btn.classList.add('active');
                showToast('Theme applied', 'success');
            });
        });
    },

    // ---------- Automatic backup ----------
    async renderBackupSettings() {
        const s = await call(window.api.settings.get());
        const box = document.getElementById('backup-settings');
        const last = s.lastBackupAt ? new Date(s.lastBackupAt).toLocaleString() : 'Abhi tak koi backup nahi';
        box.innerHTML = `
            <label style="display:flex; align-items:center; gap:8px; margin:0 0 12px;">
                <input type="checkbox" id="bk-enabled" style="width:auto;" ${s.autoBackupEnabled ? 'checked' : ''} />
                <span style="color:var(--text); font-size:13px;">Automatic backup on karein</span>
            </label>
            <label>Backup Folder</label>
            <div style="display:flex; gap:8px; align-items:center;">
                <input type="text" id="bk-folder" value="${s.backupFolder || ''}" placeholder="Koi folder choose karein..." readonly />
                <button class="btn btn-secondary btn-sm" id="bk-choose" style="white-space:nowrap;">Choose</button>
            </div>
            <div class="grid-2" style="margin-top:10px;">
                <label style="display:flex; align-items:center; gap:8px; margin:0;">
                    <input type="checkbox" id="bk-onclose" style="width:auto;" ${s.backupOnClose ? 'checked' : ''} />
                    <span style="color:var(--text); font-size:13px;">App band hone par</span>
                </label>
                <label style="display:flex; align-items:center; gap:8px; margin:0;">
                    <input type="checkbox" id="bk-daily" style="width:auto;" ${s.backupDailyOnOpen ? 'checked' : ''} />
                    <span style="color:var(--text); font-size:13px;">Rozana (app khulne par)</span>
                </label>
            </div>
            <label>Kitne backups rakhne hain</label>
            <input type="number" id="bk-keep" value="${s.keepBackups}" min="1" max="365" />
            <p class="hint" style="margin-top:10px;">Aakhri backup: <strong>${last}</strong></p>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button class="btn btn-primary" id="bk-now">Backup Now</button>
                <button class="btn btn-secondary" id="bk-export">Save Copy As...</button>
                <button class="btn btn-danger" id="bk-restore-file">Restore from File</button>
            </div>
        `;

        const saveField = async (patch) => { await call(window.api.settings.save(patch)); };

        document.getElementById('bk-enabled').addEventListener('change', async (e) => {
            await saveField({ autoBackupEnabled: e.target.checked });
            showToast(e.target.checked ? 'Auto-backup on' : 'Auto-backup off', 'success');
        });
        document.getElementById('bk-onclose').addEventListener('change', (e) => saveField({ backupOnClose: e.target.checked }));
        document.getElementById('bk-daily').addEventListener('change', (e) => saveField({ backupDailyOnOpen: e.target.checked }));
        document.getElementById('bk-keep').addEventListener('change', (e) => saveField({ keepBackups: Number(e.target.value || 14) }));

        document.getElementById('bk-choose').addEventListener('click', async () => {
            const res = await call(window.api.backup.chooseFolder());
            if (res.cancelled) return;
            showToast('Backup folder set', 'success');
            await this.renderBackupSettings();
            await this.renderBackupList();
        });

        document.getElementById('bk-now').addEventListener('click', async () => {
            try {
                const res = await call(window.api.backup.runNow());
                showToast('Backup ho gaya: ' + res.path.split(/[\\/]/).pop(), 'success');
                await this.renderBackupSettings();
                await this.renderBackupList();
            } catch (e) { /* toast already shown */ }
        });

        document.getElementById('bk-export').addEventListener('click', async () => {
            const res = await call(window.api.backup.create());
            if (!res.cancelled) showToast('Copy saved', 'success');
        });

        document.getElementById('bk-restore-file').addEventListener('click', async () => {
            if (!confirm('Restore karne se mojooda data replace ho jayega. Continue?')) return;
            const res = await call(window.api.backup.restore());
            if (res.cancelled) return;
            showToast('Restore complete. Reloading...', 'success');
            setTimeout(() => window.location.reload(), 1200);
        });
    },

    async renderBackupList() {
        const tbody = document.getElementById('backup-list');
        const list = await call(window.api.backup.list());
        if (!list.length) {
            tbody.innerHTML = `<tr><td colspan="4" class="empty-state">Koi backup nahi mila. Backup folder choose kar ke "Backup Now" dabayein.</td></tr>`;
            return;
        }
        tbody.innerHTML = list.map(b => `
            <tr>
                <td>${b.name}</td>
                <td>${new Date(b.mtime).toLocaleString()}</td>
                <td class="text-right">${(b.size / 1024).toFixed(0)} KB</td>
                <td><button class="btn-link" data-path="${b.path.replace(/"/g, '&quot;')}">Restore</button></td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', async () => {
                if (!confirm('Is backup se restore karein? Mojooda data replace ho jayega.')) return;
                await call(window.api.backup.restoreFrom(btn.dataset.path));
                showToast('Restore complete. Reloading...', 'success');
                setTimeout(() => window.location.reload(), 1200);
            });
        });
    },

    // ---------- Software update ----------
    async renderUpdatePanel() {
        const version = await call(window.api.update.currentVersion());
        const s = await call(window.api.settings.get());
        const panel = document.getElementById('update-panel');
        panel.innerHTML = `
            <p class="hint">Mojooda version: <strong>v${version}</strong></p>
            <label style="display:flex; align-items:center; gap:8px; margin:0 0 12px;">
                <input type="checkbox" id="up-auto" style="width:auto;" ${s.autoCheckUpdates ? 'checked' : ''} />
                <span style="color:var(--text); font-size:13px;">App khulne par khud update check karein</span>
            </label>
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button class="btn btn-primary" id="up-check">Check for Updates</button>
                <button class="btn btn-secondary hidden" id="up-download">Download Update</button>
                <button class="btn btn-primary hidden" id="up-install">Restart &amp; Install</button>
            </div>
            <p id="up-status" class="hint" style="margin-top:10px;">Update check ke liye internet chahiye. App khud offline chalti rahegi.</p>
        `;

        document.getElementById('up-auto').addEventListener('change', (e) =>
            call(window.api.settings.save({ autoCheckUpdates: e.target.checked })));
        document.getElementById('up-check').addEventListener('click', async () => {
            document.getElementById('up-status').textContent = 'Check kar rahe hain...';
            try { await call(window.api.update.check()); } catch (e) { /* status shown via event */ }
        });
        document.getElementById('up-download').addEventListener('click', () => call(window.api.update.download()));
        document.getElementById('up-install').addEventListener('click', () => call(window.api.update.install()));

        if (!SettingsPage._updateHooked) {
            SettingsPage._updateHooked = true;
            window.api.update.onStatus((p) => SettingsPage.handleUpdateStatus(p));
        }
    },

    handleUpdateStatus(p) {
        const status = document.getElementById('up-status');
        const dl = document.getElementById('up-download');
        const inst = document.getElementById('up-install');
        if (!status) return;   // user navigated away

        const msgs = {
            checking: 'Check kar rahe hain...',
            none: 'Aap ka software up to date hai.',
            available: `Naya version available hai: v${p.version}`,
            downloading: `Download ho raha hai... ${p.percent}%`,
            downloaded: `v${p.version} download ho gaya. Install ke liye restart karein.`,
            error: `Update check nahi ho saka: ${p.message}`,
        };
        status.textContent = msgs[p.state] || '';
        if (dl) dl.classList.toggle('hidden', p.state !== 'available');
        if (inst) inst.classList.toggle('hidden', p.state !== 'downloaded');
    },

    openBusinessModal() {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>New Business</h3>
                    <label>Name</label><input type="text" id="b-name" />
                    <label>Type</label>
                    <select id="b-type"><option value="general">General Store</option><option value="automobile">Automobile (Parts &amp; Service)</option><option value="bakery">Bakery/Restaurant</option><option value="pharmacy">Pharmacy</option><option value="other">Other</option></select>
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="b-cancel">Cancel</button>
                        <button class="btn btn-primary" id="b-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#b-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#b-save').addEventListener('click', async () => {
            const name = overlay.querySelector('#b-name').value.trim();
            if (!name) return;
            await call(window.api.business.create({ name, business_type: overlay.querySelector('#b-type').value }));
            showToast('Business created', 'success');
            overlay.remove();
            await App.loadBusinesses();
            this.render();
        });
    },

    openBranchModal() {
        if (!AppState.business) { showToast('Pehle business select karein', 'error'); return; }
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>New Branch</h3>
                    <label>Name</label><input type="text" id="br-name" />
                    <label>Address</label><input type="text" id="br-address" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="br-cancel">Cancel</button>
                        <button class="btn btn-primary" id="br-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#br-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#br-save').addEventListener('click', async () => {
            const name = overlay.querySelector('#br-name').value.trim();
            if (!name) return;
            await call(window.api.branch.create({ business_id: AppState.business.id, name, address: overlay.querySelector('#br-address').value }));
            showToast('Branch created', 'success');
            overlay.remove();
            await App.loadBranches();
            this.render();
        });
    },

    // ---------- Users & permissions ----------
    async renderUsers() {
        const tbody = document.getElementById('set-users');
        if (!AppState.business) { tbody.innerHTML = ''; return; }

        const users = await call(window.api.auth.listUsers(AppState.business.id));
        this._users = users;
        tbody.innerHTML = users.map(u => `
            <tr>
                <td>${esc(u.username)}${u.id === AppState.user.id ? ' <span class="badge amber">You</span>' : ''}</td>
                <td>${esc(u.full_name || '-')}</td>
                <td>${esc(u.role)}</td>
                <td><span class="badge ${u.active ? 'green' : 'red'}">${u.active ? 'Active' : 'Disabled'}</span></td>
                <td>
                    <button class="btn-link" data-act="edit" data-id="${u.id}">Edit</button>
                    ${u.id !== AppState.user.id ? `<button class="btn-link" data-act="del" data-id="${u.id}" style="color:var(--red);">Delete</button>` : ''}
                </td>
            </tr>
        `).join('');

        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', async () => {
                const u = users.find(x => x.id === Number(btn.dataset.id));
                if (btn.dataset.act === 'edit') this.openUserModal(u);
                else this.confirmDeleteUser(u);
            });
        });
    },

    async confirmDeleteUser(user) {
        if (!confirm(`"${user.username}" ko delete karein? Ye wapas nahi ho sakta.`)) return;
        try {
            await call(window.api.auth.deleteUser(user.id));
            showToast('User deleted', 'success');
            this.renderUsers();
        } catch (e) { /* toast already shown */ }
    },

    // Add or edit a user. The permission matrix starts from the role's defaults
    // and can then be ticked/unticked individually.
    openUserModal(user) {
        const isEdit = !!user;
        const catalog = AppState.permCatalog;
        const roles = ['cashier', 'manager', 'accountant', 'admin'];
        const startingPerms = isEdit
            ? (user.effective_permissions || [])
            : (catalog.roleDefaults.cashier || []);

        // Group permissions by their section for a readable checklist
        const groups = {};
        for (const p of catalog.permissions) {
            (groups[p.group] = groups[p.group] || []).push(p);
        }
        const matrixHtml = Object.entries(groups).map(([group, perms]) => `
            <div style="margin-bottom:12px;">
                <div style="font-weight:600; font-size:12px; color:var(--text-muted); text-transform:uppercase; margin-bottom:5px;">${esc(group)}</div>
                ${perms.map(p => `
                    <label style="display:flex; align-items:center; gap:8px; margin:0 0 5px;">
                        <input type="checkbox" class="perm-box" value="${p.key}" style="width:auto;" ${startingPerms.includes(p.key) ? 'checked' : ''} />
                        <span style="color:var(--text); font-size:13px;">${esc(p.label)}</span>
                    </label>
                `).join('')}
            </div>
        `).join('');

        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box" style="max-width:560px;">
                    <h3>${isEdit ? 'Edit User: ' + esc(user.username) : 'New User'}</h3>
                    <div class="grid-2">
                        <div><label>Username</label><input type="text" id="u-username" value="${isEdit ? esc(user.username) : ''}" /></div>
                        <div><label>Full Name</label><input type="text" id="u-fullname" value="${isEdit ? esc(user.full_name || '') : ''}" /></div>
                    </div>
                    <label>${isEdit ? 'New Password (khali chhorein to nahi badlega)' : 'Password'}</label>
                    <input type="password" id="u-password" />
                    <div class="grid-2">
                        <div>
                            <label>Role</label>
                            <select id="u-role">${roles.map(r => `<option value="${r}" ${isEdit && user.role === r ? 'selected' : ''}>${r}</option>`).join('')}</select>
                        </div>
                        <div>
                            <label>Status</label>
                            <select id="u-active">
                                <option value="1" ${!isEdit || user.active ? 'selected' : ''}>Active</option>
                                <option value="0" ${isEdit && !user.active ? 'selected' : ''}>Disabled</option>
                            </select>
                        </div>
                    </div>

                    <div style="margin-top:16px; border-top:1px solid var(--border); padding-top:12px;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; flex-wrap:wrap; gap:8px;">
                            <strong style="font-size:14px;">Permissions</strong>
                            <div style="display:flex; gap:6px;">
                                <button class="btn btn-secondary btn-sm" id="u-reset-role">Role defaults</button>
                                <button class="btn btn-secondary btn-sm" id="u-none">Clear all</button>
                            </div>
                        </div>
                        <div id="u-matrix" style="max-height:260px; overflow-y:auto; padding-right:4px;">${matrixHtml}</div>
                    </div>

                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="u-cancel">Cancel</button>
                        <button class="btn btn-primary" id="u-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);

        const setBoxes = (keys) => {
            overlay.querySelectorAll('.perm-box').forEach(b => { b.checked = keys.includes(b.value); });
        };

        // Changing the role re-seeds the checkboxes with that role's defaults
        overlay.querySelector('#u-role').addEventListener('change', (e) => {
            setBoxes(catalog.roleDefaults[e.target.value] || []);
        });
        overlay.querySelector('#u-reset-role').addEventListener('click', () => {
            setBoxes(catalog.roleDefaults[overlay.querySelector('#u-role').value] || []);
        });
        overlay.querySelector('#u-none').addEventListener('click', () => setBoxes([]));
        overlay.querySelector('#u-cancel').addEventListener('click', () => overlay.remove());

        overlay.querySelector('#u-save').addEventListener('click', async () => {
            const username = overlay.querySelector('#u-username').value.trim();
            const password = overlay.querySelector('#u-password').value;
            const role = overlay.querySelector('#u-role').value;
            const active = overlay.querySelector('#u-active').value === '1';
            const perms = Array.from(overlay.querySelectorAll('.perm-box:checked')).map(b => b.value);

            if (!username) { showToast('Username zaroori hai', 'error'); return; }
            if (!isEdit && !password) { showToast('Password zaroori hai', 'error'); return; }

            try {
                if (isEdit) {
                    const patch = {
                        username, full_name: overlay.querySelector('#u-fullname').value.trim(),
                        role, active, permissions: perms,
                    };
                    if (password) patch.password = password;
                    await call(window.api.auth.updateUser(user.id, patch));

                    // If the admin edited their own account, refresh live permissions
                    if (user.id === AppState.user.id) {
                        AppState.user = { ...AppState.user, role, effective_permissions: perms };
                        AppState.permissions = role === 'super_admin' ? AppState.permissions : perms;
                        App.applyPermissionsToNav();
                    }
                } else {
                    await call(window.api.auth.createUser({
                        business_id: AppState.business.id, username, password,
                        full_name: overlay.querySelector('#u-fullname').value.trim(),
                        role, permissions: perms,
                    }));
                }
                showToast('User saved', 'success');
                overlay.remove();
                this.renderUsers();
            } catch (e) { /* toast already shown */ }
        });
    },
};
