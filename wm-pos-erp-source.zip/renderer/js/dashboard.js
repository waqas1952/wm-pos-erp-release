const DashboardPage = {
    async render() {
        const container = document.getElementById('page-dashboard');

        if (!AppState.business || !AppState.branch) {
            container.innerHTML = `<div class="empty-state">Pehle koi business aur branch select karein.</div>`;
            return;
        }

        const b = AppState.business;
        const logoHtml = b.logo_data
            ? `<img src="${b.logo_data}" alt="logo" />`
            : esc(initialsOf(b.name));
        const metaParts = [b.address, b.phone].filter(Boolean).map(esc);

        container.innerHTML = `
            <div class="shop-header">
                <div class="shop-logo">${logoHtml}</div>
                <div>
                    <h2>${esc(b.name)}</h2>
                    <div class="shop-meta">${b.tagline ? esc(b.tagline) + ' — ' : ''}${metaParts.join(' • ') || AppState.branch.name}</div>
                </div>
            </div>
            <div id="dash-stats" class="grid-3"></div>
            <div class="card" style="margin-top:18px;">
                <h3 style="margin-top:0;">Top Selling Products (This Month)</h3>
                <table id="dash-top-products"><thead><tr><th>Product</th><th class="text-right">Qty Sold</th><th class="text-right">Revenue</th></tr></thead><tbody></tbody></table>
            </div>`;

        const isAutomobile = b.business_type === 'automobile';
        const today = todayRange();
        const month = monthRange();

        const [todaySales, monthSales, lowStock, pnl, top, openJobs, todayPnl, monthVehicles] = await Promise.all([
            call(window.api.report.salesSummary(AppState.business.id, today.from, today.to)),
            call(window.api.report.salesSummary(AppState.business.id, month.from, month.to)),
            call(window.api.stock.lowStock(AppState.branch.id)),
            call(window.api.report.profitLoss(AppState.business.id, month.from, month.to)),
            call(window.api.report.topProducts(AppState.business.id, month.from, month.to, 8)),
            isAutomobile ? call(window.api.serviceJob.list(AppState.business.id, AppState.branch.id)) : Promise.resolve([]),
            call(window.api.report.profitLoss(AppState.business.id, today.from, today.to)),
            isAutomobile ? call(window.api.vehicleSale.summary(AppState.business.id, month.from, month.to)) : Promise.resolve(null),
        ]);

        const statsEl = document.getElementById('dash-stats');
        statsEl.innerHTML = `
            <div class="stat-card"><div class="label">Today's Sales</div><div class="value">${money(todayPnl.salesTotal)}</div></div>
            <div class="stat-card"><div class="label">This Month Sales</div><div class="value">${money(pnl.salesTotal)}</div></div>
            <div class="stat-card"><div class="label">Net Profit (Month)</div><div class="value ${pnl.netProfit >= 0 ? 'green' : 'red'}">${money(pnl.netProfit)}</div></div>
            <div class="stat-card"><div class="label">Today's Invoices</div><div class="value">${todaySales.invoice_count}</div></div>
            <div class="stat-card"><div class="label">Amount Due (Today)</div><div class="value red">${money(todaySales.total_due)}</div></div>
            <div class="stat-card"><div class="label">Low Stock Items</div><div class="value ${lowStock.length ? 'red' : ''}">${lowStock.length}</div></div>
            ${isAutomobile && monthVehicles ? `<div class="stat-card"><div class="label">Vehicles Sold (Month)</div><div class="value">${monthVehicles.unitsSold}</div></div>
            <div class="stat-card"><div class="label">Vehicles In Stock</div><div class="value">${monthVehicles.inStock}</div></div>` : ''}
            ${isAutomobile ? `<div class="stat-card"><div class="label">Open Service Jobs</div><div class="value ${openJobs.filter(j => j.status !== 'delivered' && j.status !== 'cancelled').length ? 'amber' : ''}">${openJobs.filter(j => j.status !== 'delivered' && j.status !== 'cancelled').length}</div></div>` : ''}
        `;

        const tbody = document.querySelector('#dash-top-products tbody');
        tbody.innerHTML = top.length ? top.map(p => `<tr><td>${p.name}</td><td class="text-right">${p.qty_sold}</td><td class="text-right">${money(p.revenue)}</td></tr>`).join('') :
            `<tr><td colspan="3" class="empty-state">Is mahine koi sale nahi hui.</td></tr>`;
    }
};
