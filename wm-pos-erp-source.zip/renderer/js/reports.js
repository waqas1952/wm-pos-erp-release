const ReportsPage = {
    async render() {
        const container = document.getElementById('page-reports');
        if (!AppState.business) {
            container.innerHTML = `<div class="empty-state">Pehle koi business select karein.</div>`;
            return;
        }
        const month = monthRange();
        container.innerHTML = `
            <div class="page-header"><h2>Reports</h2></div>
            <div class="toolbar">
                <label style="margin:0;">From</label><input type="date" id="rep-from" value="${month.from.slice(0,10)}" />
                <label style="margin:0;">To</label><input type="date" id="rep-to" value="${month.to.slice(0,10)}" />
                <button id="rep-run" class="btn btn-primary btn-sm">Run Report</button>
            </div>
            <div class="grid-3" id="rep-summary" style="margin-bottom:18px;"></div>
            ${AppState.business.business_type === 'automobile' ? `
            <div class="card">
                <h3 style="margin-top:0;">Vehicle Sales (Bikes / Cars)</h3>
                <div class="grid-3" id="rep-vehicle-summary"></div>
            </div>
            <div class="card">
                <h3 style="margin-top:0;">Service Jobs — Labor vs Parts</h3>
                <div class="grid-3" id="rep-jobs-summary"></div>
            </div>` : ''}
            <div class="grid-2">
                <div class="card">
                    <h3 style="margin-top:0;">Top Selling Products</h3>
                    <table><thead><tr><th>Product</th><th class="text-right">Qty</th><th class="text-right">Revenue</th></tr></thead><tbody id="rep-top"></tbody></table>
                </div>
                <div class="card">
                    <h3 style="margin-top:0;">Expenses</h3>
                    <table><thead><tr><th>Date</th><th>Category</th><th class="text-right">Amount</th></tr></thead><tbody id="rep-expenses"></tbody></table>
                </div>
            </div>
            <div class="card">
                <h3 style="margin-top:0;">Low Stock Items ${AppState.branch ? '' : '(select a branch)'}</h3>
                <table><thead><tr><th>Product</th><th class="text-right">Current Stock</th><th class="text-right">Reorder Level</th></tr></thead><tbody id="rep-lowstock"></tbody></table>
            </div>
        `;
        document.getElementById('rep-run').addEventListener('click', () => this.run());
        await this.run();
    },

    async run() {
        const from = document.getElementById('rep-from').value + ' 00:00:00';
        const to = document.getElementById('rep-to').value + ' 23:59:59';

        const [summary, pnl, top, expenses] = await Promise.all([
            call(window.api.report.salesSummary(AppState.business.id, from, to)),
            call(window.api.report.profitLoss(AppState.business.id, from, to)),
            call(window.api.report.topProducts(AppState.business.id, from, to, 10)),
            call(window.api.expense.list(AppState.business.id, from, to)),
        ]);

        document.getElementById('rep-summary').innerHTML = `
            <div class="stat-card"><div class="label">Total Sales</div><div class="value">${money(summary.total_sales)}</div></div>
            <div class="stat-card"><div class="label">Cost of Goods Sold</div><div class="value">${money(pnl.cogs)}</div></div>
            <div class="stat-card"><div class="label">Gross Profit</div><div class="value green">${money(pnl.grossProfit)}</div></div>
            <div class="stat-card"><div class="label">Total Expenses</div><div class="value red">${money(pnl.expensesTotal)}</div></div>
            <div class="stat-card"><div class="label">Net Profit</div><div class="value ${pnl.netProfit >= 0 ? 'green' : 'red'}">${money(pnl.netProfit)}</div></div>
            <div class="stat-card"><div class="label">Amount Due from Customers</div><div class="value red">${money(summary.total_due)}</div></div>
        `;

        document.getElementById('rep-top').innerHTML = top.length ?
            top.map(p => `<tr><td>${p.name}</td><td class="text-right">${p.qty_sold}</td><td class="text-right">${money(p.revenue)}</td></tr>`).join('') :
            `<tr><td colspan="3" class="empty-state">Koi data nahi.</td></tr>`;

        document.getElementById('rep-expenses').innerHTML = expenses.length ?
            expenses.map(e => `<tr><td>${e.expense_date}</td><td>${e.category}</td><td class="text-right">${money(e.amount)}</td></tr>`).join('') :
            `<tr><td colspan="3" class="empty-state">Koi expense record nahi.</td></tr>`;

        if (AppState.business.business_type === 'automobile') {
            const vs = await call(window.api.vehicleSale.summary(AppState.business.id, from, to));
            document.getElementById('rep-vehicle-summary').innerHTML = `
                <div class="stat-card"><div class="label">Vehicles Sold</div><div class="value">${vs.unitsSold}</div></div>
                <div class="stat-card"><div class="label">Vehicle Revenue</div><div class="value">${money(vs.revenue)}</div></div>
                ${can('reports.profit') ? `<div class="stat-card"><div class="label">Vehicle Profit</div><div class="value ${vs.profit >= 0 ? 'green' : 'red'}">${money(vs.profit)}</div></div>` : ''}
                <div class="stat-card"><div class="label">Balance Due (Vehicles)</div><div class="value ${vs.due > 0 ? 'red' : ''}">${money(vs.due)}</div></div>
                <div class="stat-card"><div class="label">Vehicles In Stock</div><div class="value">${vs.inStock}</div></div>
            `;
            const jobSummary = await call(window.api.serviceJob.summary(AppState.business.id, from, to));
            document.getElementById('rep-jobs-summary').innerHTML = `
                <div class="stat-card"><div class="label">Jobs Delivered</div><div class="value">${jobSummary.jobCount}</div></div>
                <div class="stat-card"><div class="label">Labor Revenue</div><div class="value">${money(jobSummary.laborTotal)}</div></div>
                <div class="stat-card"><div class="label">Parts Revenue</div><div class="value">${money(jobSummary.partsTotal)}</div></div>
            `;
        }

        if (AppState.branch) {
            const lowStock = await call(window.api.stock.lowStock(AppState.branch.id));
            document.getElementById('rep-lowstock').innerHTML = lowStock.length ?
                lowStock.map(s => `<tr><td>${s.name}</td><td class="text-right">${s.quantity}</td><td class="text-right">${s.reorder_level}</td></tr>`).join('') :
                `<tr><td colspan="3" class="empty-state">Sab products stock mein hain.</td></tr>`;
        }
    },
};
