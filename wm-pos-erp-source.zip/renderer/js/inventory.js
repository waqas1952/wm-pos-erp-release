const InventoryPage = {
    categories: [],

    async render() {
        const container = document.getElementById('page-inventory');
        if (!AppState.business || !AppState.branch) {
            container.innerHTML = `<div class="empty-state">Pehle koi business aur branch select karein.</div>`;
            return;
        }
        container.innerHTML = `
            <div class="page-header">
                <h2>Inventory</h2>
                <div style="display:flex; gap:8px;">
                    ${can('inventory.edit') ? '<button id="inv-add-category" class="btn btn-secondary">+ Category</button>' : ''}
                    ${can('inventory.edit') ? '<button id="inv-add-product" class="btn btn-primary">+ Add Product</button>' : ''}
                </div>
            </div>
            <div class="toolbar">
                <input type="text" id="inv-search" placeholder="Search products..." />
            </div>
            <div class="card">
                <table>
                    <thead><tr><th>Name</th><th>Category</th><th>Barcode</th>${AppState.business.business_type === 'automobile' ? '<th>Colour</th><th>Model</th>' : ''}${can('inventory.cost') ? '<th class="text-right">Cost</th>' : ''}<th class="text-right">Sale Price</th><th class="text-right">Stock</th><th></th></tr></thead>
                    <tbody id="inv-table-body"></tbody>
                </table>
            </div>
        `;
        this.categories = await call(window.api.category.list(AppState.business.id));
        await this.loadTable();

        document.getElementById('inv-search').addEventListener('input', (e) => this.loadTable(e.target.value));
        const addProd = document.getElementById('inv-add-product');
        if (addProd) addProd.addEventListener('click', () => this.openProductModal());
        const addCat = document.getElementById('inv-add-category');
        if (addCat) addCat.addEventListener('click', () => this.openCategoryModal());
    },

    async loadTable(search) {
        const products = await call(window.api.product.list(AppState.business.id, { search }));
        const stockList = await call(window.api.stock.listForBranch(AppState.branch.id));
        const stockMap = {};
        stockList.forEach(s => stockMap[s.product_id] = s.quantity);
        const catMap = {};
        this.categories.forEach(c => catMap[c.id] = c.name);

        const tbody = document.getElementById('inv-table-body');
        const isAutomobile = AppState.business.business_type === 'automobile';
        const colCount = 6 + (isAutomobile ? 2 : 0) + (can('inventory.cost') ? 1 : 0);
        if (!products.length) {
            tbody.innerHTML = `<tr><td colspan="${colCount}" class="empty-state">Koi product nahi mila.</td></tr>`;
            return;
        }
        tbody.innerHTML = products.map(p => {
            const stock = stockMap[p.id] || 0;
            const low = stock <= p.reorder_level;
            return `<tr>
                <td>${esc(p.name)}</td>
                <td>${esc(catMap[p.category_id] || '-')}</td>
                <td>${esc(p.barcode || '-')}</td>
                ${isAutomobile ? `<td>${esc(p.color || '-')}</td><td>${esc(p.model || '-')}</td>` : ''}
                ${can('inventory.cost') ? `<td class="text-right">${money(p.cost_price)}</td>` : ''}
                <td class="text-right">${money(p.sale_price)}</td>
                <td class="text-right">${stock} ${low ? '<span class="badge red">Low</span>' : ''}</td>
                <td>
                    ${can('inventory.edit') ? `<button class="btn-link" data-act="edit" data-id="${p.id}">Edit</button>` : ''}
                    ${can('inventory.adjust') ? `<button class="btn-link" data-act="adjust" data-id="${p.id}">Adjust Stock</button>` : ''}
                </td>
            </tr>`;
        }).join('');

        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = Number(btn.dataset.id);
                const p = products.find(x => x.id === id);
                if (btn.dataset.act === 'edit') this.openProductModal(p);
                else this.openAdjustModal(p, stockMap[id] || 0);
            });
        });
    },

    openCategoryModal() {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>New Category</h3>
                    <label>Category Name</label>
                    <input type="text" id="cat-name" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="cat-cancel">Cancel</button>
                        <button class="btn btn-primary" id="cat-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#cat-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#cat-save').addEventListener('click', async () => {
            const name = overlay.querySelector('#cat-name').value.trim();
            if (!name) return;
            await call(window.api.category.create({ business_id: AppState.business.id, name }));
            this.categories = await call(window.api.category.list(AppState.business.id));
            showToast('Category added', 'success');
            overlay.remove();
            this.loadTable();
        });
    },

    openProductModal(product) {
        const isEdit = !!product;
        const isAutomobile = AppState.business && AppState.business.business_type === 'automobile';
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>${isEdit ? 'Edit Product' : 'Add Product'}</h3>
                    <label>Name</label><input type="text" id="p-name" value="${product ? esc(product.name) : ''}" />
                    <label>Category</label>
                    <select id="p-category"><option value="">-- none --</option>${this.categories.map(c => `<option value="${c.id}" ${product && product.category_id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>
                    <div class="grid-2">
                        <div><label>Barcode / SKU</label><input type="text" id="p-barcode" value="${product ? esc(product.barcode || '') : ''}" /></div>
                        <div><label>Unit</label><input type="text" id="p-unit" value="${product ? esc(product.unit) : 'pcs'}" /></div>
                    </div>
                    ${isAutomobile ? `
                    <div class="grid-2">
                        <div><label>Colour</label><input type="text" id="p-color" value="${product ? esc(product.color || '') : ''}" placeholder="e.g. Red" /></div>
                        <div><label>Model</label><input type="text" id="p-model" value="${product ? esc(product.model || '') : ''}" placeholder="e.g. 2026" /></div>
                    </div>
                    <label style="display:flex; align-items:center; gap:8px; margin-top:12px;">
                        <input type="checkbox" id="p-isvehicle" style="width:auto;" ${product ? (product.is_vehicle ? 'checked' : '') : 'checked'} />
                        <span style="color:var(--text);">Ye bike/car hai — invoice par Chassis No, Motor No, Motor Power poocha jayega</span>
                    </label>
                    <div class="grid-2" id="p-part-fields">
                        <div><label>Part Number</label><input type="text" id="p-partnum" value="${product ? esc(product.part_number || '') : ''}" placeholder="e.g. BP-4402" /></div>
                        <div><label>Compatible Vehicles</label><input type="text" id="p-fitment" value="${product ? esc(product.compatible_vehicles || '') : ''}" placeholder="e.g. Civic 2016-2021" /></div>
                    </div>` : ''}
                    <div class="grid-2">
                        <div><label>Cost Price</label><input type="number" id="p-cost" value="${product ? product.cost_price : 0}" /></div>
                        <div><label>Sale Price</label><input type="number" id="p-sale" value="${product ? product.sale_price : 0}" /></div>
                    </div>
                    <div class="grid-2">
                        <div><label>Tax %</label><input type="number" id="p-tax" value="${product ? product.tax_percent : 0}" /></div>
                        <div><label>Reorder Level</label><input type="number" id="p-reorder" value="${product ? product.reorder_level : 5}" /></div>
                    </div>
                    ${isEdit ? '<label style="margin-top:14px;"><input type="checkbox" id="p-active" style="width:auto;" ' + (product.active ? 'checked' : '') + ' /> Active</label>' : ''}
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="p-cancel">Cancel</button>
                        <button class="btn btn-primary" id="p-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        const vehBox = overlay.querySelector('#p-isvehicle');
        if (vehBox) {
            const syncPartFields = () => overlay.querySelector('#p-part-fields').classList.toggle('hidden', vehBox.checked);
            vehBox.addEventListener('change', syncPartFields);
            syncPartFields();
        }
        overlay.querySelector('#p-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#p-save').addEventListener('click', async () => {
            const payload = {
                business_id: AppState.business.id,
                category_id: overlay.querySelector('#p-category').value ? Number(overlay.querySelector('#p-category').value) : null,
                name: overlay.querySelector('#p-name').value.trim(),
                barcode: overlay.querySelector('#p-barcode').value.trim(),
                sku: overlay.querySelector('#p-barcode').value.trim(),
                unit: overlay.querySelector('#p-unit').value.trim() || 'pcs',
                cost_price: Number(overlay.querySelector('#p-cost').value || 0),
                sale_price: Number(overlay.querySelector('#p-sale').value || 0),
                tax_percent: Number(overlay.querySelector('#p-tax').value || 0),
                reorder_level: Number(overlay.querySelector('#p-reorder').value || 0),
            };
            if (isAutomobile) {
                payload.color = overlay.querySelector('#p-color').value.trim();
                payload.model = overlay.querySelector('#p-model').value.trim();
                payload.is_vehicle = overlay.querySelector('#p-isvehicle').checked;
                payload.part_number = overlay.querySelector('#p-partnum').value.trim();
                payload.compatible_vehicles = overlay.querySelector('#p-fitment').value.trim();
            }
            if (!payload.name) { showToast('Name required', 'error'); return; }
            if (isEdit) {
                payload.active = overlay.querySelector('#p-active').checked;
                await call(window.api.product.update(product.id, payload));
            } else {
                await call(window.api.product.create(payload));
            }
            showToast('Product saved', 'success');
            overlay.remove();
            this.loadTable();
        });
    },

    openAdjustModal(product, currentStock) {
        const overlay = el(`
            <div class="modal-overlay">
                <div class="modal-box">
                    <h3>Adjust Stock - ${product.name}</h3>
                    <p class="hint">Current stock: ${currentStock} ${product.unit}</p>
                    <label>Quantity Change (+ to add, - to remove)</label>
                    <input type="number" id="adj-qty" value="0" />
                    <label>Reason</label>
                    <input type="text" id="adj-reason" placeholder="e.g. damage, correction, opening stock" />
                    <div class="modal-actions">
                        <button class="btn btn-secondary" id="adj-cancel">Cancel</button>
                        <button class="btn btn-primary" id="adj-save">Save</button>
                    </div>
                </div>
            </div>`);
        document.body.appendChild(overlay);
        overlay.querySelector('#adj-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#adj-save').addEventListener('click', async () => {
            const qty = Number(overlay.querySelector('#adj-qty').value || 0);
            if (!qty) { showToast('Enter a non-zero quantity', 'error'); return; }
            await call(window.api.stock.adjust({
                business_id: AppState.business.id, branch_id: AppState.branch.id,
                product_id: product.id, quantity_change: qty,
                reason: overlay.querySelector('#adj-reason').value || 'manual', user_id: AppState.user.id,
            }));
            showToast('Stock adjusted', 'success');
            overlay.remove();
            this.loadTable();
        });
    },
};
