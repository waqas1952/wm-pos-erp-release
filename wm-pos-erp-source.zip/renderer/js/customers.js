// renderer/js/customers.js
// Customer records carry the same details printed on invoices (name,
// S/O-D/O-W/O, CNIC, contact, address), plus a khata: what they owe across
// counter sales, service jobs and vehicle sales, and payments received.

const CustomersPage = {
    async render() {
        const container = document.getElementById('page-customers');
        if (!AppState.business) {
            container.innerHTML = `<div class="empty-state">Pehle koi business select karein.</div>`;
            return;
        }
        container.innerHTML = `
            <div class="page-header">
                <h2>Customers</h2>
                ${can('customers.manage') ? '<button id="cust-add" class="btn btn-primary">+ Add Customer</button>' : ''}
            </div>
            <div class="toolbar">
                <input type="text" id="cust-search" placeholder="Naam, phone ya CNIC se search karein..." />
                <label style="display:flex; align-items:center; gap:6px; margin:0; white-space:nowrap;">
                    <input type="checkbox" id="cust-due-only" style="width:auto; flex:none; min-width:0;" /> Sirf baqi wale
                </label>
            </div>
            <div class="grid-3" id="cust-stats" style="margin-bottom:16px;"></div>
            <div class="card">
                <table>
                    <thead><tr><th>Full Name</th><th>S/O D/O W/O</th><th>CNIC No</th><th>Contact No</th><th>Address</th><th class="text-right">Balance</th><th></th></tr></thead>
                    <tbody id="cust-table-body"></tbody>
                </table>
            </div>
        `;
        document.getElementById('cust-search').addEventListener('input', () => this.loadTable());
        document.getElementById('cust-due-only').addEventListener('change', () => this.loadTable());
        const addBtn = document.getElementById('cust-add');
        if (addBtn) addBtn.addEventListener('click', () => openCustomerModal(null, () => this.loadTable()));
        await this.loadTable();
    },

    async loadTable() {
        const search = document.getElementById('cust-search').value.trim();
        const dueOnly = document.getElementById('cust-due-only').checked;
        let customers = await call(window.api.customer.list(AppState.business.id, { search }));
        const totalCount = customers.length;
        const totalDue = customers.reduce((s, c) => s + Math.max(0, c.balance), 0);
        const withDue = customers.filter(c => c.balance > 0).length;
        if (dueOnly) customers = customers.filter(c => c.balance > 0);

        document.getElementById('cust-stats').innerHTML = `
            <div class="stat-card"><div class="label">Total Customers</div><div class="value">${totalCount}</div></div>
            <div class="stat-card"><div class="label">Customers with Balance</div><div class="value ${withDue ? 'amber' : ''}">${withDue}</div></div>
            <div class="stat-card"><div class="label">Total Receivable</div><div class="value ${totalDue ? 'red' : ''}">${money(totalDue)}</div></div>
        `;

        const tbody = document.getElementById('cust-table-body');
        if (!customers.length) {
            tbody.innerHTML = `<tr><td colspan="7" class="empty-state">Koi customer nahi mila.</td></tr>`;
            return;
        }
        tbody.innerHTML = customers.map(c => `
            <tr>
                <td><strong>${esc(c.name)}</strong></td>
                <td>${esc(c.guardian_name || '-')}</td>
                <td>${esc(c.cnic_no || '-')}</td>
                <td>${esc(c.phone || '-')}</td>
                <td>${esc(c.address || '-')}</td>
                <td class="text-right" style="font-weight:600; color:${c.balance > 0 ? 'var(--red)' : c.balance < 0 ? 'var(--green)' : 'inherit'};">${money(c.balance)}</td>
                <td style="white-space:nowrap;">
                    <button class="btn-link" data-act="khata" data-id="${c.id}">Khata</button>
                    ${can('customers.payment') && c.balance > 0 ? `<button class="btn-link" data-act="pay" data-id="${c.id}">Payment</button>` : ''}
                    ${can('customers.manage') ? `<button class="btn-link" data-act="edit" data-id="${c.id}">Edit</button>` : ''}
                </td>
            </tr>
        `).join('');
        tbody.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', () => {
                const c = customers.find(x => x.id === Number(btn.dataset.id));
                if (btn.dataset.act === 'khata') openCustomerStatement(c.id, () => this.loadTable());
                else if (btn.dataset.act === 'pay') openReceivePaymentModal(c, () => this.loadTable());
                else openCustomerModal(c, () => this.loadTable());
            });
        });
    },
};

// Add / edit a customer. Used by the Customers page and by the POS quick-add
// button; onSaved receives the customer's id.
function openCustomerModal(customer, onSaved) {
    const isEdit = !!customer;
    const overlay = el(`
        <div class="modal-overlay">
            <div class="modal-box" style="max-width:520px;">
                <h3>${isEdit ? 'Edit Customer' : 'New Customer'}</h3>
                <label>Full Name</label>
                <input type="text" id="cu-name" value="${isEdit ? esc(customer.name) : ''}" />
                <label>S/O D/O W/O</label>
                <input type="text" id="cu-guardian" value="${isEdit ? esc(customer.guardian_name || '') : ''}" placeholder="e.g. S/O Muhammad Ali" />
                <div class="grid-2">
                    <div><label>CNIC No</label><input type="text" id="cu-cnic" value="${isEdit ? esc(customer.cnic_no || '') : ''}" placeholder="00000-0000000-0" /></div>
                    <div><label>Contact No</label><input type="text" id="cu-phone" value="${isEdit ? esc(customer.phone || '') : ''}" placeholder="03xx-xxxxxxx" /></div>
                </div>
                <label>Address</label>
                <input type="text" id="cu-address" value="${isEdit ? esc(customer.address || '') : ''}" />
                <label>Opening Balance (pehle se baqi raqam)</label>
                <input type="number" id="cu-opening" value="${isEdit ? (customer.opening_balance || 0) : 0}" min="0" />
                ${isEdit ? `<label style="display:flex; align-items:center; gap:8px; margin-top:12px;"><input type="checkbox" id="cu-active" style="width:auto;" ${customer.active === 0 ? '' : 'checked'} /> <span style="color:var(--text);">Active</span></label>` : ''}
                <div class="modal-actions">
                    <button class="btn btn-secondary" id="cu-cancel">Cancel</button>
                    <button class="btn btn-primary" id="cu-save">Save</button>
                </div>
            </div>
        </div>`);
    document.body.appendChild(overlay);
    overlay.querySelector('#cu-name').focus();

    // Format a typed CNIC as 00000-0000000-0 once 13 digits are entered
    const cnicInput = overlay.querySelector('#cu-cnic');
    cnicInput.addEventListener('blur', () => {
        const digits = cnicInput.value.replace(/\D/g, '');
        if (digits.length === 13) cnicInput.value = `${digits.slice(0, 5)}-${digits.slice(5, 12)}-${digits.slice(12)}`;
    });

    overlay.querySelector('#cu-cancel').addEventListener('click', () => overlay.remove());
    overlay.querySelector('#cu-save').addEventListener('click', async () => {
        const payload = {
            name: overlay.querySelector('#cu-name').value.trim(),
            guardian_name: overlay.querySelector('#cu-guardian').value.trim(),
            cnic_no: overlay.querySelector('#cu-cnic').value.trim(),
            phone: overlay.querySelector('#cu-phone').value.trim(),
            address: overlay.querySelector('#cu-address').value.trim(),
            opening_balance: Number(overlay.querySelector('#cu-opening').value || 0),
        };
        if (!payload.name) { showToast('Customer ka naam zaroori hai', 'error'); return; }
        try {
            let id;
            if (isEdit) {
                payload.active = overlay.querySelector('#cu-active').checked;
                await call(window.api.customer.update(customer.id, payload));
                id = customer.id;
            } else {
                id = await call(window.api.customer.create({ business_id: AppState.business.id, ...payload }));
            }
            showToast('Customer saved', 'success');
            overlay.remove();
            if (onSaved) onSaved(id);
        } catch (e) { /* toast already shown */ }
    });
}

function openReceivePaymentModal(customer, onDone) {
    const overlay = el(`
        <div class="modal-overlay">
            <div class="modal-box">
                <h3>Payment Receive — ${esc(customer.name)}</h3>
                <div style="display:flex; justify-content:space-between; font-size:16px; margin-bottom:10px;">
                    <span>Baqi raqam</span><strong style="color:var(--red);">${money(customer.balance)}</strong>
                </div>
                <label>Amount Received</label>
                <input type="number" id="rp-amount" value="${Math.max(0, customer.balance)}" min="1" />
                <label>Payment Method</label>
                <select id="rp-method"><option value="cash">Cash</option><option value="online">Online</option><option value="bank">Bank Transfer</option></select>
                <label>Note (optional)</label>
                <input type="text" id="rp-note" placeholder="e.g. Kist 2" />
                <div class="modal-actions">
                    <button class="btn btn-secondary" id="rp-cancel">Cancel</button>
                    <button class="btn btn-primary" id="rp-save">Save Payment</button>
                </div>
            </div>
        </div>`);
    document.body.appendChild(overlay);
    overlay.querySelector('#rp-cancel').addEventListener('click', () => overlay.remove());
    overlay.querySelector('#rp-save').addEventListener('click', async () => {
        const amount = Number(overlay.querySelector('#rp-amount').value || 0);
        if (amount <= 0) { showToast('Raqam likhein', 'error'); return; }
        try {
            await call(window.api.customer.receivePayment({
                business_id: AppState.business.id, customer_id: customer.id, amount,
                payment_method: overlay.querySelector('#rp-method').value,
                note: overlay.querySelector('#rp-note').value.trim(),
                user_id: AppState.user.id,
            }));
            showToast('Payment record ho gayi', 'success');
            overlay.remove();
            if (onDone) onDone();
        } catch (e) { /* toast already shown */ }
    });
}

async function openCustomerStatement(customerId, onChanged) {
    const st = await call(window.api.customer.statement(customerId));
    const c = st.customer;
    const overlay = el(`
        <div class="modal-overlay">
            <div class="modal-box" style="max-width:760px;">
                <h3>Khata — ${esc(c.name)}</h3>
                <p class="hint">
                    ${c.guardian_name ? esc(c.guardian_name) + ' &nbsp;•&nbsp; ' : ''}
                    ${c.cnic_no ? 'CNIC: ' + esc(c.cnic_no) + ' &nbsp;•&nbsp; ' : ''}
                    ${c.phone ? esc(c.phone) : ''}
                    ${c.address ? '<br/>' + esc(c.address) : ''}
                </p>
                <table>
                    <thead><tr><th>Date</th><th>Type</th><th>Ref</th><th class="text-right">Bill</th><th class="text-right">Paid</th><th class="text-right">Balance</th></tr></thead>
                    <tbody>
                        <tr><td>-</td><td>Opening Balance</td><td></td><td class="text-right">-</td><td class="text-right">-</td><td class="text-right">${money(st.openingBalance)}</td></tr>
                        ${st.entries.map(e => `
                            <tr>
                                <td>${esc(String(e.date || '').slice(0, 10))}</td>
                                <td>${esc(e.type)}</td>
                                <td>${esc(e.ref || '')}</td>
                                <td class="text-right">${e.billed ? money(e.billed) : '-'}</td>
                                <td class="text-right">${e.paid ? money(e.paid) : '-'}</td>
                                <td class="text-right">${money(e.balance)}</td>
                            </tr>`).join('')}
                    </tbody>
                </table>
                <div style="text-align:right; margin-top:10px; font-size:16px;">
                    Kul Baqi: <strong style="color:${c.balance > 0 ? 'var(--red)' : 'var(--green)'};">${money(c.balance)}</strong>
                </div>
                <div class="modal-actions">
                    <button class="btn btn-secondary" id="stm-close">Close</button>
                    <button class="btn btn-secondary" id="stm-print">Print Khata</button>
                    ${can('customers.payment') && c.balance > 0 ? '<button class="btn btn-primary" id="stm-pay">Payment Receive</button>' : ''}
                </div>
            </div>
        </div>`);
    document.body.appendChild(overlay);
    overlay.querySelector('#stm-close').addEventListener('click', () => overlay.remove());
    overlay.querySelector('#stm-print').addEventListener('click', () => printCustomerStatement(st));
    const payBtn = overlay.querySelector('#stm-pay');
    if (payBtn) payBtn.addEventListener('click', () => {
        overlay.remove();
        openReceivePaymentModal(c, () => {
            if (onChanged) onChanged();
            openCustomerStatement(customerId, onChanged);
        });
    });
}

// A4 statement with the customer's invoice details at the top.
function printCustomerStatement(st) {
    const b = AppState.business;
    const c = st.customer;
    const logo = b.logo_data ? `<img src="${b.logo_data}" style="width:56px;height:56px;object-fit:contain;" />` : '';
    const html = `
    <html><head><meta charset="utf-8"><title>Khata - ${esc(c.name)}</title>
    <style>
        @page { size: A4; margin: 12mm; }
        body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a1a1a; font-size: 13px; }
        .head { display:flex; align-items:center; gap:12px; border-bottom:2px solid #222; padding-bottom:10px; margin-bottom:12px; }
        .head h1 { margin:0; font-size:20px; }
        .title { text-align:center; font-size:18px; font-weight:700; letter-spacing:2px; margin:6px 0 12px; }
        .grid { display:grid; grid-template-columns:1fr 1fr; gap:4px 20px; margin-bottom:12px; }
        .grid .full { grid-column: 1 / -1; }
        .lbl { color:#555; display:inline-block; min-width:100px; }
        table { width:100%; border-collapse:collapse; }
        th, td { border:1px solid #333; padding:6px 8px; text-align:left; }
        th { background:#eee; font-size:11px; text-transform:uppercase; }
        .r { text-align:right; }
        .total { text-align:right; font-size:15px; font-weight:700; margin-top:10px; }
        .footer { text-align:center; font-size:10px; color:#555; margin-top:24px; border-top:1px solid #ccc; padding-top:6px; }
    </style></head><body>
        <div class="head">${logo}<div><h1>${esc(b.name)}</h1><div>${esc(b.address || '')} ${b.phone ? '• ' + esc(b.phone) : ''}</div></div></div>
        <div class="title">CUSTOMER STATEMENT</div>
        <div class="grid">
            <div><span class="lbl">Full Name:</span> ${esc(c.name)}</div>
            <div><span class="lbl">S/O D/O W/O:</span> ${esc(c.guardian_name || '')}</div>
            <div><span class="lbl">CNIC No:</span> ${esc(c.cnic_no || '')}</div>
            <div><span class="lbl">Contact No:</span> ${esc(c.phone || '')}</div>
            <div class="full"><span class="lbl">Address:</span> ${esc(c.address || '')}</div>
        </div>
        <table>
            <thead><tr><th>Date</th><th>Type</th><th>Ref</th><th class="r">Bill</th><th class="r">Paid</th><th class="r">Balance</th></tr></thead>
            <tbody>
                <tr><td>-</td><td>Opening Balance</td><td></td><td class="r">-</td><td class="r">-</td><td class="r">${Number(st.openingBalance).toLocaleString()}</td></tr>
                ${st.entries.map(e => `<tr><td>${esc(String(e.date || '').slice(0, 10))}</td><td>${esc(e.type)}</td><td>${esc(e.ref || '')}</td><td class="r">${e.billed ? Number(e.billed).toLocaleString() : '-'}</td><td class="r">${e.paid ? Number(e.paid).toLocaleString() : '-'}</td><td class="r">${Number(e.balance).toLocaleString()}</td></tr>`).join('')}
            </tbody>
        </table>
        <div class="total">Total Balance: Rs ${Number(c.balance).toLocaleString()}</div>
        <div class="footer">Printed on ${new Date().toLocaleString()} — Powered by WM Tech</div>
    </body></html>`;

    call(window.api.print.preview({ pages: { a4: html }, size: 'a4', title: 'Khata-' + c.name }));
}
