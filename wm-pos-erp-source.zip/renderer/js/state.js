// Global app state shared across page modules
const AppState = {
    user: null,
    business: null,
    branch: null,
    businesses: [],
    branches: [],
    permissions: [],      // effective permission keys for the logged-in user
    permCatalog: null,    // {permissions, roleDefaults, pagePermission}
};

// Does the logged-in user hold this permission?
function can(key) {
    if (!AppState.user) return false;
    if (AppState.user.role === 'super_admin') return true;
    return AppState.permissions.includes(key);
}

function showToast(message, type = 'info') {
    const el = document.getElementById('toast');
    el.textContent = message;
    el.className = 'toast ' + type;
    el.classList.remove('hidden');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => el.classList.add('hidden'), 2600);
}

// Wraps an ipc call result {ok, data} / {ok:false, error} - throws or returns data
async function call(promise) {
    const res = await promise;
    if (!res || res.ok === false) {
        showToast((res && res.error) || 'Something went wrong', 'error');
        throw new Error((res && res.error) || 'IPC call failed');
    }
    return res.data;
}

function money(n) {
    n = Number(n || 0);
    return 'Rs ' + n.toLocaleString('en-PK', { maximumFractionDigits: 2 });
}

// Today's date as YYYY-MM-DD in the computer's own timezone (the same format
// as dates printed on other invoices).
function localDateISO(d = new Date()) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function todayRange() {
    const d = new Date();
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
    return { from: `${y}-${m}-${day} 00:00:00`, to: `${y}-${m}-${day} 23:59:59` };
}

function monthRange() {
    const d = new Date();
    const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0');
    const lastDay = new Date(y, d.getMonth() + 1, 0).getDate();
    return { from: `${y}-${m}-01 00:00:00`, to: `${y}-${m}-${lastDay} 23:59:59` };
}

function el(html) {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstChild;
}

// Escape text that gets injected into innerHTML (shop names are user-entered).
function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// Up to two initials from a shop name, used when no logo is uploaded.
function initialsOf(name) {
    const words = String(name || '').trim().split(/\s+/).filter(Boolean);
    if (!words.length) return 'WM';
    if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
    return (words[0][0] + words[1][0]).toUpperCase();
}

// Fill a .brand-mark element with either the uploaded logo or initials.
function paintBrandMark(elem, business) {
    if (!elem) return;
    if (business && business.logo_data) {
        elem.innerHTML = `<img src="${business.logo_data}" alt="logo" />`;
        elem.classList.add('has-logo');
    } else {
        elem.textContent = initialsOf(business && business.name);
        elem.classList.remove('has-logo');
    }
}

// Prints any sale (counter sale, service job) through the shared invoice
// layouts and the Print Preview window (see vehicle-invoice.js / main.js).
// `sale` may carry customer details directly; `customer` is optional.
function printReceipt({ business, branch, sale, items, customer }) {
    const inv = posSaleToInvoice(sale, items, customer || null);
    return chooseInvoiceSizeAndPrint({ business, branch, sale: inv });
}
