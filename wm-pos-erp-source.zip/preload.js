const { contextBridge, ipcRenderer } = require('electron');

// Every call returns { ok, data } or { ok:false, error } - see main.js `handle()`
function invoke(channel) {
    return (...args) => ipcRenderer.invoke(channel, ...args);
}

contextBridge.exposeInMainWorld('api', {
    auth: {
        login: invoke('auth:login'),
        currentUser: invoke('auth:currentUser'),
        createUser: invoke('auth:createUser'),
        listUsers: invoke('auth:listUsers'),
        updateUser: invoke('auth:updateUser'),
        deleteUser: invoke('auth:deleteUser'),
    },
    perms: {
        catalog: invoke('perms:catalog'),
    },
    business: {
        create: invoke('business:create'),
        list: invoke('business:list'),
        get: invoke('business:get'),
        update: invoke('business:update'),
        pickLogo: invoke('business:pickLogo'),
    },
    branch: {
        list: invoke('branch:list'),
        create: invoke('branch:create'),
    },
    category: {
        list: invoke('category:list'),
        create: invoke('category:create'),
    },
    product: {
        list: invoke('product:list'),
        create: invoke('product:create'),
        update: invoke('product:update'),
        delete: invoke('product:delete'),
        findByBarcode: invoke('product:findByBarcode'),
    },
    stock: {
        listForBranch: invoke('stock:listForBranch'),
        lowStock: invoke('stock:lowStock'),
        adjust: invoke('stock:adjust'),
    },
    supplier: {
        list: invoke('supplier:list'),
        create: invoke('supplier:create'),
    },
    purchase: {
        create: invoke('purchase:create'),
        list: invoke('purchase:list'),
        items: invoke('purchase:items'),
    },
    customer: {
        list: invoke('customer:list'),
        get: invoke('customer:get'),
        create: invoke('customer:create'),
        update: invoke('customer:update'),
        statement: invoke('customer:statement'),
        receivePayment: invoke('customer:receivePayment'),
    },
    sale: {
        create: invoke('sale:create'),
        list: invoke('sale:list'),
        items: invoke('sale:items'),
        get: invoke('sale:get'),
        refund: invoke('sale:refund'),
    },
    expense: {
        create: invoke('expense:create'),
        list: invoke('expense:list'),
    },
    account: {
        list: invoke('account:list'),
        balance: invoke('account:balance'),
    },
    ledger: {
        list: invoke('ledger:list'),
    },
    report: {
        salesSummary: invoke('report:salesSummary'),
        profitLoss: invoke('report:profitLoss'),
        topProducts: invoke('report:topProducts'),
    },
    vehicle: {
        list: invoke('vehicle:list'),
        get: invoke('vehicle:get'),
        create: invoke('vehicle:create'),
        update: invoke('vehicle:update'),
    },
    mechanic: {
        list: invoke('mechanic:list'),
        create: invoke('mechanic:create'),
        update: invoke('mechanic:update'),
    },
    serviceJob: {
        list: invoke('serviceJob:list'),
        get: invoke('serviceJob:get'),
        items: invoke('serviceJob:items'),
        create: invoke('serviceJob:create'),
        addItem: invoke('serviceJob:addItem'),
        removeItem: invoke('serviceJob:removeItem'),
        updateStatus: invoke('serviceJob:updateStatus'),
        summary: invoke('serviceJob:summary'),
    },
    vehicleUnit: {
        list: invoke('vehicleUnit:list'),
        get: invoke('vehicleUnit:get'),
        create: invoke('vehicleUnit:create'),
        update: invoke('vehicleUnit:update'),
    },
    vehicleSale: {
        list: invoke('vehicleSale:list'),
        get: invoke('vehicleSale:get'),
        create: invoke('vehicleSale:create'),
        cancel: invoke('vehicleSale:cancel'),
        summary: invoke('vehicleSale:summary'),
    },
    print: {
        preview: invoke('print:preview'),
    },
    backup: {
        create: invoke('backup:create'),
        restore: invoke('backup:restore'),
        chooseFolder: invoke('backup:chooseFolder'),
        runNow: invoke('backup:runNow'),
        list: invoke('backup:list'),
        restoreFrom: invoke('backup:restoreFrom'),
    },
    settings: {
        get: invoke('settings:get'),
        save: invoke('settings:save'),
    },
    update: {
        currentVersion: invoke('update:currentVersion'),
        check: invoke('update:check'),
        download: invoke('update:download'),
        install: invoke('update:install'),
        onStatus: (cb) => ipcRenderer.on('update:status', (e, payload) => cb(payload)),
    },
});
